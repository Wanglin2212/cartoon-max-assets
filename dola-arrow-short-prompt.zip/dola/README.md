# Dola Force Duration + Download

Main features:
1. **Force any positive whole-second duration** on Dola video generate (5, 10, 15, 20, 30, 47, 120 ...)
2. **No-watermark download** (button on each video, popup buttons, optional auto-download after generate)
3. **Facebook session login** with a saved non-secret Dola account label
4. **Apply and verify Video options** (model, ratio, and resolution)

## Install
- Chrome / Edge / Brave: `chrome://extensions` -> Developer mode -> **Load unpacked** -> pick this folder
- Firefox / Zen: `about:debugging#/runtime/this-firefox` -> **Load Temporary Add-on** -> pick `manifest.json`

## Use
1. Open dola.com, click the extension icon to open the native extension sidebar (or open it from your browser's side-panel/sidebar button).
2. Pick a preset (5/10/15/20/30/60) **or type any number of seconds** (the number box wins).
3. Save & apply. The extension switches Dola to **Video**, selects the chosen model first, then ratio and resolution, and confirms each visible control. Some models hide the Resolution control; in that case the extension proceeds and enforces the selected resolution in the final request instead of failing before prompt entry. It does not change Dola's duration chip while composing. When you click Dola's Submit arrow, every recognized video-generation settings object carries the exact selected `duration`, `model`, `ratio`, and `resolution`. **Apply video options on page now** repeats the visible-control synchronization without changing the duration chip.
4. Download: click the download control on a video, or use **Download latest / Download all** in the sidebar. The extension prefers Dola's clean/original file when exposed, then falls back to the normal player MP4, which may contain Dola's logo. It reads Dola's own media metadata responses without changing them.
   Turn on **Auto-download** to save the new video automatically after each generate.
5. **Prompt workflow**: enter a prompt and optionally choose one or more image files. Selected files appear as named thumbnail previews; remove them individually with × or use **Remove all images**. Any Drop/Fill/Generate action first navigates to `https://www.dola.com/chat`, opens **AI Creation**, switches the default **Image** mode to **Video**, and confirms the selected model/ratio/resolution before touching the prompt. **Drop images** uploads the selected files, **Fill prompt** fills the Video prompt box, **Prompt + Generate** fills and submits, and **Drop + Prompt + Generate** performs all three actions. Generate actions retry the blue up-arrow only until one exact final request is observed; after that request ID is recorded, the arrow cannot be clicked again. If a selected option is unavailable, the workflow reports FAILED and does not submit. Additional actions are queued while a workflow is active. The workflow is persisted across Dola navigation for up to three minutes.
6. **Facebook login**: use **Log in with Facebook session**. If Dola's login popup is not visible, the extension opens it, selects the Facebook provider, and lets Facebook reuse the session cookie already managed by the same browser profile. After Dola confirms login, the extension stores only the provider, Dola profile label, non-secret local identifier, and last-login time. It never reads, copies, exports, or replays Facebook cookies, tokens, email addresses, or passwords. If the Facebook session has expired, Facebook will request normal user authentication.
7. **Reset account**: open the sidebar and use the red **Reset account** button. After confirmation, it follows: profile-row arrow → Settings → Account → Delete Account → Delete → Delete Now, then handles the login UI in this priority order: Confirm → Continue with Facebook → Log In. If Facebook pauses on **Continue as…**, approve it in the Facebook window; the sidebar explains this checkpoint and the reset resumes automatically when Facebook returns to Dola. The durable flow allows five minutes for this round trip. **Pause** preserves the current step and freezes its timeout, **Continue** resumes it, **Stop** cancels automation on the current screen, and **End task** cancels then reloads Dola. Delete Now is retried until its UI genuinely disappears. The state survives Dola navigation and cannot report success until no login control remains, the authenticated profile row is stable, and its non-secret account label has been saved. The Dola page then refreshes automatically. Chrome/Edge uses the debugger permission for rendered controls; close DevTools before testing if Chrome reports another debugger is attached. Account deletion is permanent.

## Files
| File | World | Job |
|---|---|---|
| `dola_force_duration.js` | page (MAIN) | exact video-setting patcher; covers Dola's nested string-form `chat_ability` before request signing, then verifies fetch/XHR submissions without rebuilding authenticated Request objects |
| `dola_force_duration_bridge.js` | page (MAIN) | connects duration/model/ratio/resolution settings to the patcher and unsupported-duration guard |
| `dola_media_capture.js` | page (MAIN) | observes Dola's fetch and XHR recent-conversation/play-info metadata for clean-file resolution without changing requests or responses |
| `bootstrap_submit_only.js` | content | pushes current settings, records exact request diagnostics, and provides compatibility injection fallback |
| `video_option_matcher.js` | content | recognizes Dola model controls such as `2.0 Fast` plus model/ratio/resolution menu choices |
| `video_duration_audit.js` | content | compares the requested duration with rendered media metadata |
| `video_download_policy.js` | content | rejects logo/watermarked and unverified player files; accepts explicitly clean/original media metadata |
| `account_profile.js` | content | creates a strict non-secret allowlist for saved Facebook account metadata |
| `reset_account.js` | content | follows the confirmed account reset flow and browser-managed Facebook login |
| `workflow_actions.js` | content | selects and verifies Dola Video controls, drops images, fills prompts, and starts generation |
| `workflow_ui.js` | extension UI | controls the five prompt-workflow actions |
| `download.js` | content | exact-video metadata matcher, nested clean-URL resolver for current and legacy play-info responses, auto-download watcher, and rendered-duration audit |
| `download.css` | content | button + toast styles |
| `background.js` | service worker | `downloads.download()` |
| `sidebar.html` + `popup.js` | extension sidebar / side panel | settings + download buttons |

Prompt actions append only: “Do not shorten the duration without asking for my permission.” when duration forcing is enabled.

## Console API (page world)


```js
__dolaForceDuration.set(20)                 // force 20s
__dolaForceDuration.set(20, { model: "seedance_v2.5", ratio: "9:16", resolution: "1080p" })
__dolaForceDuration.setChip(20)             // click / type the chip now
__dolaForceDuration.get()                   // current forced seconds
__dolaForceDuration.cost()                  // points estimate (ceil(sec/5))
__dolaForceDuration.disable()
```

## Safety rules kept from the original
- One supplied settings engine handles Dola's current nested `message.ext.chat_ability` schema, plus fetch-init and XMLHttpRequest text-body submissions in the page MAIN world. The manifest loads it directly in MAIN; DOM injection is only a compatibility fallback.
- The current `ability_type = 17` settings are patched while Dola serializes them, before its request/authentication layer signs the body. Existing authenticated `Request` objects still pass through by identity.
- Only `duration`, `model`, `ratio`, and `resolution` inside recognized video-generation settings are changed before Dola signs the request. The final fetch/XHR boundary is audit-only: an unprepared request is blocked locally instead of being changed after signing. Other JSON fields, request options, headers, credentials, cookies, and sessions are preserved.
- The MAIN-world ownership guard disarms an older duplicate extension hook and blocks its Request-rebuilding implementation from loading afterward.
- Updating to v1.10.7 refreshes open Dola tabs once to remove any older page-world hook still held in tab memory; site cookies and login storage are not cleared.
- When Dola displays the exact response `Something went wrong. Please try again.`, the extension waits 2.5 seconds and clicks that response's Retry action. It makes at most five attempts, logs every attempt, and marks the prompt failed if the same response remains after attempt five.
- Facebook authentication remains browser-managed. Extension storage accepts only provider, display name, generated local identifier, and last-login time—never credentials or session material.
- A generation HTTP 429/high-demand response is marked FAILED and never auto-resubmitted. Dola's authentication headers, cookies, credentials, and response objects are inspected only for diagnostics and are never hidden or rewritten.
- If Dola still reaches `?from_logout=1` within two minutes of a generation, one bounded Facebook-session recovery attempt is allowed when a saved Facebook profile exists.
- Authenticated `Request` objects are passed through unchanged and are never rebuilt, preventing Dola session loss.
- Setting inspection is limited to Dola generation endpoints and `ability_type = 17`; unrelated JSON objects containing generic duration/model fields are ignored.
- Persisted Reset Account runs from older builds are discarded unless they carry fresh explicit-reset authorization.
- If an enabled generation request cannot be parsed and verified, it is blocked instead of silently sending an unforced request. Unrelated requests still pass through untouched.
- If Dola answers "longer than 10s is not supported, continue with 10s?" nothing is auto-clicked — your choice is never silently shortened. Unavailable model/ratio/resolution selections also stop the workflow before submit.

> Note: the site decides what durations it actually renders. The extension forces and verifies the final request, rejects a shorter-duration offer, and later compares the rendered video metadata with the requested duration. A materially shorter result (for example, 9s from a 30s request) is marked FAILED.
