(function (root, factory) {
  var api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  if (root) root.DolaAccountProfile = api;
})(typeof globalThis !== "undefined" ? globalThis : self, function () {
  "use strict";

  function normalizeDisplayName(value) {
    return String(value || "").replace(/\s+/g, " ").trim().slice(0, 100);
  }

  function hashText(value) {
    var hash = 2166136261;
    var text = String(value || "");
    for (var index = 0; index < text.length; index += 1) {
      hash ^= text.charCodeAt(index);
      hash = Math.imul(hash, 16777619);
    }
    return (hash >>> 0).toString(16).padStart(8, "0");
  }

  function createAccountInfo(provider, displayName, timestamp) {
    var safeProvider = String(provider || "").toLowerCase() === "facebook" ? "facebook" : "";
    var safeName = normalizeDisplayName(displayName);
    var date = timestamp == null ? new Date() : new Date(timestamp);
    if (!safeProvider || !safeName || !Number.isFinite(date.getTime())) return null;
    return {
      id: safeProvider + ":" + hashText(safeName.toLowerCase()),
      provider: safeProvider,
      displayName: safeName,
      lastLoginAt: date.toISOString()
    };
  }

  function safeAccountInfo(value) {
    if (!value || typeof value !== "object") return null;
    return createAccountInfo(value.provider, value.displayName, value.lastLoginAt);
  }

  return {
    normalizeDisplayName: normalizeDisplayName,
    createAccountInfo: createAccountInfo,
    safeAccountInfo: safeAccountInfo
  };
});
