var t="undefined"!=typeof browser?browser:chrome;

// An unpacked extension reload does not remove page-world hooks from tabs that
// were already open. Refresh each Dola tab once for this migration so no
// v1.8.x request wrapper survives in memory. This does not clear site data.
(function refreshDolaTabsForSafeHookMigration(){
  var migrationVersion="1.10.25", storageKey="dolaSafeHookMigrationVersion";
  if (typeof browser !== "undefined" && t === browser) {
    Promise.resolve().then(function(){return t.storage.local.get(storageKey);}).then(async function(data){
      if(data&&data[storageKey]===migrationVersion)return;
      if(t.tabs&&t.tabs.query&&t.tabs.reload){
        var tabs=await t.tabs.query({url:["*://dola.com/*","*://www.dola.com/*"]});
        await Promise.all((tabs||[]).filter(function(tab){return tab&&Number.isInteger(tab.id);}).map(function(tab){return t.tabs.reload(tab.id);}));
      }
      var update={};update[storageKey]=migrationVersion;
      await t.storage.local.set(update);
    }).catch(function(error){console.warn("[Dola ForceDuration/bg] safe-hook migration could not refresh Dola tabs",error);});
    return;
  }
  try {
    t.storage.local.get(storageKey,function(data){
      if(data&&data[storageKey]===migrationVersion)return;
      var update={}; update[storageKey]=migrationVersion;
      t.storage.local.set(update,function(){
        if(!t.tabs||!t.tabs.query||!t.tabs.reload)return;
        t.tabs.query({url:["*://dola.com/*","*://www.dola.com/*"]},function(tabs){
          (tabs||[]).forEach(function(tab){
            if(tab&&Number.isInteger(tab.id))t.tabs.reload(tab.id,function(){void t.runtime.lastError;});
          });
        });
      });
    });
  }catch(error){console.warn("[Dola ForceDuration/bg] safe-hook migration could not refresh Dola tabs",error);}
})();

function r(t,r){try{var e=(new URL(t).pathname.split("/").pop()||"").split("?")[0];if(e&&/\.(mp4|mov|webm|m4v)$/i.test(e))return e}catch(t){}var a=new Date;return"dola-video-"+(a.getFullYear()+String(a.getMonth()+1).padStart(2,"0")+String(a.getDate()).padStart(2,"0"))+"-"+String(a.getHours()).padStart(2,"0")+String(a.getMinutes()).padStart(2,"0")+String(a.getSeconds()).padStart(2,"0")+"-"+(r+1)+".mp4"}

// Open the native extension sidebar from the toolbar button.
if (t.action && t.action.onClicked) t.action.onClicked.addListener(function(tab){
  if (t.sidePanel && t.sidePanel.open) {
    t.sidePanel.open({windowId: tab.windowId}).catch(function(error){
      console.warn("[Dola ForceDuration/bg] side panel could not open", error);
    });
  } else if (t.sidebarAction && t.sidebarAction.open) {
    t.sidebarAction.open();
  }
});

function validDownloadUrls(values) {
  var seen = new Set(), urls = [], failures = [];
  (Array.isArray(values) ? values : []).forEach(function(value, index) {
    try {
      var parsed = new URL(String(value || "").trim());
      if (parsed.protocol !== "http:" && parsed.protocol !== "https:") throw new Error("Only HTTP(S) video URLs can be downloaded.");
      if (seen.has(parsed.href)) return;
      seen.add(parsed.href);
      urls.push(parsed.href);
    } catch (error) {
      failures.push({index:index,error:error && error.message || "Invalid download URL."});
    }
  });
  return {urls:urls,failures:failures};
}

function startDownload(url, index) {
  var options = {url:url,filename:r(url,index),conflictAction:"uniquify"};
  // Firefox's browser API is Promise-based. Chrome's callback form lets us
  // reliably read runtime.lastError on versions that do not return a Promise.
  if (typeof browser !== "undefined" && t === browser) return Promise.resolve(t.downloads.download(options));
  return new Promise(function(resolve,reject) {
    try {
      t.downloads.download(options,function(downloadId) {
        var lastError = t.runtime && t.runtime.lastError;
        if (lastError) reject(new Error(lastError.message));
        else if (downloadId === undefined || downloadId === null) reject(new Error("The browser did not start the download."));
        else resolve(downloadId);
      });
    } catch (error) { reject(error); }
  });
}

t.runtime.onMessage.addListener(function(message,sender,sendResponse){
  if(!message||message.type!=="DOLA_FD_DOWNLOAD")return;
  (async function(){
    var checked=validDownloadUrls(message.urls),failures=checked.failures.slice(),count=0;
    for(var index=0;index<checked.urls.length;index++){
      try{await startDownload(checked.urls[index],index);count++;}
      catch(error){
        var detail={index:index,url:checked.urls[index],error:error&&error.message||String(error)};
        failures.push(detail);
        console.warn("[Dola ForceDuration/bg] download failed",detail.error);
      }
    }
    var requested=checked.urls.length,ok=requested>0&&count===requested&&failures.length===0;
    var error="";
    if(!requested)error=failures.length?"No valid HTTP(S) download URLs were provided.":"No download URLs were provided.";
    else if(failures.length)error=count?count+" of "+requested+" downloads started; "+failures.length+" failed.":"The browser rejected every download.";
    sendResponse({ok:ok,count:count,requested:requested,failures:failures,error:error});
  })().catch(function(error){
    sendResponse({ok:false,count:0,requested:0,failures:[{error:error&&error.message||String(error)}],error:error&&error.message||String(error)});
  });
  return true;
});

// Chrome/Edge trusted clicks for Dola controls that React does not accept from
// synthetic page events. Semantic lookup uses Chrome's accessibility tree, so
// generated wrappers and open shadow roots do not hide the target.
if (t.debugger && t.debugger.attach) t.runtime.onMessage.addListener(function(e,a,n){
  if (!e || e.type !== "DOLA_FD_TRUSTED_CLICK" || !a.tab || !a.tab.id) return;
  var target = {tabId:a.tab.id}, x = Number(e.x), y = Number(e.y), done = false, visualFallbackStarted = false;
  var semantic = String(e.semantic || "").trim();
  if (semantic !== "Delete Now" && semantic !== "Facebook") semantic = "";
  function finish(result) { if (done) return; done = true; n(result); }
  function close(result) { t.debugger.detach(target, function(){ finish(result); }); }
  function boxDetails(boxResult) {
    var quad = boxResult && boxResult.model && boxResult.model.content;
    if (!quad || quad.length < 8) return null;
    var width = Math.max(quad[0],quad[2],quad[4],quad[6]) - Math.min(quad[0],quad[2],quad[4],quad[6]);
    var height = Math.max(quad[1],quad[3],quad[5],quad[7]) - Math.min(quad[1],quad[3],quad[5],quad[7]);
    if (width < 2 || height < 2) return null;
    return {x:(quad[0]+quad[2]+quad[4]+quad[6])/4,y:(quad[1]+quad[3]+quad[5]+quad[7])/4,width:width,height:height};
  }
  function dispatchClick(px, py, details) {
    t.debugger.sendCommand(target, "Input.dispatchMouseEvent", {type:"mouseMoved",x:px,y:py,pointerType:"mouse"}, function(){
      if (t.runtime.lastError) { close({ok:false,error:t.runtime.lastError.message,stage:"mouseMoved"}); return; }
      t.debugger.sendCommand(target, "Input.dispatchMouseEvent", {type:"mousePressed",x:px,y:py,button:"left",buttons:1,clickCount:1,pointerType:"mouse"}, function(){
        if (t.runtime.lastError) { close({ok:false,error:t.runtime.lastError.message,stage:"mousePressed"}); return; }
        t.debugger.sendCommand(target, "Input.dispatchMouseEvent", {type:"mouseReleased",x:px,y:py,button:"left",buttons:0,clickCount:1,pointerType:"mouse"}, function(){
          var error = t.runtime.lastError;
          close(error ? {ok:false,error:error.message} : Object.assign({ok:true,x:px,y:py},details||{}));
        });
      });
    });
  }
  function tryVisualDeleteNow(originalError) {
    if (visualFallbackStarted) { close({ok:false,error:originalError,semantic:"Delete Now"}); return; }
    visualFallbackStarted = true;
    t.debugger.sendCommand(target,"Page.getLayoutMetrics",{},function(metrics){
      var metricsError=t.runtime.lastError;
      var cssWidth=metrics&&metrics.cssLayoutViewport&&Number(metrics.cssLayoutViewport.clientWidth);
      if(metricsError||!cssWidth){close({ok:false,error:metricsError&&metricsError.message||"Visual fallback could not read the viewport",semantic:"Delete Now"});return;}
      t.debugger.sendCommand(target,"Page.captureScreenshot",{format:"png",fromSurface:true,captureBeyondViewport:false},function(capture){
        var captureError=t.runtime.lastError;
        if(captureError||!capture||!capture.data){close({ok:false,error:captureError&&captureError.message||"Visual fallback could not capture Dola",semantic:"Delete Now"});return;}
        (async function(){
          if(typeof createImageBitmap!=="function"||typeof OffscreenCanvas!=="function")throw new Error("Visual image analysis is unavailable in this browser");
          var binary=atob(capture.data),bytes=new Uint8Array(binary.length);
          for(var byteIndex=0;byteIndex<binary.length;byteIndex++)bytes[byteIndex]=binary.charCodeAt(byteIndex);
          var bitmap=await createImageBitmap(new Blob([bytes],{type:"image/png"}));
          var canvas=new OffscreenCanvas(bitmap.width,bitmap.height),context=canvas.getContext("2d",{willReadFrequently:true});
          context.drawImage(bitmap,0,0); bitmap.close();
          var pixels=context.getImageData(0,0,canvas.width,canvas.height).data;
          function redAt(px,py){
            if(px<0||py<0||px>=canvas.width||py>=canvas.height)return false;
            var offset=(Math.floor(py)*canvas.width+Math.floor(px))*4,r=pixels[offset],g=pixels[offset+1],b=pixels[offset+2],alpha=pixels[offset+3];
            return alpha>220&&r>=210&&g<=130&&b<=120&&r-g>=90&&r-b>=90;
          }
          var best=null,step=2;
          for(var py=0;py<canvas.height;py+=step){
            var runStart=-1;
            for(var px=0;px<=canvas.width;px+=step){
              var red=px<canvas.width&&redAt(px,py);
              if(red&&runStart<0)runStart=px;
              if(!red&&runStart>=0){var width=px-runStart;if(!best||width>best.width)best={left:runStart,right:px-step,y:py,width:width};runStart=-1;}
            }
          }
          if(!best)throw new Error("No red Delete Now surface found");
          var centerX=(best.left+best.right)/2,top=best.y,bottom=best.y;
          while(top>0&&redAt(centerX,top-1))top--;
          while(bottom<canvas.height-1&&redAt(centerX,bottom+1))bottom++;
          var scale=canvas.width/cssWidth,cssButtonWidth=best.width/scale,cssButtonHeight=(bottom-top+1)/scale;
          if(cssButtonWidth<160||cssButtonHeight<24||cssButtonHeight>100||cssButtonWidth/cssButtonHeight<2.5)throw new Error("Red surface did not match Delete Now button dimensions");
          dispatchClick(centerX/scale,((top+bottom)/2)/scale,{matchedBy:"visual-red-control",semantic:"Delete Now",width:cssButtonWidth,height:cssButtonHeight});
        })().catch(function(error){close({ok:false,error:originalError+"; "+error.message,semantic:"Delete Now",matchedBy:"visual-fallback"});});
      });
    });
  }
  function fallbackCoordinatesOrClose(error, label) {
    if (isFinite(x) && isFinite(y)) {
      dispatchClick(x,y,{matchedBy:"coordinates-fallback",semantic:label||semantic||""});
      return;
    }
    if ((label || semantic) === "Delete Now") { tryVisualDeleteNow(error); return; }
    close({ok:false,error:error,semantic:label||semantic||""});
  }
  function tryBoxNodes(nodes, index, details, exhausted) {
    if (index >= nodes.length) { exhausted(); return; }
    var node = nodes[index];
    var boxInput = node.backendDOMNodeId ? {backendNodeId:node.backendDOMNodeId} : {nodeId:node.nodeId};
    t.debugger.sendCommand(target, "DOM.getBoxModel", boxInput, function(result){
      var box = boxDetails(result);
      var facebookSize = semantic === "Facebook" && box && (box.width < 18 || box.width > 120 || box.height < 18 || box.height > 120);
      if (!box || facebookSize) { tryBoxNodes(nodes,index+1,details,exhausted); return; }
      dispatchClick(box.x,box.y,Object.assign({},details,{width:box.width,height:box.height}));
    });
  }
  function searchDom(query) {
    t.debugger.sendCommand(target,"DOM.enable",{},function(){
      t.debugger.sendCommand(target,"DOM.performSearch",{query:query,includeUserAgentShadowDOM:true},function(searchResult){
        var searchId = searchResult && searchResult.searchId;
        var count = searchResult && searchResult.resultCount || 0;
        if (!searchId || !count) { fallbackCoordinatesOrClose("Semantic control not found",semantic||query); return; }
        t.debugger.sendCommand(target,"DOM.getSearchResults",{searchId:searchId,fromIndex:0,toIndex:Math.min(count,80)},function(results){
          var nodes = (results && results.nodeIds || []).map(function(nodeId){return {nodeId:nodeId};});
          t.debugger.sendCommand(target,"DOM.discardSearchResults",{searchId:searchId},function(){
            tryBoxNodes(nodes,0,{matchedBy:"dom-search",semantic:semantic||query},function(){ fallbackCoordinatesOrClose("Semantic control has no clickable box",semantic||query); });
          });
        });
      });
    });
  }
  function deepSemanticExpression(name) {
    return "(" + function(semanticName){
      function normalized(value){return String(value||"").replace(/\s+/g," ").trim().toLowerCase();}
      function visible(element){
        if(!element||!element.isConnected)return false;
        var style=getComputedStyle(element),rect=element.getBoundingClientRect();
        return style.display!=="none"&&style.visibility!=="hidden"&&style.opacity!=="0"&&style.pointerEvents!=="none"&&rect.width>2&&rect.height>2;
      }
      function clickable(element){
        if(!element)return null;
        var current=element;
        for(var depth=0;current&&depth<8;depth++,current=current.parentElement){
          var tag=String(current.tagName||"").toLowerCase(),role=current.getAttribute&&current.getAttribute("role"),tabindex=current.getAttribute&&current.getAttribute("tabindex"),style;
          try{style=getComputedStyle(current);}catch(error){style=null;}
          if(tag==="button"||tag==="a"||role==="button"||(tabindex!=null&&tabindex!=="-1")||current.onclick||(style&&style.cursor==="pointer")||/(?:^|[\s_-])(?:button|btn|cursor-pointer)(?:[\s_-]|$)/i.test(String(current.className||"")))return current;
        }
        return null;
      }
      function details(element){
        var values=[element.textContent,element.getAttribute&&element.getAttribute("aria-label"),element.getAttribute&&element.getAttribute("title"),element.id,element.className,element.getAttribute&&element.getAttribute("data-provider"),element.getAttribute&&element.getAttribute("data-testid")];
        return normalized(values.filter(Boolean).join(" "));
      }
      function blueEvidence(element){
        var nodes=[element].concat(Array.from(element.querySelectorAll("svg,img,path,circle,use,i")));
        return nodes.some(function(node){
          var values=[node.getAttribute&&node.getAttribute("fill"),node.getAttribute&&node.getAttribute("stroke"),node.getAttribute&&node.getAttribute("style"),node.getAttribute&&node.getAttribute("src")];
          try{var style=getComputedStyle(node);values.push(style.color,style.fill,style.stroke,style.backgroundColor);}catch(error){}
          var text=normalized(values.filter(Boolean).join(" "));
          if(/#(?:1877f2|0866ff|4267b2|3b5998|1b74e4)\b/i.test(text))return true;
          var match,pattern=/rgba?\(\s*(\d{1,3})\s*[, ]\s*(\d{1,3})\s*[, ]\s*(\d{1,3})(?:\s*[,/]\s*([\d.]+))?/ig;
          while((match=pattern.exec(text))){var r=Number(match[1]),g=Number(match[2]),b=Number(match[3]),a=match[4]==null?1:Number(match[4]);if(a>.15&&b>=145&&b>=g+45&&g>=r+25)return true;}
          return false;
        });
      }
      var roots=[document],rootIndex=0,all=[],rendered=[],deleteNowVisible=false;
      while(rootIndex<roots.length){
        var root=roots[rootIndex++];
        Array.from(root.querySelectorAll("*")).forEach(function(element){
          if(element.shadowRoot)roots.push(element.shadowRoot);
          if(visible(element)){rendered.push(element);if(normalized(element.textContent)==="delete now")deleteNowVisible=true;}
          var target=clickable(element);if(target&&all.indexOf(target)<0&&visible(target))all.push(target);
        });
      }
      var wanted=normalized(semanticName),matches=[];
      if(wanted==="delete now"){
        matches=all.filter(function(element){return normalized(element.textContent)===wanted;});
        // Some Dola builds render the final red control as a plain div with no
        // role, tabindex, click cursor, or accessible button ancestor. Its
        // exact rendered label is still safe and unambiguous inside this flow.
        if(!matches.length)matches=rendered.filter(function(element){return normalized(element.textContent)===wanted;});
      }
      else if(wanted==="facebook"&&!deleteNowVisible){
        var circular=all.filter(function(element){var rect=element.getBoundingClientRect();return rect.width>=18&&rect.width<=120&&rect.height>=18&&rect.height<=120&&Math.abs(rect.width-rect.height)<=30;});
        matches=circular.filter(function(element){
        var rect=element.getBoundingClientRect(),hint=details(element);
        if(/google|apple|iphone|phone|telephone|mobile|sms|qr(?:[ _-]?code)?/.test(hint)&&!/(?:facebook|fb[ _-]?(?:login|auth|provider|logo)|provider[ _-]?fb)/.test(hint))return false;
        var centerX=rect.left+rect.width/2,centerY=rect.top+rect.height/2;
        var hasPeer=circular.some(function(other){if(other===element)return false;var otherRect=other.getBoundingClientRect();return Math.abs(centerY-(otherRect.top+otherRect.height/2))<=18&&Math.abs(centerX-(otherRect.left+otherRect.width/2))<=240;});
        return hasPeer&&(/(?:facebook|fb[ _-]?(?:login|auth|provider|logo)|provider[ _-]?fb)/.test(hint)||blueEvidence(element));
        });
      }
      matches.sort(function(left,right){return left.getBoundingClientRect().width*left.getBoundingClientRect().height-right.getBoundingClientRect().width*right.getBoundingClientRect().height;});
      if(!matches.length)return null;
      var rect=matches[0].getBoundingClientRect();
      return {x:rect.left+rect.width/2,y:rect.top+rect.height/2,width:rect.width,height:rect.height};
    } + ")(" + JSON.stringify(name) + ")";
  }
  function searchDeepSemantic(name) {
    t.debugger.sendCommand(target,"Runtime.evaluate",{expression:deepSemanticExpression(name),returnByValue:true},function(result){
      var value=result&&result.result&&result.result.value;
      if(value&&isFinite(value.x)&&isFinite(value.y)) {
        dispatchClick(Number(value.x),Number(value.y),{matchedBy:"deep-dom",semantic:name,width:value.width,height:value.height});
        return;
      }
      if(name === "Facebook") fallbackCoordinatesOrClose("Facebook provider row not found",name);
      else searchDom(name);
    });
  }
  function searchAccessibility(name) {
    t.debugger.sendCommand(target,"Accessibility.enable",{},function(){
      t.debugger.sendCommand(target,"Accessibility.getFullAXTree",{},function(result){
        var wanted = name.toLowerCase();
        var candidates = (result && result.nodes || []).filter(function(node){
          if (!node || node.ignored || !node.backendDOMNodeId) return false;
          var label = String(node.name && node.name.value || "").replace(/\s+/g," ").trim().toLowerCase();
          var role = String(node.role && node.role.value || "").toLowerCase();
          if (!/(?:button|link|image|generic)/.test(role)) return false;
          return wanted === "delete now" ? label === wanted : /(?:^|\b)(?:facebook|fb)(?:\b|$)/.test(label);
        }).sort(function(left,right){
          var leftRole = String(left.role && left.role.value || "").toLowerCase();
          var rightRole = String(right.role && right.role.value || "").toLowerCase();
          return Number(rightRole === "button") - Number(leftRole === "button");
        });
        tryBoxNodes(candidates,0,{matchedBy:"accessibility",semantic:name},function(){ searchDeepSemantic(name); });
      });
    });
  }
  t.debugger.attach(target,"1.3",function(){
    if (t.runtime.lastError) { finish({ok:false,error:t.runtime.lastError.message}); return; }
    // Exact content-script coordinates are more specific than any global
    // semantic lookup and must always win.
    if (isFinite(x) && isFinite(y)) dispatchClick(x,y,{matchedBy:"coordinates",semantic:semantic});
    else if (semantic === "Facebook") searchDeepSemantic(semantic);
    else if (semantic) searchAccessibility(semantic);
    else if (e.selector) searchDom(String(e.selector));
    else close({ok:false,error:"Invalid click target"});
  });
  return true;
});

// Trusted keyboard fallback for controlled/contenteditable Dola prompt boxes.
if (t.debugger && t.debugger.attach) t.runtime.onMessage.addListener(function(e,a,n){
  if (!e || e.type !== "DOLA_FD_TRUSTED_TEXT" || !a.tab || !a.tab.id) return;
  var target = {tabId:a.tab.id}, x = Number(e.x), y = Number(e.y), text = String(e.text || ""), done = false;
  function finish(result) {
    if (done) return;
    done = true;
    t.debugger.detach(target, function(){ n(result); });
  }
  function run(commands, index) {
    if (index >= commands.length) { finish({ok:true}); return; }
    var command = commands[index];
    t.debugger.sendCommand(target, command[0], command[1], function(){
      if (t.runtime.lastError) { finish({ok:false,error:t.runtime.lastError.message}); return; }
      run(commands, index + 1);
    });
  }
  t.debugger.attach(target, "1.3", function(){
    if (t.runtime.lastError) { done = true; n({ok:false,error:t.runtime.lastError.message}); return; }
    if (!isFinite(x) || !isFinite(y)) { finish({ok:false,error:"Invalid prompt target"}); return; }
    run([
      ["Input.dispatchMouseEvent", {type:"mouseMoved",x:x,y:y}],
      ["Input.dispatchMouseEvent", {type:"mousePressed",x:x,y:y,button:"left",clickCount:1}],
      ["Input.dispatchMouseEvent", {type:"mouseReleased",x:x,y:y,button:"left",clickCount:1}],
      ["Input.dispatchKeyEvent", {type:"rawKeyDown",key:"Control",code:"ControlLeft",windowsVirtualKeyCode:17,modifiers:2}],
      ["Input.dispatchKeyEvent", {type:"rawKeyDown",key:"a",code:"KeyA",windowsVirtualKeyCode:65,modifiers:2}],
      ["Input.dispatchKeyEvent", {type:"keyUp",key:"a",code:"KeyA",windowsVirtualKeyCode:65,modifiers:2}],
      ["Input.dispatchKeyEvent", {type:"keyUp",key:"Control",code:"ControlLeft",windowsVirtualKeyCode:17}],
      ["Input.insertText", {text:text}]
    ], 0);
  });
  return true;
});
