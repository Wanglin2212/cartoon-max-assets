(function () {
  "use strict";

  if (window.__dolaFDBootstrap) return;
  window.__dolaFDBootstrap = true;

  var api = typeof browser !== "undefined" ? browser : chrome;
  var defaults = { enabled: true, duration: 15, autoChip: false, ratio: "", model: "", resolution: "" };
  var lastUrl = location.href;
  var mainReady = false;
  var lastSettings = null;

  function submitOnlySettings(settings) {
    return Object.assign({}, defaults, settings || {}, { autoChip: false });
  }

  function pushSettings(settings) {
    var safe = submitOnlySettings(settings);
    lastSettings = safe;
    window.postMessage({ type: "DOLA_FORCE_DURATION_SETTINGS", settings: safe }, "*");
    console.log("[Dola ForceDuration/boot]", safe.enabled ? "armed for submit: " + safe.duration + "s" : "disabled");
  }

  function readSettings() {
    return new Promise(function (resolve) {
      try {
        api.storage.local.get("forceDuration", function (data) {
          resolve(submitOnlySettings(data && data.forceDuration));
        });
      } catch (error) {
        resolve(submitOnlySettings());
      }
    });
  }

  function injectScript(fileName) {
    return new Promise(function (resolve) {
      try {
        var script = document.createElement("script");
        script.src = api.runtime.getURL(fileName);
        script.async = false;
        script.onload = function () {
          script.remove();
          resolve(true);
        };
        script.onerror = function () {
          console.warn("[Dola ForceDuration/boot] failed to inject " + fileName);
          resolve(false);
        };
        (document.head || document.documentElement).appendChild(script);
      } catch (error) {
        console.warn("[Dola ForceDuration/boot] inject error", error && error.message);
        resolve(false);
      }
    });
  }

  async function injectPageHook() {
    if (document.documentElement.dataset.dolaFdV11012Injected === "1") return true;
    if (!await injectScript("dola_force_duration.js")) return false;
    if (!await injectScript("dola_force_duration_bridge.js")) return false;
    if (!await injectScript("dola_media_capture.js")) return false;
    document.documentElement.dataset.dolaFdV11012Injected = "1";
    return true;
  }

  async function start() {
    pushSettings(await readSettings());
    setTimeout(async function () {
      if (mainReady) return;
      console.warn("[Dola ForceDuration/boot] MAIN-world manifest scripts did not report ready; trying compatibility injection.");
      await injectPageHook();
      if (lastSettings) pushSettings(lastSettings);
    }, 750);
  }

  start();

  try {
    api.storage.onChanged.addListener(function (changes, area) {
      if (area === "local" && changes.forceDuration) {
        pushSettings(changes.forceDuration.newValue || {});
      }
    });
  } catch (error) {}

  try {
    api.runtime.onMessage.addListener(function (message) {
      if (message && message.type === "DOLA_FD_APPLY_CHIP") {
        window.postMessage({ type: "DOLA_FORCE_DURATION_APPLY_CHIP" }, "*");
      }
    });
  } catch (error) {}

  try {
    window.addEventListener("message", function (event) {
      if (event.source !== window || event.origin !== location.origin) return;
      var message = event && event.data;
      if (!message || typeof message !== "object") return;
      if (message.type === "DOLA_FD_FORCE_READY") {
        mainReady = true;
        if (lastSettings) pushSettings(lastSettings);
      }
      if (message.type === "DOLA_FD_GEN_SEEN") {
        api.storage.local.set({ dolaLastGenerationAttemptAt: Date.now() });
        return;
      }
      if (message.type !== "DOLA_FD_FORCE_RESULT" && message.type !== "DOLA_FD_DURATION_REFUSED" && message.type !== "DOLA_FD_FORCE_READY" && message.type !== "DOLA_FD_GENERATION_RESPONSE" && message.type !== "DOLA_FD_PREFLIGHT" && message.type !== "DOLA_FD_GENERATION_REJECTED") return;
      var entry = {
        time: new Date().toISOString(),
        step: "force",
        status: message.status || "running",
        message: message.message || "Duration request updated.",
        url: message.url || location.pathname
      };
      api.storage.local.get("dolaForceDiagnosticLog", function (data) {
        var log = data && Array.isArray(data.dolaForceDiagnosticLog) ? data.dolaForceDiagnosticLog.slice(-99) : [];
        log.push(entry);
        var update = { dolaForceDiagnostic: entry, dolaForceDiagnosticLog: log };
        if (message.type === "DOLA_FD_FORCE_RESULT" && message.finalRequest) update.dolaLatestForceResult = message;
        if (message.type === "DOLA_FD_GENERATION_RESPONSE") update.dolaLatestGenerationResponse = message;
        api.storage.local.set(update);
      });
    });
  } catch (error) {}

  setInterval(function () {
    if (location.href === lastUrl) return;
    lastUrl = location.href;
    start();
  }, 1500);
}());
