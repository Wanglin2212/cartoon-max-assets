(function (root, factory) {
  const api = factory(root);
  if (typeof module === "object" && module.exports) module.exports = api;
  if (root) {
    root.DolaForceDuration = api;
    if (root.document) {
      // Claim the two legacy globals immediately. This closes the small gap
      // between loading this module and loading the bridge, so an older copy
      // of the extension cannot install its Request-rebuilding hook afterward.
      root.__dolaForceDurationSubmit = true;
      if (!root.__dolaForceDuration) {
        root.__dolaForceDuration = {
          __dolaForceDurationVersion: "1.10.13",
          __dolaForceDurationSentinel: true
        };
      }
    }
  }
})(typeof globalThis !== "undefined" ? globalThis : self, function (root) {
  "use strict";

  // Keep private references so the narrowly-scoped pre-serialization hook
  // below never calls itself recursively.
  const nativeJsonParse = JSON.parse;
  const nativeJsonStringify = JSON.stringify;

  function secondsValue(value) {
    const seconds = Number(value);
    return Number.isInteger(seconds) && seconds > 0 ? seconds : 0;
  }

  function selectedSeconds(preset, custom) {
    const customText = String(custom == null ? "" : custom).trim();
    if (customText) return secondsValue(customText);
    return secondsValue(preset);
  }

  const allowedRatios = new Set(["9:16", "16:9", "1:1", "4:3", "3:4"]);
  const allowedModels = new Set(["seedance_v2.0", "seedance_v2.5"]);
  const allowedResolutions = new Set(["480p", "720p", "1080p", "2k", "4k"]);

  function selectedOption(value, allowed) {
    const option = String(value == null ? "" : value).trim();
    return allowed.has(option) ? option : "";
  }

  function normalizeSettings(value) {
    const source = value && typeof value === "object" ? value : { duration: value };
    const duration = secondsValue(source.duration);
    return {
      enabled: source.enabled !== false && duration > 0,
      duration: duration,
      ratio: selectedOption(source.ratio, allowedRatios),
      model: selectedOption(source.model, allowedModels),
      resolution: selectedOption(source.resolution, allowedResolutions),
    };
  }

  function settingsSignature(value) {
    const settings = normalizeSettings(value);
    if (!settings.enabled) return "";
    return [settings.duration, settings.ratio, settings.model, settings.resolution].join("|");
  }

  function parseObject(value) {
    if (value && typeof value === "object") return value;
    if (typeof value !== "string") return null;
    try {
      const parsed = nativeJsonParse(value);
      return parsed && typeof parsed === "object" ? parsed : null;
    } catch (_) {
      return null;
    }
  }

  function generationRequestUrl(value) {
    const url = String(value || "");
    return /\/(?:samantha\/)?chat\/(?:completion|async\/chunk_stream)(?:[/?#]|$)/i.test(url);
  }

  function requestUrl(input) {
    if (typeof input === "string") return input;
    if (root && typeof root.URL === "function" && input instanceof root.URL) return input.href;
    return input && input.url || "";
  }

  /**
   * Force the selected video-generation settings into Dola's ability_type 17
   * JSON only. Unrelated request fields, headers, cookies and tokens are left
   * untouched.
   */
  function patchPayload(bodyText, requestedSettings) {
    const settings = normalizeSettings(requestedSettings);
    const seconds = settings.duration;
    if (!settings.enabled || typeof bodyText !== "string") {
      return { bodyText: bodyText, changed: false, matched: false, applied: false, seconds: 0, settings: settings };
    }

    let body;
    try {
      body = nativeJsonParse(bodyText);
    } catch (_) {
      return { bodyText: bodyText, changed: false, matched: false, applied: false, seconds: seconds, settings: settings };
    }

    let changed = false;
    let generationPayload = false;
    let mutationCount = 0;
    let applicationCount = 0;
    let verificationFailed = false;

    function setGenerationSettings(container, key) {
      const original = container[key];
      const params = parseObject(original);
      if (!params || Array.isArray(params)) {
        verificationFailed = true;
        return;
      }

      applicationCount += 1;
      let localChange = false;
      const desired = {
        duration: settings.duration,
        ratio: settings.ratio,
        model: settings.model,
        resolution: settings.resolution,
      };
      Object.keys(desired).forEach(function (parameter) {
        const target = desired[parameter];
        if (target === "") return;
        if (params[parameter] === target) return;
        params[parameter] = target;
        localChange = true;
        mutationCount += 1;
      });

      const exact = params.duration === settings.duration &&
        (!settings.ratio || params.ratio === settings.ratio) &&
        (!settings.model || params.model === settings.model) &&
        (!settings.resolution || params.resolution === settings.resolution);
      if (!exact) verificationFailed = true;
      if (!localChange) return;
      container[key] = typeof original === "string" ? nativeJsonStringify(params) : params;
      changed = true;
    }

    function visit(node) {
      if (!node || typeof node !== "object") return;

      const hasAbilityParam = Object.prototype.hasOwnProperty.call(node, "ability_param");
      const hasAbilityParams = Object.prototype.hasOwnProperty.call(node, "abilityParams");
      if (Number(node.ability_type) === 17 && (hasAbilityParam || hasAbilityParams)) {
        generationPayload = true;
        if (hasAbilityParam) setGenerationSettings(node, "ability_param");
        if (hasAbilityParams) setGenerationSettings(node, "abilityParams");
      }

      Object.keys(node).forEach(function (key) {
        const child = node[key];
        // Current Dola builds message.ext.chat_ability as a JSON string whose
        // ability_param is another JSON string. Parse only this named field;
        // arbitrary strings and unrelated JSON remain untouched.
        if ((key === "chat_ability" || key === "chatAbility") && typeof child === "string") {
          const parsedAbility = parseObject(child);
          if (!parsedAbility) return;
          const mutationsBefore = mutationCount;
          visit(parsedAbility);
          if (mutationCount > mutationsBefore) node[key] = nativeJsonStringify(parsedAbility);
          return;
        }
        if (child && typeof child === "object") visit(child);
      });
    }

    visit(body);
    return {
      bodyText: changed ? nativeJsonStringify(body) : bodyText,
      changed: changed && generationPayload,
      matched: generationPayload,
      applied: generationPayload && applicationCount > 0 && !verificationFailed,
      seconds: seconds,
      settings: settings,
    };
  }

  function unsupportedDurationResponse(text, requestedSeconds) {
    const requested = secondsValue(requestedSeconds);
    const normalized = String(text || "").replace(/\s+/g, " ").trim();
    const refusal = /(?:not\s+support(?:ed)?|unsupported|cannot|can't|unable).{0,80}(?:duration|seconds?|\d+\s*s\b)|(?:duration|longer\s+than|\d+\s*s\b).{0,80}(?:not\s+support(?:ed)?|unsupported|cannot|can't|unable)|(?:maximum|max(?:imum)?\s+duration|only\s+supports?).{0,40}\d+\s*(?:s|seconds?)/i.test(normalized);
    if (!refusal) return { unsupported: false, requestedSeconds: requested, offeredSeconds: 0 };

    const offerMatch = normalized.match(/(?:continue|generate|use|try|shorten|instead|maximum|max(?:imum)?|only\s+supports?)[^\d]{0,40}(\d+)\s*(?:s|seconds?)\b/i);
    const offered = offerMatch ? secondsValue(offerMatch[1]) : 0;
    return {
      unsupported: true,
      requestedSeconds: requested,
      offeredSeconds: offered && (!requested || offered < requested) ? offered : 0,
      text: normalized,
    };
  }

  function shouldMaskTransientLogout(status, url, flowLogin, agwLogin) {
    // Authentication response fields belong to Dola. They are inspected for
    // diagnostics only and are never hidden or rewritten by this extension.
    return false;
  }

  function responseLoginDetails(response, url) {
    let flowLogin = null;
    let agwLogin = null;
    try {
      if (response && response.headers && typeof response.headers.get === "function") {
        flowLogin = response.headers.get("x-tt-flow-login");
        agwLogin = response.headers.get("x-tt-agw-login");
      }
    } catch (_) {}
    return {
      status: Number(response && response.status) || 0,
      flowLogin: flowLogin,
      agwLogin: agwLogin,
      url: String(url || ""),
      logoutSuppressed: false
    };
  }

  function protectTransientLogoutResponse(response, url) {
    const details = responseLoginDetails(response, url);
    return { response: response, details: details };
  }

  function neutralizeLegacyApi(api) {
    if (!api || typeof api !== "object" || api.__dolaForceDurationVersion === "1.10.13") return false;
    const originalDisable = typeof api.disable === "function" ? api.disable : null;

    function lockDisabled() {
      try { if (originalDisable) originalDisable.call(api); } catch (_) {}
      try {
        if (api._state && typeof api._state === "object") {
          api._state.enabled = false;
          api._state.duration = 0;
        }
      } catch (_) {}
      return 0;
    }

    lockDisabled();
    try { api.set = lockDisabled; } catch (_) {}
    try { api.apply = function () { lockDisabled(); return Promise.resolve(false); }; } catch (_) {}
    try { api.enabled = function () { return false; }; } catch (_) {}
    return true;
  }

  let installed = false;
  let originalStringify = null;
  let installedStringify = null;
  let originalFetch = null;
  let originalOpen = null;
  let originalSend = null;

  /**
   * Install in the page MAIN world. getSettings is called immediately before
   * every recognized generation request is patched.
   */
  function install(getSettings, onPatched, onResponse) {
    if (installed || !root) return false;
    const readSettings = typeof getSettings === "function" ? getSettings : function () { return getSettings; };
    const notify = typeof onPatched === "function" ? onPatched : function () {};
    const notifyResponse = typeof onResponse === "function" ? onResponse : function () {};
    let requestSequence = 0;

    function nextRequestId() {
      requestSequence += 1;
      return "dola-generation-" + Date.now().toString(36) + "-" + requestSequence.toString(36);
    }

    function patch(bodyText, details, requestedSettings) {
      const selected = requestedSettings === undefined ? readSettings() : requestedSettings;
      const patched = patchPayload(bodyText, selected);
      if (patched.matched || details && details.finalRequest) notify(patched, details || {});
      return patched;
    }

    function settingsError(requestId) {
      const error = new Error("Dola generation was blocked because the selected settings were not present in this exact request.");
      error.code = "DOLA_SETTINGS_NOT_APPLIED";
      error.requestId = requestId;
      return error;
    }

    function notifyNetworkError(error, meta) {
      notifyResponse({
        status: 0,
        flowLogin: null,
        agwLogin: null,
        url: String(meta.url || ""),
        logoutSuppressed: false,
        requestedSeconds: meta.requested.duration,
        requestedSettings: meta.requested,
        forceApplied: meta.forceApplied,
        requestId: meta.requestId,
        error: String(error && error.message || error)
      }, { transport: meta.transport, url: meta.url, requestId: meta.requestId });
    }

    function observeResponse(response, meta) {
      const details = responseLoginDetails(response, meta.url);
      details.requestedSeconds = meta.requested.duration;
      details.requestedSettings = meta.requested;
      details.forceApplied = meta.requested.enabled ? meta.forceApplied === true : null;
      details.requestId = meta.requestId;
      notifyResponse(details, { transport: meta.transport, url: meta.url, requestId: meta.requestId });

      // Inspect a clone so Dola receives the original response body untouched.
      try {
        if (response && typeof response.clone === "function") {
          Promise.resolve(response.clone().text()).then(function (text) {
            if (!text) return;
            notifyResponse(Object.assign({}, details, {
              bodyInspection: true,
              responseText: String(text).slice(0, 250000)
            }), { transport: meta.transport, url: meta.url, requestId: meta.requestId, bodyInspection: true });
          }).catch(function () {});
        }
      } catch (_) {}
      return response;
    }

    function sendFetch(receiver, input, init, meta) {
      return Promise.resolve(originalFetch.call(receiver, input, init)).then(function (response) {
        return observeResponse(response, meta);
      }, function (error) {
        notifyNetworkError(error, meta);
        throw error;
      });
    }

    // Dola currently serializes {ability_type: 17, ability_param: "..."}
    // before its request/authentication layer runs. Updating that one exact
    // serialization point lets the request layer sign and submit the final
    // body, without rebuilding Request objects or touching session data.
    if (root.JSON && typeof root.JSON.stringify === "function") {
      originalStringify = root.JSON.stringify;
      installedStringify = function (value, replacer, space) {
        const serialized = originalStringify.apply(this, arguments);
        const hasSettings = value && typeof value === "object" &&
          (Object.prototype.hasOwnProperty.call(value, "ability_param") ||
           Object.prototype.hasOwnProperty.call(value, "abilityParams"));
        if (!hasSettings || Number(value.ability_type) !== 17 || typeof serialized !== "string") {
          return serialized;
        }
        const patched = patch(serialized, {
          transport: "Dola ability serialization",
          preflight: true,
          url: root.location && root.location.pathname || ""
        });
        return patched.matched ? patched.bodyText : serialized;
      };
      root.JSON.stringify = installedStringify;
    }

    if (typeof root.fetch === "function") {
      originalFetch = root.fetch;
      root.fetch = function (input, init) {
        const receiver = this;
        const url = requestUrl(input);
        if (!generationRequestUrl(url)) return originalFetch.call(receiver, input, init);
        const requestId = nextRequestId();
        const requested = normalizeSettings(readSettings());
        const nextInit = init ? Object.assign({}, init) : {};
        const meta = { requestId: requestId, requested: requested, forceApplied: !requested.enabled, transport: "fetch", url: url };

        if (typeof nextInit.body === "string") {
          const audited = patchPayload(nextInit.body, requested);
          const exact = audited.applied && !audited.changed;
          const finalResult = Object.assign({}, audited, { applied: exact, changed: false });
          notify(finalResult, { transport: "fetch audit", url: url, requestId: requestId, finalRequest: true });
          meta.forceApplied = requested.enabled ? exact : null;
          // Never rewrite the body at the final network boundary. Dola may
          // already have signed it; changing it here can invalidate the
          // authenticated session and redirect the user to from_logout=1.
          if (requested.enabled && !exact) return Promise.reject(settingsError(requestId));
          return sendFetch(receiver, input, init, meta);
        }

        const isRequest = root.Request && input instanceof root.Request;
        const method = String(nextInit.method || isRequest && input.method || "GET").toUpperCase();
        if (requested.enabled && isRequest && method !== "GET" && method !== "HEAD") {
          // Read a clone for verification, then send the original Request object
          // unchanged. This preserves Dola's headers, credentials and signature.
          return Promise.resolve(input.clone().text()).then(function (bodyText) {
            const audited = patchPayload(bodyText, requested);
            const exact = audited.applied && !audited.changed;
            const finalResult = Object.assign({}, audited, { applied: exact, changed: false });
            notify(finalResult, { transport: "fetch Request audit", url: url, requestId: requestId, finalRequest: true });
            meta.forceApplied = exact;
            if (!exact) throw settingsError(requestId);
            return sendFetch(receiver, input, init, meta);
          }, function (error) {
            notifyNetworkError(error, meta);
            throw error;
          });
        }

        if (requested.enabled && method !== "GET" && method !== "HEAD") {
          notify({ bodyText: nextInit.body, changed: false, matched: false, applied: false, settings: requested, seconds: requested.duration },
            { transport: "fetch", url: url, requestId: requestId, finalRequest: true });
          return Promise.reject(settingsError(requestId));
        }

        return sendFetch(receiver, input, init, meta);
      };
    }

    if (root.XMLHttpRequest && root.XMLHttpRequest.prototype) {
      const proto = root.XMLHttpRequest.prototype;
      originalOpen = proto.open;
      originalSend = proto.send;
      proto.open = function (method, url) {
        this.__dolaDurationMethod = method;
        this.__dolaDurationUrl = url;
        return originalOpen.apply(this, arguments);
      };
      proto.send = function (body) {
        const url = this.__dolaDurationUrl || "";
        const generationRequest = generationRequestUrl(url);
        const requestId = generationRequest ? nextRequestId() : "";
        const requested = generationRequest ? normalizeSettings(readSettings()) : normalizeSettings(0);
        let directlyApplied = false;
        if (generationRequest && typeof body === "string") {
          const audited = patchPayload(body, requested);
          directlyApplied = audited.applied && !audited.changed;
          const finalResult = Object.assign({}, audited, { applied: directlyApplied, changed: false });
          notify(finalResult, { transport: "XMLHttpRequest audit", url: url, requestId: requestId, finalRequest: true });
          if (requested.enabled && !directlyApplied) throw settingsError(requestId);
        } else if (generationRequest && requested.enabled) {
          notify({ bodyText: body, changed: false, matched: false, applied: false, settings: requested, seconds: requested.duration },
            { transport: "XMLHttpRequest", url: url, requestId: requestId, finalRequest: true });
          throw settingsError(requestId);
        }
        if (generationRequest && typeof this.addEventListener === "function") {
          const xhr = this;
          this.addEventListener("loadend", function () {
            let flowLogin = null;
            let agwLogin = null;
            let responseText = "";
            try {
              flowLogin = xhr.getResponseHeader("x-tt-flow-login");
              agwLogin = xhr.getResponseHeader("x-tt-agw-login");
            } catch (_) {}
            try {
              if (typeof xhr.responseText === "string") responseText = xhr.responseText.slice(0, 250000);
            } catch (_) {}
            notifyResponse({
              status: Number(xhr.status) || 0,
              flowLogin: flowLogin,
              agwLogin: agwLogin,
              url: String(url),
              logoutSuppressed: false,
              requestedSeconds: requested.duration,
              requestedSettings: requested,
              forceApplied: requested.enabled ? directlyApplied : null,
              requestId: requestId,
              responseText: responseText
            }, { transport: "XMLHttpRequest", url: url, requestId: requestId });
          }, { once: true });
        }
        return originalSend.call(this, body);
      };
    }

    installed = true;
    return true;
  }

  function uninstall() {
    if (!installed || !root) return false;
    if (root.JSON && installedStringify && root.JSON.stringify === installedStringify) root.JSON.stringify = originalStringify;
    if (originalFetch) root.fetch = originalFetch;
    if (root.XMLHttpRequest && root.XMLHttpRequest.prototype) {
      if (originalOpen) root.XMLHttpRequest.prototype.open = originalOpen;
      if (originalSend) root.XMLHttpRequest.prototype.send = originalSend;
    }
    installed = false;
    originalStringify = installedStringify = originalFetch = originalOpen = originalSend = null;
    return true;
  }

  return { secondsValue, selectedSeconds, normalizeSettings, settingsSignature, generationRequestUrl, requestUrl, patchPayload, unsupportedDurationResponse, shouldMaskTransientLogout, protectTransientLogoutResponse, neutralizeLegacyApi, install, uninstall };
});
