(function () {
  "use strict";

  if (window.__dolaForceDurationBridgeVersion === "1.10.13") return;
  window.__dolaForceDurationBridge = true;
  window.__dolaForceDurationBridgeVersion = "1.10.13";

  var engine = window.DolaForceDuration;
  if (!engine) {
    console.error("[Dola ForceDuration] MAIN-world module was not loaded.");
    return;
  }

  // If another unpacked copy injected an older engine first, permanently
  // disarm its settings API before installing the current safe hook.
  var legacyHookNeutralized = engine.neutralizeLegacyApi(window.__dolaForceDuration);
  window.__dolaForceDurationSubmit = true;

  var state = { enabled: false, duration: 0, ratio: "", model: "", resolution: "" };
  var refusalWatch = { active: false, baseline: "", lastSignature: "" };

  function wait(milliseconds) {
    return new Promise(function (resolve) { setTimeout(resolve, milliseconds); });
  }

  function post(type, details) {
    try { window.postMessage(Object.assign({ type: type, at: Date.now() }, details || {}), "*"); }
    catch (error) {}
  }

  function bodyText() {
    return String(document.body && document.body.innerText || "");
  }

  function startRefusalWatch() {
    refusalWatch.active = true;
    refusalWatch.baseline = bodyText();
    refusalWatch.lastSignature = "";
  }

  function modelLabel(value) {
    if (value === "seedance_v2.5") return "Dreamina Seedance 2.5";
    if (value === "seedance_v2.0") return "Seedance 2.0";
    return value || "";
  }

  function settingsDescription(settings) {
    var selected = settings || {};
    var parts = [];
    if (Number(selected.duration) > 0) parts.push(Number(selected.duration) + "s");
    if (selected.ratio) parts.push(selected.ratio);
    if (selected.resolution) parts.push(selected.resolution);
    if (selected.model) parts.push(modelLabel(selected.model));
    return parts.join(", ");
  }

  function onPatched(result, details) {
    var transport = details && details.transport || "request";
    var selected = result.settings || state;
    var summary = settingsDescription(selected);
    var preflight = !!(details && details.preflight);
    var finalRequest = !!(details && details.finalRequest);
    var requestId = details && details.requestId || "";
    var message = !result.applied
      ? "Prompt FAILED: the selected generation settings could not be applied to Dola's video request."
      : result.changed
        ? summary + " injected into the Dola generation request (" + transport + ")."
        : "Dola generation request already contains the exact selected settings: " + summary + ".";
    if (preflight && !finalRequest) {
      post("DOLA_FD_PREFLIGHT", {
        status: result.applied ? "running" : "failed",
        settings: selected,
        message: result.applied ? "Prepared Dola video settings before request signing: " + summary + "." : message,
        url: details && details.url || location.pathname
      });
      console.log("[Dola ForceDuration]", message);
      return;
    }
    post("DOLA_FD_GEN_SEEN", { requestId: requestId, settings: selected });
    post("DOLA_FD_FORCE_RESULT", {
      status: result.applied ? "success" : "failed",
      requestId: requestId,
      finalRequest: finalRequest,
      duration: result.seconds,
      ratio: selected.ratio || "",
      model: selected.model || "",
      resolution: selected.resolution || "",
      settings: selected,
      transport: transport,
      preflight: preflight,
      message: message,
      url: details && details.url || location.pathname
    });
    if (!result.applied) {
      post("DOLA_FD_GENERATION_REJECTED", {
        status: "failed",
        requestId: requestId,
        settingsMissed: true,
        durationMissed: true,
        message: message,
        url: details && details.url || location.pathname
      });
    }
    if (finalRequest && result.applied) startRefusalWatch();
    console.log("[Dola ForceDuration]", message);
  }

  function onGenerationResponse(result, details) {
    var transport = details && details.transport || "request";
    var statusCode = Number(result && result.status) || 0;
    var requestId = result && result.requestId || details && details.requestId || "";
    var loginRejected = String(result && result.flowLogin) === "0" || String(result && result.agwLogin) === "0";
    var requested = result && result.requestedSettings || state;
    if (result && result.bodyInspection) {
      var refusal = engine.unsupportedDurationResponse(result.responseText, requested.duration);
      if (refusal.unsupported) {
        var refusalMessage = "Prompt FAILED: Dola refused " + requested.duration + "s" +
          (refusal.offeredSeconds ? " and offered " + refusal.offeredSeconds + "s" : "") +
          ". Shorter generation was not accepted.";
        post("DOLA_FD_DURATION_REFUSED", {
          status: "failed",
          requestId: requestId,
          requestedSeconds: requested.duration,
          offeredSeconds: refusal.offeredSeconds,
          message: refusalMessage,
          url: details && details.url || location.pathname
        });
        post("DOLA_FD_GENERATION_REJECTED", {
          status: "failed",
          requestId: requestId,
          durationMissed: true,
          requestedSeconds: requested.duration,
          requestedSettings: requested,
          message: refusalMessage,
          url: details && details.url || location.pathname
        });
        console.log("[Dola ForceDuration]", refusalMessage);
      }
      return;
    }
    var settingsMissed = requested.enabled && result && result.forceApplied === false;
    var durationMissed = settingsMissed;
    var failed = statusCode === 0 || statusCode >= 400 || loginRejected || settingsMissed;
    var message;
    if (settingsMissed) {
      message = "Prompt FAILED: the Dola generation request did not contain the selected settings (" + settingsDescription(requested) + "). A false success was blocked.";
    } else if (statusCode === 429) {
      message = "Prompt FAILED: Dola returned HTTP 429/high demand. The prompt was not resubmitted.";
    } else if (loginRejected) {
      message = "Dola rejected the current login on the generation response (HTTP " + statusCode + ").";
    } else if (statusCode === 0) {
      message = "Prompt FAILED: the Dola generation request had a network error.";
    } else {
      message = "Dola generation response: HTTP " + statusCode + " (" + transport + ").";
    }
    post("DOLA_FD_GEN_SEEN", { requestId: requestId, settings: requested });
    post("DOLA_FD_GENERATION_RESPONSE", {
      status: failed ? "failed" : "response",
      requestId: requestId,
      statusCode: statusCode,
      logoutSuppressed: !!(result && result.logoutSuppressed),
      loginRejected: loginRejected,
      durationMissed: durationMissed,
      settingsMissed: settingsMissed,
      requestedSeconds: Number(result && result.requestedSeconds) || 0,
      requestedSettings: requested,
      message: message,
      url: details && details.url || location.pathname
    });
    if (failed) {
      post("DOLA_FD_GENERATION_REJECTED", {
        status: "failed",
        requestId: requestId,
        statusCode: statusCode,
        logoutSuppressed: !!(result && result.logoutSuppressed),
        loginRejected: loginRejected,
        durationMissed: durationMissed,
        settingsMissed: settingsMissed,
        requestedSeconds: Number(result && result.requestedSeconds) || 0,
        requestedSettings: requested,
        message: message,
        url: details && details.url || location.pathname
      });
    }
    console.log("[Dola ForceDuration]", message);
  }

  function scanForRefusal() {
    if (!refusalWatch.active || !state.enabled || !state.duration) return;
    var current = bodyText();
    if (!current || current === refusalWatch.baseline) return;
    var candidate = current.indexOf(refusalWatch.baseline) === 0
      ? current.slice(refusalWatch.baseline.length)
      : current;
    var result = engine.unsupportedDurationResponse(candidate, state.duration);
    if (!result.unsupported) return;
    var signature = state.duration + "|" + result.offeredSeconds + "|" + result.text.slice(-300);
    if (signature === refusalWatch.lastSignature) return;
    refusalWatch.lastSignature = signature;
    refusalWatch.active = false;
    post("DOLA_FD_DURATION_REFUSED", {
      status: "failed",
      requestedSeconds: state.duration,
      offeredSeconds: result.offeredSeconds,
      message: "Prompt FAILED: Dola refused " + state.duration + "s" + (result.offeredSeconds ? " and offered " + result.offeredSeconds + "s" : "") + ". Shorter generation was not accepted."
    });
  }

  function installRefusalObserver() {
    if (!document.body) { setTimeout(installRefusalObserver, 200); return; }
    var timer = null;
    new MutationObserver(function () {
      clearTimeout(timer);
      timer = setTimeout(scanForRefusal, 250);
    }).observe(document.body, { childList: true, subtree: true, characterData: true });
  }

  function isVisible(node) {
    if (!node) return false;
    var rect = node.getBoundingClientRect();
    var style = getComputedStyle(node);
    return rect.width > 0 && rect.height > 0 && style.visibility !== "hidden" && style.display !== "none";
  }

  function label(node) {
    return String(node && (node.textContent || node.getAttribute("aria-label") || node.title) || "").trim();
  }

  function activate(node) {
    if (!node) return;
    try { node.focus(); } catch (error) {}
    ["pointerdown", "mousedown", "mouseup", "click"].forEach(function (type) {
      try {
        var EventType = type.indexOf("pointer") >= 0 && window.PointerEvent ? PointerEvent : MouseEvent;
        node.dispatchEvent(new EventType(type, { bubbles: true, cancelable: true, button: 0, view: window }));
      } catch (error) {}
    });
    try { node.click(); } catch (error) {}
  }

  function durationFromLabel(value) {
    var match = String(value || "").match(/(\d+)\s*s(?:ec(?:onds?)?)?\b/i);
    return match ? Number(match[1]) : NaN;
  }

  function durationControls() {
    return Array.from(document.querySelectorAll("button,[role=button],[role=combobox]"))
      .filter(isVisible)
      .filter(function (node) { var text = label(node); return /\d+\s*s/i.test(text) && text.length <= 12; });
  }

  async function setChip(value) {
    var duration = engine.secondsValue(value) || state.duration;
    if (!duration) return false;
    var controls = durationControls();
    if (controls.some(function (node) { return durationFromLabel(label(node)) === duration; })) return true;
    if (controls.length) { activate(controls[0]); await wait(350); }

    var exact = new RegExp("^\\s*" + duration + "\\s*s(?:ec(?:onds?)?)?\\s*$", "i");
    var target = Array.from(document.querySelectorAll("button,[role=button],[role=option],[role=menuitem],div,span,li"))
      .filter(isVisible)
      .find(function (node) {
        var rect = node.getBoundingClientRect();
        return exact.test(label(node).replace(/\s+/g, " ").trim()) && rect.width * rect.height > 0 && rect.width * rect.height < 20000;
      });
    if (target) { activate(target); await wait(400); return true; }

    var input = Array.from(document.querySelectorAll("input[type=number],input[inputmode=numeric],input[type=text],input[type=range]"))
      .filter(isVisible)
      .find(function (node) {
        var hint = (node.placeholder || "") + " " + (node.getAttribute("aria-label") || "") + " " + (node.name || "") + " " + (node.id || "");
        return /sec|dur|length|\bs\b/i.test(hint) || node.type === "range" || node.type === "number";
      });
    if (!input) return false;
    var descriptor = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(input), "value");
    if (descriptor && descriptor.set) descriptor.set.call(input, String(duration));
    else input.value = String(duration);
    input.dispatchEvent(new Event("input", { bubbles: true }));
    input.dispatchEvent(new Event("change", { bubbles: true }));
    try { input.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", bubbles: true })); } catch (error) {}
    await wait(300);
    return true;
  }

  engine.install(function () {
    return state.enabled ? Object.assign({}, state) : 0;
  }, onPatched, onGenerationResponse);

  var publicApi = {
    __dolaForceDurationVersion: "1.10.13",
    set: function (duration, extra) {
      var parsed = engine.secondsValue(duration);
      if (!parsed) return state.duration;
      state.duration = parsed;
      state.enabled = true;
      if (extra && typeof extra === "object") {
        var next = engine.normalizeSettings(Object.assign({}, state, extra, { duration: parsed, enabled: true }));
        state.ratio = next.ratio;
        state.model = next.model;
        state.resolution = next.resolution;
      }
      return parsed;
    },
    get: function () { return state.duration; },
    enabled: function () { return state.enabled; },
    setChip: setChip,
    apply: async function (duration, extra) { publicApi.set(duration, extra); return setChip(duration); },
    disable: function () { state.enabled = false; },
    cost: function () {
      var multiplier = state.model === "seedance_v2.5" ? 2 : 1;
      return Math.max(multiplier, Math.ceil((state.duration || 10) / 5) * multiplier);
    },
    _state: state
  };
  window.__dolaForceDuration = publicApi;

  window.addEventListener("message", function (event) {
    if (event.source !== window || event.origin !== location.origin) return;
    var message = event && event.data;
    if (!message || typeof message !== "object") return;
    if (message.type === "DOLA_FORCE_DURATION_SETTINGS") {
      var settings = message.settings;
      if (!settings || typeof settings !== "object") return;
      var selected = engine.normalizeSettings(settings);
      state.enabled = selected.enabled;
      state.duration = selected.duration;
      state.ratio = selected.ratio;
      state.model = selected.model;
      state.resolution = selected.resolution;
      console.log("[Dola ForceDuration]", state.enabled ? "armed for each generation: " + settingsDescription(state) : "disabled");
    } else if (message.type === "DOLA_FORCE_DURATION_APPLY_CHIP") {
      setChip(state.duration);
    }
  });

  installRefusalObserver();
  post("DOLA_FD_FORCE_READY", {
    status: "running",
    message: "v1.10.13 MAIN video-settings hook ready; each final generation request is verified and account/session data is unchanged." +
      (legacyHookNeutralized ? " A legacy duplicate hook was detected and neutralized." : "")
  });
  console.log("[Dola ForceDuration] MAIN-world bridge ready");
}());
