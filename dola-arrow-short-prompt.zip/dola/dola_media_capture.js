(function () {
  "use strict";

  if (window.__dolaFDMediaCapture) return;
  window.__dolaFDMediaCapture = true;

  var previousFetch = window.fetch;
  var records = [];

  function requestUrl(input) {
    if (typeof input === "string") return input;
    if (typeof URL === "function" && input instanceof URL) return input.href;
    return input && input.url || "";
  }

  function isMediaMetadataUrl(value) {
    return /\/(?:im\/chain\/recent_conv|samantha\/(?:video|media)\/get_play_info|alice\/upload\/refresh_file_url)(?:[/?#]|$)/i.test(String(value || ""));
  }

  function post(record) {
    try {
      window.postMessage({
        type: "DOLA_FD_MEDIA_METADATA",
        at: record.at,
        url: record.url,
        responseText: record.responseText
      }, "*");
    } catch (_) {}
  }

  function capture(response, url) {
    try {
      if (!response || typeof response.clone !== "function") return;
      Promise.resolve(response.clone().text()).then(function (text) {
        if (!text) return;
        var record = {
          at: Date.now(),
          url: String(url || ""),
          responseText: String(text).slice(0, 2000000)
        };
        records.push(record);
        records = records.slice(-8);
        post(record);
      }).catch(function () {});
    } catch (_) {}
  }

  function captureText(text, url) {
    if (!text) return;
    var record = {
      at: Date.now(),
      url: String(url || ""),
      responseText: String(text).slice(0, 2000000)
    };
    records.push(record);
    records = records.slice(-12);
    post(record);
  }

  if (typeof previousFetch === "function") {
    window.fetch = function (input, init) {
      var receiver = this;
      var url = requestUrl(input);
      var result = previousFetch.call(receiver, input, init);
      if (!isMediaMetadataUrl(url)) return result;
      return Promise.resolve(result).then(function (response) {
        capture(response, url);
        return response;
      });
    };
  }

  // Recent Dola builds request play information with XMLHttpRequest rather
  // than fetch. Observe the completed response without changing the request,
  // its headers, credentials, body, or the response returned to Dola.
  if (window.XMLHttpRequest && window.XMLHttpRequest.prototype) {
    var xhrOpen = window.XMLHttpRequest.prototype.open;
    var xhrSend = window.XMLHttpRequest.prototype.send;
    window.XMLHttpRequest.prototype.open = function (method, url) {
      this.__dolaFDMediaUrl = String(url || "");
      return xhrOpen.apply(this, arguments);
    };
    window.XMLHttpRequest.prototype.send = function () {
      var xhr = this;
      var url = xhr.__dolaFDMediaUrl || "";
      if (isMediaMetadataUrl(url)) {
        xhr.addEventListener("loadend", function () {
          try {
            var text = "";
            if (!xhr.responseType || xhr.responseType === "text") text = xhr.responseText;
            else if (xhr.responseType === "json" && xhr.response != null) text = JSON.stringify(xhr.response);
            captureText(text, xhr.responseURL || url);
          } catch (_) {}
        }, { once: true });
      }
      return xhrSend.apply(this, arguments);
    };
  }

  window.addEventListener("message", function (event) {
    if (event.source !== window || event.origin !== location.origin) return;
    var message = event && event.data;
    if (!message || message.type !== "DOLA_FD_MEDIA_METADATA_REQUEST") return;
    records.forEach(post);
  });
}());
