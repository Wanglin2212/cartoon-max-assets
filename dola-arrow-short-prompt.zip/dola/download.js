(function () {
  "use strict";

  if (window.top !== window || window.__dolaFDDownload) return;
  window.__dolaFDDownload = true;

  var api = typeof browser !== "undefined" ? browser : chrome;
  var AUDIT_KEY = "dolaPendingDurationAudits";
  var LOG_KEY = "dolaWorkflowDiagnosticLog";
  var durationAudit = globalThis.DolaVideoDurationAudit;
  var downloadPolicy = globalThis.DolaVideoDownloadPolicy;
  var audits = [];
  var autoDownload = false;
  var scanTimer = null;
  var busy = false;
  var mediaMetadataRecords = [];

  function wait(milliseconds) {
    return new Promise(function (resolve) { setTimeout(resolve, milliseconds); });
  }

  function isHttpUrl(value) {
    try { return /^https?:$/i.test(new URL(String(value), location.href).protocol); }
    catch (_) { return false; }
  }

  function absoluteUrl(value) {
    try { return new URL(String(value), location.href).href; }
    catch (_) { return ""; }
  }

  function looksLikeVideo(value) {
    var text = String(value || "");
    return /\.(?:mp4|mov|webm|m4v)(?:[?#]|$)|\/video\/tos\/|mime_type=video|play_?(?:url|addr)|download_?(?:url|addr)|\/fplay\/|[?&](?:vid|video_id)=/i.test(text);
  }

  function cleanCandidate(value, hint) {
    if (downloadPolicy) return downloadPolicy.isExplicitlyClean(value, hint);
    var field = String(hint || "").replace(/([a-z0-9])([A-Z])/g, "$1_$2").toLowerCase().trim();
    var text = String(value || "").toLowerCase();
    if (/(?:^|[^a-z0-9])watermark(?:ed)?(?:[^a-z0-9]|$)|logo_type=(?:watermark|hd)|(?:^|[^a-z0-9])wm(?:[^a-z0-9]|$)/.test(field + " " + text) &&
        !/(?:^|[^a-z0-9])(?:unwatermarked|no[_-]?watermark|without[_-]?watermark)(?:[^a-z0-9]|$)|logo_type=unwatermarked/.test(field + " " + text)) return false;
    var exactField = /^(?:unwatermarked|no_watermark|without_watermark)(?:_(?:url|addr|uri|src))?$/.test(field) ||
      /^(?:origin|original|source|raw|material|play)(?:_(?:url|addr|uri|src))$/.test(field);
    try {
      var parsed = new URL(text, "https://dola.invalid/");
      text = parsed.pathname + parsed.search;
    } catch (_) {}
    return exactField || /(?:^|[^a-z0-9])(?:unwatermarked|no[_-]?watermark|without[_-]?watermark|origin|original|source|raw|material|fplay)(?:[^a-z0-9]|$)/.test(text);
  }

  function cleanPreferred(value) {
    return cleanCandidate(value, "");
  }

  function explicitlyWatermarked(value, hint) {
    if (downloadPolicy) return downloadPolicy.isExplicitlyWatermarked(value, hint);
    var text = (String(hint || "") + " " + String(value || "")).toLowerCase();
    return /(?:^|[^a-z])watermark(?:ed)?(?:[^a-z]|$)|logo_type=(?:watermark|hd)|download_addr|\bwm\b/.test(text) &&
      !/unwatermarked|no_?watermark|without.?watermark|logo_type=unwatermarked/.test(text);
  }

  function mediaKey(value) {
    try {
      var url = new URL(String(value), location.href);
      var vid = url.searchParams.get("vid") || url.searchParams.get("video_id") || "";
      if (vid) return "vid:" + vid;
      var tos = url.pathname.match(/\/video\/tos\/[^?#]+/i);
      return tos ? tos[0].toLowerCase() : (url.origin + url.pathname).toLowerCase();
    } catch (_) { return String(value || "").split("?")[0].toLowerCase(); }
  }

  function childHint(parent, child) {
    return parent ? parent + "." + child : String(child || "");
  }

  function extractUrls(value, rootHint) {
    var found = new Map();
    function add(candidate, hint) {
      var url = absoluteUrl(String(candidate || "").replace(/\\u002f/gi, "/").replace(/\\\//g, "/").replace(/&amp;/g, "&"));
      if (!url || !isHttpUrl(url) || (!looksLikeVideo(url) && !cleanCandidate(url, hint))) return;
      var key = mediaKey(url);
      var current = found.get(key);
      if (!current || (!cleanPreferred(current) && cleanPreferred(url))) found.set(key, url);
    }
    function visit(node, hint) {
      if (typeof node === "string") {
        var matches = node.match(/https?:\/\/[^\s"'\\<>()]+/gi) || [];
        matches.forEach(function (url) { add(url, hint); });
        var trimmed = node.trim();
        if ((trimmed[0] === "{" || trimmed[0] === "[") && trimmed.length < 2000000) {
          try { visit(JSON.parse(trimmed), hint); } catch (_) {}
        }
      } else if (Array.isArray(node)) {
        node.forEach(function (item, index) { visit(item, childHint(hint, index)); });
      } else if (node && typeof node === "object") {
        Object.keys(node).forEach(function (key) { visit(node[key], childHint(hint, key)); });
      }
    }
    try { visit(typeof value === "string" ? JSON.parse(value) : value, rootHint || ""); } catch (_) { visit(String(value || ""), rootHint || ""); }
    visit(String(value || "").replace(/\\u002f/gi, "/").replace(/\\\//g, "/"), rootHint || "");
    return Array.from(found.values()).sort(function (left, right) {
      return Number(cleanPreferred(right)) - Number(cleanPreferred(left));
    });
  }

  function extractCleanUrls(value, rootHint) {
    var found = new Map();
    function add(candidate, hint) {
      var url = absoluteUrl(String(candidate || "").replace(/\\u002f/gi, "/").replace(/\\\//g, "/").replace(/&amp;/g, "&"));
      if (!url || !isHttpUrl(url) || !looksLikeVideo(url) || explicitlyWatermarked(url, hint)) return;
      if (!cleanCandidate(url, hint)) return;
      found.set(mediaKey(url), url);
    }
    function visit(node, hint) {
      if (typeof node === "string") {
        var matches = node.match(/https?:\/\/[^\s"'\\<>()]+/gi) || [];
        matches.forEach(function (url) { add(url, hint); });
        var trimmed = node.trim();
        if ((trimmed[0] === "{" || trimmed[0] === "[") && trimmed.length < 2000000) {
          try { visit(JSON.parse(trimmed), hint); } catch (_) {}
        }
      } else if (Array.isArray(node)) {
        node.forEach(function (item, index) { visit(item, childHint(hint, index)); });
      } else if (node && typeof node === "object") {
        Object.keys(node).forEach(function (key) { visit(node[key], childHint(hint, key)); });
      }
    }
    try { visit(typeof value === "string" ? JSON.parse(value) : value, rootHint || ""); }
    catch (_) { visit(String(value || ""), rootHint || ""); }
    return Array.from(found.values());
  }

  function metadataGroups(value) {
    var groups = [];
    function unique(values) {
      var map = new Map();
      values.forEach(function (url) { map.set(mediaKey(url), url); });
      return Array.from(map.values());
    }
    function walk(node, hint) {
      var urls = [];
      var clean = [];
      if (typeof node === "string") {
        urls = extractUrls(node, hint);
        clean = extractCleanUrls(node, hint);
        var trimmed = node.trim();
        if ((trimmed[0] === "{" || trimmed[0] === "[") && trimmed.length < 2000000) {
          try {
            var nested = walk(JSON.parse(trimmed), hint);
            urls = urls.concat(nested.urls);
            clean = clean.concat(nested.clean);
          } catch (_) {}
        }
      } else if (Array.isArray(node)) {
        node.forEach(function (item, index) {
          var child = walk(item, childHint(hint, index));
          urls = urls.concat(child.urls);
          clean = clean.concat(child.clean);
        });
      } else if (node && typeof node === "object") {
        Object.keys(node).forEach(function (key) {
          var child = walk(node[key], childHint(hint, key));
          urls = urls.concat(child.urls);
          clean = clean.concat(child.clean);
        });
      }
      urls = unique(urls);
      clean = unique(clean);
      if (urls.length && clean.length && urls.length <= 24) groups.push({ urls: urls, clean: clean });
      return { urls: urls, clean: clean };
    }
    try { walk(typeof value === "string" ? JSON.parse(value) : value, ""); }
    catch (_) { walk(String(value || ""), ""); }
    return groups.sort(function (left, right) { return left.urls.length - right.urls.length; });
  }

  function sharesMediaIdentity(left, right) {
    if (mediaKey(left) === mediaKey(right)) return true;
    try {
      var a = new URL(left);
      var b = new URL(right);
      var names = ["vid", "video_id", "item_id", "file_id", "tos_key"];
      return names.some(function (name) {
        var first = a.searchParams.get(name);
        return first && first === b.searchParams.get(name);
      });
    } catch (_) { return false; }
  }

  function cachedCleanUrl(referenceUrls, allowLatest) {
    var references = referenceUrls || [];
    for (var recordIndex = mediaMetadataRecords.length - 1; recordIndex >= 0; recordIndex -= 1) {
      var record = mediaMetadataRecords[recordIndex];
      var groups = metadataGroups(record.responseText);
      for (var groupIndex = 0; groupIndex < groups.length; groupIndex += 1) {
        var group = groups[groupIndex];
        var matches = references.some(function (reference) {
          return group.urls.some(function (candidate) { return sharesMediaIdentity(reference, candidate); });
        });
        if (matches && group.clean.length) return group.clean[0];
      }
      if (allowLatest) {
        var latest = extractCleanUrls(record.responseText);
        if (latest.length) return latest[0];
      }
    }
    return "";
  }

  function allCachedCleanUrls() {
    var found = new Map();
    mediaMetadataRecords.slice().reverse().forEach(function (record) {
      extractCleanUrls(record.responseText).forEach(function (url) { found.set(mediaKey(url), url); });
    });
    return Array.from(found.values());
  }

  async function requestMetadataCache() {
    window.postMessage({ type: "DOLA_FD_MEDIA_METADATA_REQUEST" }, "*");
    await wait(350);
  }

  function videoUrls(video) {
    var values = [];
    [video.currentSrc, video.src, video.getAttribute("src")].forEach(function (value) { if (value) values.push(value); });
    video.querySelectorAll("source[src]").forEach(function (source) { values.push(source.src || source.getAttribute("src")); });
    var container = video.closest("article,[data-message-id],[class*=message],[class*=video]") || video.parentElement;
    if (container) extractUrls(container.outerHTML).forEach(function (url) { values.push(url); });
    var unique = new Map();
    values.forEach(function (value) {
      var url = absoluteUrl(value);
      if (url && isHttpUrl(url) && looksLikeVideo(url)) unique.set(mediaKey(url), url);
    });
    return Array.from(unique.values()).sort(function (left, right) {
      return Number(cleanPreferred(right)) - Number(cleanPreferred(left));
    });
  }

  function performanceUrls() {
    var entries = [];
    try { entries = performance.getEntriesByType("resource"); } catch (_) {}
    var unique = new Map();
    entries.slice().reverse().forEach(function (entry) {
      var url = absoluteUrl(entry && entry.name);
      if (url && isHttpUrl(url) && looksLikeVideo(url) && !unique.has(mediaKey(url))) unique.set(mediaKey(url), url);
    });
    return Array.from(unique.values());
  }

  async function fetchCleanPlayInfo(vid) {
    var attempts = [
      { url: "/samantha/media/get_play_info", body: { key: vid } },
      { url: "/samantha/media/get_play_info", body: { vid: vid } },
      { url: "/samantha/video/get_play_info", body: { vid: vid } }
    ];
    for (var i = 0; i < attempts.length; i += 1) {
      try {
        var response = await fetch(attempts[i].url, {
          method: "POST",
          credentials: "include",
          headers: { "accept": "application/json, text/plain, */*", "content-type": "application/json", "Agw-Js-Conv": "str" },
          body: JSON.stringify(attempts[i].body)
        });
        var urls = extractCleanUrls(await response.text());
        if (urls.length) return urls[0];
      } catch (_) {}
    }
    return "";
  }

  async function resolveMediaUrl(value, references, allowLatest) {
    var url = absoluteUrl(value);
    if (!url || !isHttpUrl(url)) throw new Error("The selected video has no downloadable URL yet.");
    var vid = "";
    try {
      var parsed = new URL(url);
      vid = parsed.searchParams.get("vid") || parsed.searchParams.get("video_id") || parsed.searchParams.get("item_id") || "";
    } catch (_) {}
    if (vid) {
      var playUrl = await fetchCleanPlayInfo(vid);
      if (playUrl) return playUrl;
    }
    if (/\/fplay\//i.test(url)) {
      try {
        var apiResponse = await fetch(url, { credentials: "same-origin" });
        var apiType = String(apiResponse.headers && apiResponse.headers.get("content-type") || "");
        if (/^video\//i.test(apiType)) return apiResponse.url || url;
        var apiUrls = extractCleanUrls(await apiResponse.text());
        if (apiUrls.length) return apiUrls[0];
      } catch (_) {}
      return url;
    }
    var expires = 0;
    try { expires = Number(new URL(url).searchParams.get("x-expires")) || 0; } catch (_) {}
    var expired = !!(expires && expires <= Date.now() / 1000 + 60);
    if (expired) {
      try {
        var refreshResponse = await fetch("/alice/upload/refresh_file_url", {
          method: "POST",
          credentials: "include",
          headers: { "accept": "application/json, text/plain, */*", "content-type": "application/json", "Agw-Js-Conv": "str" },
          body: JSON.stringify({ url: url })
        });
        var refreshText = await refreshResponse.text();
        var refreshed = extractCleanUrls(refreshText);
        if (refreshed.length) return refreshed[0];
        var ordinaryRefreshed = extractUrls(refreshText);
        if (ordinaryRefreshed.length) return ordinaryRefreshed[0];
      } catch (_) {}
    }
    var cached = cachedCleanUrl(references && references.length ? references : [url], allowLatest);
    if (cached) return cached;
    // Prefer clean/original media above, but fall back to Dola's ordinary
    // player file (which may include its logo) when no clean source exists.
    if (!expired) return url;
    if (expired) throw new Error("The clean video link expired and Dola did not provide a refreshed file. Reload the chat and retry.");
    throw new Error("Dola did not expose a downloadable video file.");
  }

  function requestDownload(urls) {
    var message = { type: "DOLA_FD_DOWNLOAD", urls: urls };
    try {
      if (typeof browser !== "undefined" && browser.runtime && browser.runtime.sendMessage) {
        return Promise.resolve(browser.runtime.sendMessage(message)).then(function (result) {
          return result || { ok: false, error: "The download service did not respond." };
        }, function (error) { return { ok: false, error: error && error.message || String(error) }; });
      }
      return new Promise(function (resolve) {
        api.runtime.sendMessage(message, function (result) {
          var error = api.runtime.lastError;
          resolve(error ? { ok: false, error: error.message } : result || { ok: false, error: "The download service did not respond." });
        });
      });
    } catch (error) {
      return Promise.resolve({ ok: false, error: error && error.message || String(error) });
    }
  }

  function toast(message) {
    if (!document.body) return;
    var node = document.getElementById("dola-fd-toast");
    if (!node) {
      node = document.createElement("div");
      node.id = "dola-fd-toast";
      document.body.appendChild(node);
    }
    node.textContent = message;
    node.classList.add("show");
    clearTimeout(node._dolaTimer);
    node._dolaTimer = setTimeout(function () { node.classList.remove("show"); }, 4000);
  }

  async function downloadUrls(urls, allowLatest, references) {
    var resolved = [];
    var seen = new Set();
    var lastError = null;
    for (var i = 0; i < urls.length; i += 1) {
      try {
        var candidateReferences = references === null ? [urls[i]] : references || urls;
        var url = await resolveMediaUrl(urls[i], candidateReferences, allowLatest);
        var key = mediaKey(url);
        if (!seen.has(key)) { seen.add(key); resolved.push(url); }
      } catch (error) { lastError = error; }
    }
    if (!resolved.length) throw lastError || new Error("No downloadable video URL was found.");
    var result = await requestDownload(resolved);
    var count = Number(result && result.count) || 0;
    if (!result || count < 1) throw new Error(result && result.error || "The browser rejected the video download.");
    if (count < resolved.length) toast("Started " + count + " of " + resolved.length + " downloads. " + (result.error || "The browser rejected the remaining files."));
    else toast("Downloading " + count + " video" + (count === 1 ? "" : "s") + "…");
    return { ok: true, count: count, requested: resolved.length, partial: count < resolved.length, error: result.error || "" };
  }

  async function downloadVideo(video) {
    if (busy) return { ok: false, reason: "busy", error: "A download is already running." };
    busy = true;
    try {
      toast("Finding this video's best available file…");
      await requestMetadataCache();
      var urls = videoUrls(video);
      if (!urls.length) throw new Error("This video has no downloadable URL yet.");
      var videos = Array.from(document.querySelectorAll("video"));
      var allowLatest = videos.length > 0 && videos[videos.length - 1] === video;
      var cached = cachedCleanUrl(urls, allowLatest);
      var candidates = cached ? [cached].concat(urls) : urls;
      return await downloadUrls(candidates, allowLatest, urls);
    } catch (error) {
      toast("Download failed: " + (error && error.message || error));
      return { ok: false, error: String(error && error.message || error) };
    } finally { busy = false; }
  }

  async function downloadLatest(all) {
    if (busy) return { ok: false, reason: "busy", error: "A download is already running." };
    busy = true;
    try {
      toast("Finding the best available video file…");
      await requestMetadataCache();
      var videos = Array.from(document.querySelectorAll("video"));
      var urls = allCachedCleanUrls();
      videos.slice().reverse().forEach(function (video) { videoUrls(video).forEach(function (url) { urls.push(url); }); });
      performanceUrls().forEach(function (url) { urls.push(url); });
      if (!urls.length) throw new Error("Open the chat containing the generated video and retry.");
      // Latest may use the most recent captured metadata as a fallback. All
      // resolves each candidate only against its own identity so distinct
      // videos cannot collapse to the same newest URL.
      return await downloadUrls(all ? urls : [urls[0]], !all, all ? null : urls);
    } catch (error) {
      toast("Download failed: " + (error && error.message || error));
      return { ok: false, count: 0, error: String(error && error.message || error) };
    } finally { busy = false; }
  }

  function setLocal(update) {
    return new Promise(function (resolve) { api.storage.local.set(update, resolve); });
  }

  function saveAudits() {
    var update = {};
    update[AUDIT_KEY] = audits.slice(-20);
    return setLocal(update);
  }

  function writeAudit(status, message) {
    var entry = { status: status, step: "duration audit", message: message, time: new Date().toISOString(), url: location.pathname };
    return new Promise(function (resolve) {
      api.storage.local.get(LOG_KEY, function (data) {
        var log = data && Array.isArray(data[LOG_KEY]) ? data[LOG_KEY].slice(-99) : [];
        log.push(entry);
        api.storage.local.set({ dolaWorkflowDiagnostic: entry, dolaWorkflowDiagnosticLog: log, dolaForceDiagnostic: entry }, resolve);
      });
    });
  }

  function currentVideoKeys() {
    var keys = [];
    document.querySelectorAll("video").forEach(function (video) {
      var urls = videoUrls(video);
      if (urls.length) keys.push(mediaKey(urls[0]));
    });
    return keys;
  }

  function videoDuration(video) {
    return new Promise(function (resolve) {
      if (Number.isFinite(video.duration) && video.duration > 0) { resolve(video.duration); return; }
      var done = false;
      function finish() {
        if (done) return;
        done = true;
        resolve(Number.isFinite(video.duration) && video.duration > 0 ? video.duration : 0);
      }
      video.addEventListener("loadedmetadata", finish, { once: true });
      setTimeout(finish, 3000);
      try { video.load(); } catch (_) {}
    });
  }

  async function auditRenderedVideos() {
    if (!audits.length) return;
    var changed = false;
    var now = Date.now();
    for (var i = 0; i < audits.length; i += 1) {
      var audit = audits[i];
      if (audit.done || now - audit.startedAt < 4000) continue;
      if (now - audit.startedAt > 20 * 60 * 1000) {
        audit.done = true;
        changed = true;
        await writeAudit("failed", "Duration audit timed out: no rendered video was found for the " + audit.requestedSeconds + "s request.");
        continue;
      }
      var videos = Array.from(document.querySelectorAll("video"));
      for (var j = videos.length - 1; j >= 0; j -= 1) {
        var urls = videoUrls(videos[j]);
        var key = urls.length ? mediaKey(urls[0]) : "element:" + j;
        if (audit.baseline.indexOf(key) >= 0) continue;
        var actual = await videoDuration(videos[j]);
        if (!actual) continue;
        var result = durationAudit
          ? durationAudit.evaluate(audit.requestedSeconds, actual)
          : { valid: true, shorter: actual + Math.max(1.5, audit.requestedSeconds * 0.05) < audit.requestedSeconds };
        audit.done = true;
        audit.actualSeconds = actual;
        changed = true;
        if (result.shorter) {
          await writeAudit("failed", "Prompt FAILED: requested " + audit.requestedSeconds + "s, but Dola rendered " + actual.toFixed(1) + "s. The shorter result was not marked successful.");
          toast("Duration FAILED: requested " + audit.requestedSeconds + "s, received " + actual.toFixed(1) + "s.");
        } else {
          await writeAudit("success", "Generated video duration verified: requested " + audit.requestedSeconds + "s, received " + actual.toFixed(1) + "s.");
          if (audit.autoDownload && urls.length) await downloadVideo(videos[j]);
        }
        break;
      }
    }
    if (changed) {
      audits = audits.filter(function (audit) { return !audit.done || Date.now() - audit.startedAt < 60000; });
      await saveAudits();
    }
  }

  function registerAudit(message) {
    var requestId = String(message.requestId || "");
    var settings = message.settings || {};
    var duration = Number(settings.duration);
    if (!requestId || !Number.isInteger(duration) || duration <= 0 || audits.some(function (item) { return item.requestId === requestId; })) return;
    audits.push({
      requestId: requestId,
      requestedSeconds: duration,
      startedAt: Number(message.at) || Date.now(),
      baseline: currentVideoKeys(),
      autoDownload: autoDownload,
      done: false
    });
    saveAudits();
    toast("Generation submitted. Waiting to verify the rendered duration…");
  }

  function decorateVideos() {
    document.querySelectorAll("video").forEach(function (video) {
      if (video.dataset.dolaFdDecorated === "1") return;
      video.dataset.dolaFdDecorated = "1";
      var container = video.closest("div") || video.parentElement;
      if (!container) return;
      if (getComputedStyle(container).position === "static") container.style.position = "relative";
      var button = document.createElement("button");
      button.className = "dola-fd-btn";
      button.type = "button";
      button.textContent = "No-watermark";
      button.title = "Download this exact video (clean file preferred; player file may include Dola logo)";
      button.addEventListener("click", function (event) {
        event.preventDefault();
        event.stopPropagation();
        downloadVideo(video);
      });
      container.appendChild(button);
    });
  }

  function scheduleScan() {
    clearTimeout(scanTimer);
    scanTimer = setTimeout(function () {
      decorateVideos();
      auditRenderedVideos().catch(function (error) { console.warn("[Dola download] duration audit", error); });
    }, 250);
  }

  window.addEventListener("message", function (event) {
    if (event.source !== window || event.origin !== location.origin) return;
    var message = event && event.data;
    if (!message || typeof message !== "object") return;
    if (message.type === "DOLA_FD_GEN_SEEN") registerAudit(message);
    if (message.type === "DOLA_FD_MEDIA_METADATA" && typeof message.responseText === "string") {
      mediaMetadataRecords.push({
        at: Number(message.at) || Date.now(),
        url: String(message.url || ""),
        responseText: message.responseText.slice(0, 2000000)
      });
      mediaMetadataRecords = mediaMetadataRecords.slice(-8);
    }
  });

  api.runtime.onMessage.addListener(function (message, sender, sendResponse) {
    if (!message) return;
    if (message.type === "DOLA_FD_DL_LATEST") { downloadLatest(false).then(sendResponse); return true; }
    if (message.type === "DOLA_FD_DL_ALL") { downloadLatest(true).then(sendResponse); return true; }
  });

  api.storage.local.get(["forceDuration", AUDIT_KEY], function (data) {
    autoDownload = !!(data && data.forceDuration && data.forceDuration.autoDownload);
    audits = data && Array.isArray(data[AUDIT_KEY]) ? data[AUDIT_KEY].filter(function (audit) {
      return audit && !audit.done && Date.now() - Number(audit.startedAt) < 20 * 60 * 1000;
    }) : [];
    scheduleScan();
  });
  api.storage.onChanged.addListener(function (changes, area) {
    if (area === "local" && changes.forceDuration) autoDownload = !!(changes.forceDuration.newValue && changes.forceDuration.newValue.autoDownload);
  });

  function startObserver() {
    if (!document.documentElement) { setTimeout(startObserver, 100); return; }
    new MutationObserver(scheduleScan).observe(document.documentElement, { childList: true, subtree: true });
    scheduleScan();
    setInterval(scheduleScan, 2000);
  }
  startObserver();
}());
