(function () {
  "use strict";

  var api = typeof browser !== "undefined" ? browser : chrome;
  var autoChip = document.getElementById("autoChip");
  var saveButton = document.getElementById("save");
  var chipButton = document.getElementById("chip");
  var status = document.getElementById("status");
  var versionLabel = document.getElementById("extensionVersion");
  var selectionTimer = null;
  if (!autoChip) return;

  function forceSubmitOnly() {
    autoChip.checked = false;
    autoChip.disabled = true;
  }

  function selectedDuration() {
    var custom = document.getElementById("custom");
    var preset = document.getElementById("preset");
    var customText = String(custom && custom.value || "").trim();
    var customValue = Number(customText);
    if (customText) return Number.isInteger(customValue) && customValue > 0 ? customValue : 0;
    var presetValue = Number(preset && preset.value);
    return Number.isInteger(presetValue) && presetValue > 0 ? presetValue : 15;
  }

  function updateCostText() {
    var cost = document.getElementById("cost");
    if (!cost) return;
    if (!selectedDuration()) {
      cost.textContent = "Enter a positive custom duration.";
      return;
    }
    cost.textContent = cost.textContent.replace(/\s+when submitted$/i, "") + " when submitted";
  }

  function persistSelectedDuration() {
    clearTimeout(selectionTimer);
    selectionTimer = setTimeout(function () {
      var duration = selectedDuration();
      if (!duration) return;
      api.storage.local.get("forceDuration", function (data) {
        var current = Object.assign({ enabled: true, autoDownload: false, ratio: "", model: "", resolution: "" }, data && data.forceDuration || {});
        current.duration = duration;
        current.autoChip = false;
        api.storage.local.set({ forceDuration: current });
      });
    }, 120);
  }

  function validateBeforeSave(event) {
    forceSubmitOnly();
    if (selectedDuration()) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    if (status) {
      status.textContent = "Custom duration must be a positive number.";
      status.style.color = "#c0392b";
    }
  }

  function showSavedMode(settings) {
    if (!status || !settings) return;
    setTimeout(function () {
      status.textContent = settings.enabled === false
        ? "Saved — force is OFF."
        : "Saved — " + (Number(settings.duration) || selectedDuration()) + "s will be forced when Dola Submit is clicked.";
      status.style.color = settings.enabled === false ? "#666" : "#1a7f37";
    }, 0);
  }

  forceSubmitOnly();
  setTimeout(function () { forceSubmitOnly(); updateCostText(); }, 0);

  ["preset", "custom", "model"].forEach(function (id) {
    var control = document.getElementById(id);
    if (control) control.addEventListener("input", function () { setTimeout(updateCostText, 0); });
    if (control) control.addEventListener("change", function () { setTimeout(updateCostText, 0); });
  });

  if (saveButton) saveButton.addEventListener("click", validateBeforeSave, true);
  if (chipButton) chipButton.addEventListener("click", validateBeforeSave, true);

  ["preset", "custom"].forEach(function (id) {
    var control = document.getElementById(id);
    if (control) control.addEventListener("input", persistSelectedDuration);
    if (control) control.addEventListener("change", persistSelectedDuration);
  });

  try {
    if (versionLabel) versionLabel.textContent = "v" + api.runtime.getManifest().version;
  } catch (error) {}

  try {
    api.storage.local.get("forceDuration", function (data) {
      forceSubmitOnly();
      updateCostText();
      var current = data && data.forceDuration;
      if (current && current.autoChip !== false) {
        api.storage.local.set({ forceDuration: Object.assign({}, current, { autoChip: false }) });
      }
    });
    api.storage.onChanged.addListener(function (changes, area) {
      if (area !== "local" || !changes.forceDuration || !changes.forceDuration.newValue) return;
      forceSubmitOnly();
      showSavedMode(changes.forceDuration.newValue);
    });
  } catch (error) {}
}());
