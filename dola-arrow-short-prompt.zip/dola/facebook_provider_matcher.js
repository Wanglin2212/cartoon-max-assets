(function (root, factory) {
  "use strict";
  var api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  if (root) root.DolaFacebookProviderMatcher = api;
}(typeof globalThis !== "undefined" ? globalThis : this, function () {
  "use strict";

  function normalize(value) {
    return String(value || "").replace(/\s+/g, " ").trim().toLowerCase();
  }

  function hasFacebookIdentity(value) {
    return /(?:facebook(?:\.com)?|fb[ _-]?(?:login|auth|provider|logo)|provider[ _-]?fb)/i.test(normalize(value));
  }

  function hasOtherProviderIdentity(value) {
    return /(?:google|apple|iphone|phone|telephone|mobile|sms|qr(?:[ _-]?code)?)/i.test(normalize(value));
  }

  function isFacebookBlue(red, green, blue, alpha) {
    red = Number(red);
    green = Number(green);
    blue = Number(blue);
    alpha = alpha == null ? 1 : Number(alpha);
    return alpha > 0.15 && blue >= 145 && blue >= green + 45 && green >= red + 25;
  }

  function hasFacebookBlue(value) {
    var text = normalize(value);
    if (/(?:#1877f2|#0866ff|#4267b2|#3b5998|#1b74e4)\b/i.test(text)) return true;
    var rgb = /rgba?\(\s*(\d{1,3})\s*[, ]\s*(\d{1,3})\s*[, ]\s*(\d{1,3})(?:\s*[,/]\s*([\d.]+))?/ig;
    var match;
    while ((match = rgb.exec(text))) {
      if (isFacebookBlue(match[1], match[2], match[3], match[4])) return true;
    }
    return false;
  }

  function evidenceScore(identityText, visualText) {
    if (hasOtherProviderIdentity(identityText) && !hasFacebookIdentity(identityText)) return -100;
    if (hasFacebookIdentity(identityText)) return 100;
    return hasFacebookBlue(visualText) ? 60 : 0;
  }

  return {
    normalize: normalize,
    hasFacebookIdentity: hasFacebookIdentity,
    hasOtherProviderIdentity: hasOtherProviderIdentity,
    isFacebookBlue: isFacebookBlue,
    hasFacebookBlue: hasFacebookBlue,
    evidenceScore: evidenceScore
  };
}));
