(function (root, factory) {
  var api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  if (root && root.document) api.install(root.document, root.MutationObserver);
})(typeof globalThis !== "undefined" ? globalThis : self, function () {
  "use strict";

  function cleanLabel(text) {
    // Only Dola's generated-video summary suffix, never ordinary prompt text.
    return String(text).replace(/^(\s*Generated video:\s*[\s\S]*?),\s*(?:16:9|9:16|1:1|4:3|3:4|21:9)(?:,\s*\d+(?:\.\d+)?\s*s)?(\s*)$/i, "$1$2");
  }

  function install(document, Observer) {
    if (!document.body || typeof Observer !== "function") return null;
    function cleanText(node) {
      if (!node || node.nodeType !== 3 || !node.parentElement) return;
      if (node.parentElement.closest('input,textarea,select,script,style,[contenteditable]:not([contenteditable="false"]),[role="textbox"]')) return;
      var next = cleanLabel(node.nodeValue);
      if (next !== node.nodeValue) node.nodeValue = next;
    }
    function scan(node) {
      if (node.nodeType === 3) { cleanText(node); return; }
      // SHOW_TEXT, scoped to the new subtree rather than rescanning the page.
      var walker = document.createTreeWalker(node, 4);
      var text;
      while ((text = walker.nextNode())) cleanText(text);
    }
    scan(document.body);
    var observer = new Observer(function (records) {
      records.forEach(function (record) {
        if (record.type === "characterData") cleanText(record.target);
        else Array.prototype.forEach.call(record.addedNodes || [], scan);
      });
    });
    observer.observe(document.body, { childList: true, characterData: true, subtree: true });
    return observer;
  }
  return { cleanLabel: cleanLabel, install: install };
});
