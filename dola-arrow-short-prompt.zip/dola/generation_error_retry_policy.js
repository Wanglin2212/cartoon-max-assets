(function (root, factory) {
  "use strict";
  var api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  if (root) root.DolaGenerationRetryPolicy = api;
}(typeof globalThis !== "undefined" ? globalThis : this, function () {
  "use strict";

  var ERROR_MESSAGE = "Something went wrong. Please try again.";
  var MAX_ATTEMPTS = 5;
  var RETRY_DELAY_MS = 2500;

  function normalize(value) {
    return String(value || "").replace(/\s+/g, " ").trim();
  }

  function isRetryableError(value) {
    return /^something went wrong[.,]\s*please try again[.!]?$/i.test(normalize(value));
  }

  function isRetryHint(value) {
    return /(?:^|\b)(?:retry|re-try|regenerate|re-generate|try again|refresh|reload|redo)(?:\b|$)/i.test(normalize(value));
  }

  function isExcludedHint(value) {
    return /(?:copy|clipboard|thumb|like|dislike|share|forward|edit|more|menu|ellipsis|report|delete)/i.test(normalize(value));
  }

  function decision(state, now, errorVisible) {
    var current = state || {};
    var attempts = Math.max(0, Number(current.attempts) || 0);
    var lastAttemptAt = Math.max(0, Number(current.lastAttemptAt) || 0);
    var elapsed = Math.max(0, Number(now) - lastAttemptAt);
    if (!errorVisible) return { action: "wait", attempts: attempts };
    if (elapsed < RETRY_DELAY_MS) return { action: "wait", attempts: attempts, waitMs: RETRY_DELAY_MS - elapsed };
    if (attempts >= MAX_ATTEMPTS) return { action: "failed", attempts: attempts };
    return { action: "retry", attempts: attempts, nextAttempt: attempts + 1 };
  }

  return {
    ERROR_MESSAGE: ERROR_MESSAGE,
    MAX_ATTEMPTS: MAX_ATTEMPTS,
    RETRY_DELAY_MS: RETRY_DELAY_MS,
    normalize: normalize,
    isRetryableError: isRetryableError,
    isRetryHint: isRetryHint,
    isExcludedHint: isExcludedHint,
    decision: decision
  };
}));
