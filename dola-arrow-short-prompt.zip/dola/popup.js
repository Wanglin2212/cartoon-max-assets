(function () {
  "use strict";

  var api = typeof browser !== "undefined" ? browser : chrome;
  var promiseApi = typeof browser !== "undefined";
  var defaults = { enabled: true, duration: 15, autoChip: false, autoDownload: false, ratio: "", model: "", resolution: "" };

  function byId(id) { return document.getElementById(id); }

  function errorMessage(error, fallback) {
    return String(error && (error.error || error.reason || error.message) || fallback);
  }

  function getLocal(keys) {
    if (promiseApi) {
      try { return Promise.resolve(api.storage.local.get(keys)); }
      catch (error) { return Promise.reject(error); }
    }
    return new Promise(function (resolve, reject) {
      api.storage.local.get(keys, function (data) {
        var message = api.runtime.lastError && api.runtime.lastError.message;
        if (message) reject(new Error(message));
        else resolve(data);
      });
    });
  }

  function setLocal(data) {
    if (promiseApi) {
      try { return Promise.resolve(api.storage.local.set(data)); }
      catch (error) { return Promise.reject(error); }
    }
    return new Promise(function (resolve, reject) {
      api.storage.local.set(data, function () {
        var message = api.runtime.lastError && api.runtime.lastError.message;
        if (message) reject(new Error(message));
        else resolve();
      });
    });
  }

  function queryTabs(query) {
    if (promiseApi) {
      try { return Promise.resolve(api.tabs.query(query)); }
      catch (error) { return Promise.reject(error); }
    }
    return new Promise(function (resolve, reject) {
      api.tabs.query(query, function (tabs) {
        var message = api.runtime.lastError && api.runtime.lastError.message;
        if (message) reject(new Error(message));
        else resolve(tabs || []);
      });
    });
  }

  function sendTabMessage(tabId, message) {
    if (promiseApi) {
      try { return Promise.resolve(api.tabs.sendMessage(tabId, message)); }
      catch (error) { return Promise.reject(error); }
    }
    return new Promise(function (resolve, reject) {
      api.tabs.sendMessage(tabId, message, function (result) {
        var message = api.runtime.lastError && api.runtime.lastError.message;
        if (message) reject(new Error(message));
        else resolve(result);
      });
    });
  }

  function setDownloadPending(pending, activeButton) {
    ["dlLatest", "dlAll", "workflowDownload"].forEach(function (id) {
      var button = byId(id);
      if (!button) return;
      button.disabled = !!pending;
      if (pending && button === activeButton) button.setAttribute("aria-busy", "true");
      else button.removeAttribute("aria-busy");
    });
  }

  function selectedDuration() {
    var customText = String(byId("custom").value || "").trim();
    if (customText) {
      var custom = Number(customText);
      return Number.isInteger(custom) && custom > 0 ? custom : 0;
    }
    var preset = Number(byId("preset").value);
    return Number.isInteger(preset) && preset > 0 ? preset : 15;
  }

  function updateCost() {
    var seconds = selectedDuration();
    var multiplier = byId("model").value === "seedance_v2.5" ? 2 : 1;
    var points = Math.max(multiplier, Math.ceil(seconds / 5) * multiplier);
    byId("cost").textContent = seconds
      ? "→ will force " + seconds + "s  (≈ " + points + " pt" + (points === 1 ? "" : "s") + " per video)"
      : "Enter a positive whole-number duration.";
  }

  function setStatus(message, color) {
    byId("status").textContent = message;
    byId("status").style.color = color || "#1a7f37";
  }

  function currentSettings() {
    return {
      enabled: byId("enabled").checked,
      duration: selectedDuration(),
      autoChip: false,
      autoDownload: byId("autoDownload").checked,
      ratio: byId("ratio").value,
      model: byId("model").value,
      resolution: byId("resolution").value
    };
  }

  function saveSettings(callback) {
    var settings = currentSettings();
    if (!Number.isSafeInteger(settings.duration) || settings.duration <= 0) {
      setStatus("Enter a positive whole-number duration.", "#c0392b");
      return;
    }
    setLocal({ forceDuration: settings }).then(function () {
      setStatus(settings.enabled ? "Saved — " + settings.duration + "s will be forced on submit." : "Saved — force is OFF.");
      if (callback) callback(settings);
    }).catch(function (error) {
      setStatus(errorMessage(error, "Settings could not be saved."), "#c0392b");
    });
  }

  function sendToDola(message) {
    return queryTabs({ active: true, currentWindow: true }).then(function (tabs) {
      var tab = tabs && tabs[0];
      if (!tab || !/^https?:\/\/(www\.)?dola\.com\//i.test(tab.url || "")) {
        throw new Error("Open a dola.com tab first.");
      }
      return sendTabMessage(tab.id, message);
    });
  }

  function saveAndApply() {
    saveSettings(function (settings) {
      if (!settings.enabled) return;
      setStatus("Saved. Applying Dola Video controls…", "#666");
      sendToDola({ type: "DOLA_FD_APPLY_OPTIONS" }).then(function (result) {
        if (result && result.ok) setStatus(result.message || "Video controls applied.");
        else setStatus(errorMessage(result, "The Dola action could not be completed."), "#c0392b");
      }).catch(function (error) {
        setStatus(errorMessage(error, "Dola tab is not ready — reload it and try again."), "#c0392b");
      });
    });
  }

  ["preset", "custom", "model"].forEach(function (id) {
    byId(id).addEventListener("input", updateCost);
  });
  byId("preset").addEventListener("change", function () {
    byId("custom").value = "";
    updateCost();
  });
  byId("save").addEventListener("click", saveAndApply);
  byId("chip").addEventListener("click", saveAndApply);

  byId("dlLatest").addEventListener("click", function (event) {
    var button = event.currentTarget;
    setDownloadPending(true, button);
    setStatus("Looking for latest no-watermark video…", "#666");
    sendToDola({ type: "DOLA_FD_DL_LATEST" }).then(function (result) {
      if (!result || !result.ok) throw new Error(errorMessage(result, "No no-watermark video found. Open the chat with the video."));
      setStatus("Downloading " + result.count + " video" + (Number(result.count) === 1 ? "." : "s."));
    }).catch(function (error) {
      setStatus(errorMessage(error, "No no-watermark video found. Open the chat with the video."), "#c0392b");
    }).finally(function () { setDownloadPending(false); });
  });

  byId("dlAll").addEventListener("click", function (event) {
    var button = event.currentTarget;
    setDownloadPending(true, button);
    setStatus("Collecting all no-watermark videos…", "#666");
    sendToDola({ type: "DOLA_FD_DL_ALL" }).then(function (result) {
      if (!result || !result.ok) throw new Error(errorMessage(result, "No no-watermark videos found."));
      setStatus("Downloading " + result.count + " video" + (Number(result.count) === 1 ? "" : "s") + ".");
    }).catch(function (error) {
      setStatus(errorMessage(error, "No no-watermark videos found."), "#c0392b");
    }).finally(function () { setDownloadPending(false); });
  });

  getLocal("forceDuration").then(function (data) {
    var settings = Object.assign({}, defaults, data && data.forceDuration || {});
    byId("enabled").checked = settings.enabled !== false;
    var seconds = Number(settings.duration) > 0 ? Math.floor(Number(settings.duration)) : 15;
    var presetFound = Array.prototype.some.call(byId("preset").options, function (option) { return Number(option.value) === seconds; });
    if (presetFound) {
      byId("preset").value = String(seconds);
      byId("custom").value = "";
    } else {
      byId("custom").value = String(seconds);
    }
    byId("autoChip").checked = false;
    byId("autoDownload").checked = !!settings.autoDownload;
    byId("ratio").value = settings.ratio || "";
    byId("model").value = settings.model || "";
    byId("resolution").value = settings.resolution || "";
    updateCost();
  }).catch(function (error) {
    updateCost();
    setStatus(errorMessage(error, "Settings could not be loaded."), "#c0392b");
  });
}());
