(function () {
  "use strict";

  var api = typeof browser !== "undefined" ? browser : chrome;
  // Facebook may pause the OAuth round trip on its own "Continue as…" page.
  // Give the user enough time to approve it without losing the durable reset
  // state; the Dola content script resumes as soon as Facebook redirects back.
  var PROCESS_TIMEOUT = 300000;
  var STORAGE_KEY = "dolaResetFlow";
  var DIAGNOSTIC_KEY = "dolaResetDiagnostic";
  var DIAGNOSTIC_LOG_KEY = "dolaResetDiagnosticLog";
  var ACCOUNT_INFO_KEY = "dolaSavedAccount";
  var LOGIN_PREFERENCE_KEY = "dolaLoginPreference";
  var LAST_GENERATION_KEY = "dolaLastGenerationAttemptAt";
  var AUTO_RELOGIN_GUARD_KEY = "dolaFacebookAutoReloginGenerationAt";
  var accountProfile = globalThis.DolaAccountProfile;
  var facebookProviderMatcher = globalThis.DolaFacebookProviderMatcher;
  var running = false;
  var flowPaused = false;
  var flowCancelled = false;
  var deadlineExtensionMs = 0;

  function deadlineReached(deadline) { return Date.now() >= Number(deadline) + deadlineExtensionMs; }
  function waitUntilRunnable() {
    return new Promise(function (resolve, reject) {
      var timer = setInterval(function () {
        if (flowCancelled) { clearInterval(timer); reject(new Error("Account task stopped")); }
        else if (!flowPaused) { clearInterval(timer); resolve(); }
      }, 100);
    });
  }

  function normalize(value) { return String(value || "").replace(/\s+/g, " ").trim(); }
  function diagnostic(step, message, extra) {
    var entry = { step: step, message: message, url: location.pathname, time: new Date().toISOString() };
    if (extra) entry.extra = extra;
    var data = {}; data[DIAGNOSTIC_KEY] = entry;
    api.storage.local.get(DIAGNOSTIC_LOG_KEY, function (stored) {
      var log = stored && Array.isArray(stored[DIAGNOSTIC_LOG_KEY]) ? stored[DIAGNOSTIC_LOG_KEY].slice(-79) : [];
      log.push(entry);
      data[DIAGNOSTIC_LOG_KEY] = log;
      api.storage.local.set(data);
    });
    console.log("[Dola ForceDuration/reset]", step + ":", message, entry);
  }
  function activate(node) {
    if (!node) return false;
    if (typeof node.dispatchEvent === "function") {
      var rect = node.getBoundingClientRect ? node.getBoundingClientRect() : { left: 0, top: 0, width: 0, height: 0 };
      var x = rect.left + rect.width / 2;
      var y = rect.top + rect.height / 2;
      var options = { bubbles: true, cancelable: true, view: window, clientX: x, clientY: y, button: 0 };
      if (typeof PointerEvent === "function") {
        node.dispatchEvent(new PointerEvent("pointerdown", options));
        node.dispatchEvent(new PointerEvent("pointerup", options));
      }
      node.dispatchEvent(new MouseEvent("mousedown", options));
      node.dispatchEvent(new MouseEvent("mouseup", options));
      if (typeof node.click === "function") node.click();
      else node.dispatchEvent(new MouseEvent("click", options));
      return true;
    }
    return false;
  }
  function activateByKeyboard(node) {
    if (!node || typeof node.dispatchEvent !== "function") return false;
    if (typeof node.focus === "function") node.focus();
    var options = { bubbles: true, cancelable: true, key: "Enter", code: "Enter", keyCode: 13, which: 13 };
    node.dispatchEvent(new KeyboardEvent("keydown", options));
    node.dispatchEvent(new KeyboardEvent("keyup", options));
    return true;
  }
  function requestTrustedClick(node, selector, semantic) {
    var rect = node && node.getBoundingClientRect ? node.getBoundingClientRect() : null;
    if (!rect && !selector && !semantic) return Promise.resolve({ ok: false, error: "Trusted click has no target" });
    return new Promise(function (resolve) {
      try {
        var message = { type: "DOLA_FD_TRUSTED_CLICK", selector: selector || null, semantic: semantic || null };
        if (rect) {
          message.x = rect.left + rect.width / 2;
          message.y = rect.top + rect.height / 2;
        }
        api.runtime.sendMessage(message, function (result) {
          if (api.runtime.lastError) resolve({ ok: false, error: api.runtime.lastError.message });
          else resolve(result || { ok: false, error: "No trusted-click response" });
        });
      } catch (error) { resolve({ ok: false, error: error.message }); }
    });
  }
  function findText(pattern) {
    var nodes = document.querySelectorAll("button, [role=button], a, [role=menuitem], [role=dialog] span, [role=dialog] div, div, p, span");
    var match = null;
    for (var i = 0; i < nodes.length; i++) {
      var text = normalize(nodes[i].textContent);
      // Prefer the deepest matching element. The recorded Delete Account
      // target is the nested inner div, not its larger Radix ancestors.
      if (text && pattern.test(text) && isVisible(nodes[i])) match = nodes[i];
    }
    return match;
  }
  function isVisible(node) {
    if (!node || !node.isConnected) return false;
    var style = window.getComputedStyle(node);
    return style.display !== "none" && style.visibility !== "hidden" && style.opacity !== "0" && style.pointerEvents !== "none" && node.getBoundingClientRect().width > 0;
  }
  function getState() {
    return new Promise(function (resolve) { api.storage.local.get(STORAGE_KEY, function (data) { resolve(data && data[STORAGE_KEY]); }); });
  }
  function setState(state) {
    var data = {}; data[STORAGE_KEY] = state;
    return new Promise(function (resolve) { api.storage.local.set(data, resolve); });
  }
  function clearState() {
    return new Promise(function (resolve) { api.storage.local.remove(STORAGE_KEY, resolve); });
  }
  function waitFor(pattern, deadline, label) {
    diagnostic(label, "watching for control");
    return new Promise(function (resolve, reject) {
      var timer = setInterval(function () {
        if (flowCancelled) { clearInterval(timer); reject(new Error("Account task stopped")); return; }
        if (flowPaused) return;
        var node = findText(pattern);
        if (node) { clearInterval(timer); diagnostic(label, "control found"); resolve(node); }
        else if (deadlineReached(deadline)) { clearInterval(timer); diagnostic(label, "timeout: control not found"); reject(new Error("Could not find " + label)); }
      }, 250);
    });
  }
  function clickControl(pattern, label, deadline) {
    return waitFor(pattern, deadline, label).then(function (node) {
      diagnostic(label, "clicking control", { tag: node.tagName, text: normalize(node.textContent) });
      if (!activate(node)) throw new Error(label + " could not be activated");
      return new Promise(function (resolve) { setTimeout(resolve, 500); });
    });
  }
  function waitForCondition(condition, label, deadline) {
    diagnostic(label, "waiting for transition");
    return new Promise(function (resolve, reject) {
      var timer = setInterval(function () {
        if (flowCancelled) { clearInterval(timer); reject(new Error("Account task stopped")); return; }
        if (flowPaused) return;
        if (condition()) { clearInterval(timer); diagnostic(label, "transition confirmed"); resolve(); }
        else if (deadlineReached(deadline)) { clearInterval(timer); diagnostic(label, "timeout: transition not confirmed"); reject(new Error(label + " transition failed")); }
      }, 250);
    });
  }
  function retryClickUntil(pattern, label, condition, deadline) {
    return retryTargetUntil(function () { return findText(pattern); }, label, condition, deadline);
  }
  function retryTargetUntil(findNode, label, condition, deadline) {
    return new Promise(function (resolve, reject) {
      var lastAttempt = 0;
      var timer = setInterval(function () {
        if (flowCancelled) { clearInterval(timer); reject(new Error("Account task stopped")); return; }
        if (flowPaused) return;
        if (deadlineReached(deadline)) {
          clearInterval(timer);
          diagnostic(label, "timeout: click did not cause the expected transition");
          reject(new Error(label + " transition failed"));
          return;
        }
        if (condition()) { clearInterval(timer); diagnostic(label, "transition confirmed"); resolve(); return; }
        if (Date.now() - lastAttempt < 900) return;
        var node = findNode();
        if (!node) return;
        lastAttempt = Date.now();
        diagnostic(label, "click attempt", { tag: node.tagName, text: normalize(node.textContent) });
        activate(node);
        // Dola's Account row is a generic div; retry its immediate parent if
        // the visible child did not deliver the React click handler.
        setTimeout(function () {
          if (!condition() && node.parentElement) activate(node.parentElement);
        }, 250);
        // Delete Now is a custom div button in the recorded page. Try its
        // keyboard activation as a final equivalent user interaction.
        setTimeout(function () {
          if (!condition()) activateByKeyboard(node);
        }, 500);
      }, 250);
    });
  }
  function findDeleteNowControl() {
    var label = findText(/^Delete Now$/i);
    var target = clickableParent(label);
    return target && isVisible(target) ? target : null;
  }
  function isDeleteVerificationPending() {
    // Dola briefly reuses the final red control as a loading "Next" button
    // while it verifies the linked Facebook session. Clicking during this
    // React transition is ignored, even though Chrome dispatches the event.
    return !!findText(/^Delete Account$/i) && !!findText(/^Next$/i) && !findDeleteNowControl();
  }
  function isDeleteNowScreen() {
    return !!findDeleteNowControl();
  }
  function clickDeleteAccount(deadline) {
    return retryClickUntil(/^Delete Account$/i, "Delete Account", function () {
      return !!findText(/^Delete$/i) || isDeleteNowScreen();
    }, deadline);
  }
  function clickDelete(deadline) {
    return new Promise(function (resolve, reject) {
      var lastAttempt = 0;
      var missingSince = 0;
      var hasClicked = false;
      var verificationNoticeShown = false;
      var timer = setInterval(function () {
        if (flowCancelled) { clearInterval(timer); reject(new Error("Account task stopped")); return; }
        if (flowPaused) return;
        if (deadlineReached(deadline)) {
          clearInterval(timer);
          diagnostic("Delete", "timeout: confirmation did not transition");
          reject(new Error("Delete transition failed before the 5-minute timeout"));
          return;
        }
        if (isDeleteNowScreen()) {
          clearInterval(timer);
          diagnostic("Delete", "Delete Now screen detected; transition confirmed");
          resolve();
          return;
        }
        if (isDeleteVerificationPending()) {
          missingSince = 0;
          if (!verificationNoticeShown) {
            verificationNoticeShown = true;
            diagnostic("Delete", "Facebook verification pending; waiting for Next to become Delete Now");
          }
          return;
        }
        verificationNoticeShown = false;
        var node = findText(/^Delete$/i);
        if (!node) {
          if (hasClicked && !missingSince) missingSince = Date.now();
          if (hasClicked && Date.now() - missingSince >= 1500) {
            clearInterval(timer);
            diagnostic("Delete", "Delete control disappeared; advancing to final confirmation");
            resolve();
          }
          return;
        }
        missingSince = 0;
        if (Date.now() - lastAttempt < 900) return;
        lastAttempt = Date.now();
        hasClicked = true;
        diagnostic("Delete", "click attempt", { tag: node.tagName, text: normalize(node.textContent) });
        activate(clickableParent(node));
      }, 250);
    });
  }
  function clickableParent(node) {
    if (!node) return null;
    var direct = node.closest && node.closest("button, a, [role=button], [tabindex]:not([tabindex='-1'])");
    if (direct) return direct;
    var current = node;
    for (var depth = 0; current && depth < 5; depth++, current = current.parentElement) {
      if (String(current.tagName || "").toLowerCase() === "svg") continue;
      var style = getComputedStyle(current);
      if (current.onclick || style.cursor === "pointer" || /(?:^|\s)(?:button|btn)(?:\s|$|-)/i.test(String(current.className || ""))) return current;
    }
    return node;
  }
  function providerClickableParent(node) {
    if (!node) return null;
    var current = node;
    for (var depth = 0; current && depth < 7; depth++, current = current.parentElement) {
      var tag = String(current.tagName || "").toLowerCase();
      var role = current.getAttribute && current.getAttribute("role");
      var tabindex = current.getAttribute && current.getAttribute("tabindex");
      var style;
      try { style = getComputedStyle(current); } catch (error) { style = null; }
      if (tag === "button" || tag === "a" || role === "button" || (tabindex != null && tabindex !== "-1") || current.onclick ||
          (style && style.cursor === "pointer") || /(?:^|[\s_-])(?:button|btn|cursor-pointer)(?:[\s_-]|$)/i.test(String(current.className || ""))) return current;
    }
    return null;
  }
  function elementHint(node) {
    if (!node) return "";
    var values = [node.textContent, node.getAttribute && node.getAttribute("aria-label"), node.getAttribute && node.getAttribute("title"), node.id, node.className, node.getAttribute && node.getAttribute("data-provider"), node.getAttribute && node.getAttribute("data-testid"), node.getAttribute && node.getAttribute("href")];
    var image = node.querySelector && node.querySelector("img");
    if (image) values.push(image.alt, image.src);
    return normalize(values.filter(Boolean).join(" "));
  }
  function visualEvidence(node) {
    if (!node) return "";
    var values = [node.outerHTML && node.outerHTML.slice(0, 16000)];
    var visualNodes = [node].concat(Array.from(node.querySelectorAll ? node.querySelectorAll("svg, img, path, circle, use, i") : []).slice(0, 80));
    visualNodes.forEach(function (visual) {
      values.push(
        visual.getAttribute && visual.getAttribute("fill"),
        visual.getAttribute && visual.getAttribute("stroke"),
        visual.getAttribute && visual.getAttribute("style"),
        visual.getAttribute && visual.getAttribute("src"),
        visual.getAttribute && visual.getAttribute("href"),
        visual.getAttribute && visual.getAttribute("xlink:href")
      );
      try {
        var style = getComputedStyle(visual);
        values.push(style.color, style.fill, style.stroke, style.backgroundColor);
      } catch (error) {}
    });
    return normalize(values.filter(Boolean).join(" "));
  }
  function providerIconCandidates(scope) {
    scope = scope || document;
    var raw = scope.querySelectorAll("button, a, [role=button], [tabindex]:not([tabindex='-1']), [class*='cursor'], div, span, svg, img, i");
    var candidates = [];
    for (var index = 0; index < raw.length; index += 1) {
      var candidate = providerClickableParent(raw[index]);
      if (!candidate || candidates.indexOf(candidate) >= 0 || !isVisible(candidate)) continue;
      var hasIcon = /^(?:svg|img|i)$/i.test(String(candidate.tagName || "")) || !!candidate.querySelector("svg, img, i") || /url\(|mask/i.test(visualEvidence(candidate));
      if (!hasIcon) continue;
      var rect = candidate.getBoundingClientRect();
      if (rect.width < 26 || rect.width > 90 || rect.height < 26 || rect.height > 90 || Math.abs(rect.width - rect.height) > 26) continue;
      candidates.push(candidate);
    }
    // Provider controls form a horizontal row. Requiring a nearby peer avoids
    // treating an unrelated blue icon elsewhere on the page as Facebook.
    return candidates.filter(function (candidate) {
      var rect = candidate.getBoundingClientRect();
      var centerY = rect.top + rect.height / 2;
      return candidates.some(function (other) {
        if (other === candidate) return false;
        var otherRect = other.getBoundingClientRect();
        var otherCenterY = otherRect.top + otherRect.height / 2;
        return Math.abs(centerY - otherCenterY) <= 18 && Math.abs((rect.left + rect.width / 2) - (otherRect.left + otherRect.width / 2)) <= 240;
      });
    });
  }
  function loginProviderSurface() {
    if (findDeleteNowControl()) return null;
    var marker = findText(/Log In to Unlock More Features/i);
    var scope = marker && marker.closest && marker.closest("[role=dialog], [aria-modal=true]");
    var candidates = providerIconCandidates(scope || document);
    if (candidates.length < 2) return null;
    return { scope: scope || document, candidates: candidates, marker: marker };
  }
  function findFacebookControl() {
    var surface = loginProviderSurface();
    var marker = findText(/Log In to Unlock More Features/i);
    var scope = surface ? surface.scope : (marker && marker.closest && marker.closest("[role=dialog], [aria-modal=true]"));
    if (!scope) return null;
    var byText = Array.from(scope.querySelectorAll("button, [role=button], a, div, span")).find(function (node) {
      return /^Continue with Facebook$/i.test(normalize(node.textContent)) && isVisible(node);
    });
    if (byText) return providerClickableParent(byText);

    var directSelectors = [
      "button[aria-label*='facebook' i]", "[role=button][aria-label*='facebook' i]",
      "button[title*='facebook' i]", "[role=button][title*='facebook' i]",
      "[data-provider*='facebook' i]", "[data-testid*='facebook' i]",
      "a[href*='facebook.com' i]", "img[alt*='facebook' i]"
    ];
    for (var selectorIndex = 0; selectorIndex < directSelectors.length; selectorIndex += 1) {
      var directMatches = scope.querySelectorAll(directSelectors[selectorIndex]);
      for (var directIndex = 0; directIndex < directMatches.length; directIndex += 1) {
        var direct = providerClickableParent(directMatches[directIndex]);
        if (direct && isVisible(direct) && surface && surface.candidates.indexOf(direct) >= 0) return direct;
      }
    }

    // Dola reorders the circular providers. Identify Facebook from semantic
    // attributes or its rendered blue icon; never infer it from left/middle/right.
    if (!facebookProviderMatcher || !surface) return null;
    var iconButtons = surface.candidates;
    var ranked = iconButtons.map(function (candidate) {
      return {
        node: candidate,
        hint: elementHint(candidate),
        score: facebookProviderMatcher.evidenceScore(elementHint(candidate), visualEvidence(candidate))
      };
    }).sort(function (left, right) { return right.score - left.score; });
    if (ranked.length && ranked[0].score >= 60) return ranked[0].node;

    // If Dola supplies provider names only for Phone/Apple, the sole remaining
    // icon is Facebook. More than one unknown icon is intentionally ambiguous.
    var remaining = ranked.filter(function (entry) {
      return !facebookProviderMatcher.hasOtherProviderIdentity(entry.hint);
    });
    return remaining.length === 1 ? remaining[0].node : null;
  }
  function findClickableText(pattern) {
    var node = findText(pattern);
    var target = providerClickableParent(node);
    return target && isVisible(target) ? target : null;
  }
  function findLoginControl() {
    return findClickableText(/^Confirm$/i) || findFacebookControl() || findClickableText(/Continue with Google/i) || findText(/Log In to Unlock More Features/i) || findClickableText(/^Log In$/i);
  }
  function isLoggedInReady() {
    if (findLoginControl()) return false;
    return !!findProfileRow();
  }
  function completeProviderLogin(deadline, flow) {
    return new Promise(function (resolve, reject) {
      var lastAttempt = 0;
      var lastProviderAttempt = 0;
      var readySince = 0;
      var lastStage = "";
      var providerProbeInFlight = false;
      var providerWasClickedAt = 0;
      var facebookHandoffNoticeShown = false;
      var READY_CONFIRMATION_MS = 3000;
      function probeProviderControl() {
        if (!flow.semantic || providerProbeInFlight || Date.now() - lastProviderAttempt < 3000 || (providerWasClickedAt && Date.now() - providerWasClickedAt < 30000)) return;
        lastProviderAttempt = Date.now();
        providerProbeInFlight = true;
        diagnostic(flow.stage, "browser-level semantic click probe");
        requestTrustedClick(null, null, flow.semantic).then(function (result) {
          providerProbeInFlight = false;
          if (result && result.ok) providerWasClickedAt = Date.now();
          diagnostic(flow.stage, result && result.ok ? "browser-level semantic click dispatched" : "browser-level semantic control not found; retrying", {
            error: result && result.error || null,
            matchedBy: result && result.matchedBy || null
          });
        });
      }
      diagnostic("Log In", "monitoring automatic " + flow.provider + " session login flow");
      var timer = setInterval(function () {
        if (flowCancelled) { clearInterval(timer); reject(new Error("Account task stopped")); return; }
        if (flowPaused) return;
        if (deadlineReached(deadline)) {
          clearInterval(timer);
          diagnostic("Log In", "timeout: automatic login did not complete");
          reject(new Error("Automatic login did not complete before the 5-minute timeout"));
          return;
        }
        var confirmNode = findClickableText(/^Confirm$/i);
        var providerNode = flow.findProvider();
        var loginDialog = findText(/Log In to Unlock More Features/i);
        var providerSurface = flow.hasProviderSurface && flow.hasProviderSurface();
        // A covered page-level Log In control must never take priority while
        // the provider chooser is open.
        var loginNode = loginDialog || providerSurface ? null : findClickableText(/^Log In$/i);
        var node = confirmNode || providerNode || loginNode;
        var stage = confirmNode ? "Confirm" : (providerNode ? flow.stage : (loginNode ? "Log In" : ""));
        if (flow.provider === "Facebook" && providerWasClickedAt && !facebookHandoffNoticeShown && Date.now() - providerWasClickedAt >= 1500) {
          facebookHandoffNoticeShown = true;
          diagnostic("Facebook confirmation", "If Facebook shows ‘Continue as…’, approve it there. Reset will resume automatically after Facebook returns to Dola.");
        }
        if (!node) {
          if (loginDialog || providerSurface) {
            readySince = 0;
            if (lastStage !== flow.controlStage) {
              lastStage = flow.controlStage;
              diagnostic(flow.stage, "login popup visible; locating " + flow.provider + " provider control");
            }
            probeProviderControl();
            return;
          }
          if (!isLoggedInReady()) {
            readySince = 0;
            probeProviderControl();
            return;
          }
          if (!readySince) {
            readySince = Date.now();
            diagnostic("Log In", "logged-in profile detected; verifying");
          }
          if (Date.now() - readySince >= READY_CONFIRMATION_MS) {
            clearInterval(timer);
            diagnostic("Log In", "automatic login confirmed");
            resolve();
          }
          return;
        }
        readySince = 0;
        if (stage !== lastStage) {
          lastStage = stage;
          diagnostic(stage, "control detected");
        }
        var retryDelay = stage === flow.stage ? 8000 : 900;
        if (stage === flow.stage && providerWasClickedAt && Date.now() - providerWasClickedAt < 30000) return;
        if (Date.now() - lastAttempt < retryDelay) return;
        lastAttempt = Date.now();
        diagnostic(stage, "click attempt", { tag: node.tagName, text: normalize(node.textContent) });
        if (stage === flow.stage && flow.trustedClick) {
          // The content script found the exact provider control. Preserve its
          // coordinates instead of replacing it with a global semantic match.
          requestTrustedClick(node, null, null).then(function (result) {
              if (result && result.ok) providerWasClickedAt = Date.now();
              if (!result || !result.ok) {
              diagnostic(stage, "trusted click unavailable; using page click", { error: result && result.error || null });
              activate(node);
            }
          });
        } else activate(node);
        setTimeout(function () {
          var stillVisible = stage === "Confirm" ? findText(/^Confirm$/i) : (stage === flow.stage ? flow.findProvider() : findText(/^Log In$/i));
          if (!(stage === flow.stage && flow.trustedClick) && stillVisible && node.parentElement) activate(node.parentElement);
        }, 300);
      }, 250);
    });
  }
  function completeFacebookLogin(deadline) {
    return completeProviderLogin(deadline, {
      provider: "Facebook",
      stage: "Continue with Facebook",
      controlStage: "Facebook control",
      findProvider: findFacebookControl,
      hasProviderSurface: function () { return !!loginProviderSurface(); },
      trustedClick: true,
      semantic: "Facebook"
    });
  }
  function completeGoogleLogin(deadline) {
    return completeProviderLogin(deadline, {
      provider: "Google",
      stage: "Continue with Google",
      controlStage: "Google control",
      findProvider: function () { return findText(/Continue with Google/i); },
      trustedClick: false,
      semantic: ""
    });
  }
  function clickDeleteNow(deadline) {
    // Resolve the visible label to its current clickable ancestor. Dola's
    // generated button class changes between builds and can be shared by
    // unrelated controls, so it is not a safe browser-level target.
    var findDeleteNow = function () {
      var label = findText(/^Delete Now$/i);
      var target = clickableParent(label);
      return target && isVisible(target) ? target : null;
    };
    return new Promise(function (resolve, reject) {
      var lastAttempt = 0;
      var missingSince = 0;
      var probeInFlight = false;
      var hasClicked = false;
      var deleteNowStableSince = 0;
      var verificationPendingSince = 0;
      var verificationGraceExpired = false;
      var ABSENCE_CONFIRMATION_MS = 5000;
      var CONTROL_STABILITY_MS = 750;
      var VERIFICATION_GRACE_MS = 4000;
      function rememberClick() {
        hasClicked = true;
      }
      var timer = setInterval(function () {
        if (flowCancelled) { clearInterval(timer); reject(new Error("Account task stopped")); return; }
        if (flowPaused) return;
        if (deadlineReached(deadline)) {
          clearInterval(timer);
          diagnostic("Delete Now", "timeout: button did not disappear");
          reject(new Error("Delete Now did not disappear before the 5-minute timeout"));
          return;
        }
        // Do not use a login surface as completion evidence here. Dola can
        // render that surface behind the still-open Delete Account modal,
        // which previously advanced the flow while Delete Now was visible.
        if (isDeleteVerificationPending()) {
          missingSince = 0;
          deleteNowStableSince = 0;
          if (!verificationPendingSince) {
            verificationPendingSince = Date.now();
            diagnostic("Delete Now", "temporary Next verification detected; waiting briefly");
          }
          if (Date.now() - verificationPendingSince < VERIFICATION_GRACE_MS) return;
          if (!verificationGraceExpired) {
            verificationGraceExpired = true;
            diagnostic("Delete Now", "Next verification grace expired; probing Delete Now despite stale Next UI");
          }
        } else {
          verificationPendingSince = 0;
          verificationGraceExpired = false;
        }
        var currentNode = findDeleteNow();
        if (!currentNode) {
          deleteNowStableSince = 0;
          if (missingSince && Date.now() - missingSince >= ABSENCE_CONFIRMATION_MS) {
            if (hasClicked) {
              clearInterval(timer);
              diagnostic("Delete Now", "control remained absent after click; transition confirmed");
              resolve();
            }
            return;
          }
          // The button can live outside this content script's DOM. Probe and
          // click it through Chrome DevTools Protocol before deciding it is
          // actually absent.
          if (probeInFlight || Date.now() - lastAttempt < 900) return;
          lastAttempt = Date.now();
          probeInFlight = true;
          diagnostic("Delete Now", "browser-level click probe");
          requestTrustedClick(null, null, "Delete Now").then(function (result) {
            probeInFlight = false;
            if (result && result.ok) {
              rememberClick();
              missingSince = 0;
              diagnostic("Delete Now", "browser-level click dispatched");
              return;
            }
            if (result && /Semantic control (?:not found|has no clickable box)/.test(String(result.error || ""))) {
              if (!missingSince) missingSince = Date.now();
              return;
            }
            // A debugger conflict is not proof that the visible UI vanished.
            missingSince = 0;
            diagnostic("Delete Now", "browser-level probe failed; retrying", { error: result && result.error || null });
          });
          return;
        }
        // A temporary React unmount is not completion; keep watching and
        // clicking if the control comes back.
        missingSince = 0;
        if (!deleteNowStableSince) {
          deleteNowStableSince = Date.now();
          diagnostic("Delete Now", "control appeared; waiting for it to become interactive");
          return;
        }
        if (Date.now() - deleteNowStableSince < CONTROL_STABILITY_MS) return;
        if (Date.now() - lastAttempt < 900) return;
        var node = currentNode;
        lastAttempt = Date.now();
        var rect = node.getBoundingClientRect ? node.getBoundingClientRect() : null;
        diagnostic("Delete Now", "trusted click attempt", {
          tag: node.tagName,
          className: node.className,
          text: normalize(node.textContent),
          rect: rect ? { left: rect.left, top: rect.top, width: rect.width, height: rect.height } : null
        });
        // Use the exact measured control when it is visible. Semantic search
        // is reserved for frames/shadow roots the content script cannot see.
        requestTrustedClick(node, null, null).then(function (result) {
          if (result && result.ok) {
            rememberClick();
            diagnostic("Delete Now", "trusted click dispatched");
            // Chrome can accept a coordinate event even when an overlay or a
            // nested visual element receives it instead of Dola's React
            // handler. If the button survives, retry by accessible name so
            // the browser resolves the live clickable control itself.
            setTimeout(function () {
              if (!findDeleteNow()) return;
              diagnostic("Delete Now", "button still visible; trying semantic click");
              requestTrustedClick(null, null, "Delete Now").then(function (semanticResult) {
                if (semanticResult && semanticResult.ok) {
                  rememberClick();
                  diagnostic("Delete Now", "semantic click dispatched");
                  return;
                }
                var liveNode = findDeleteNow();
                var fallbackClicked = !!liveNode && activate(liveNode);
                if (fallbackClicked) rememberClick();
                diagnostic("Delete Now", fallbackClicked ? "semantic click unavailable; page fallback dispatched" : "semantic and page clicks failed; retrying", { error: semanticResult && semanticResult.error || null });
              });
            }, 600);
            return;
          }
          // A coordinate failure can still be recovered by browser-level
          // semantic lookup (including shadow DOM and accessibility nodes).
          requestTrustedClick(null, null, "Delete Now").then(function (semanticResult) {
            if (semanticResult && semanticResult.ok) {
              rememberClick();
              diagnostic("Delete Now", "coordinate click failed; semantic click dispatched", { error: result && result.error || null });
              return;
            }
            // If debugger permission is unavailable (or another debugger is
            // attached), still perform the requested click from the page and
            // let the next interval retry if Dola keeps the control visible.
            var liveNode = findDeleteNow() || node;
            var fallbackClicked = activate(liveNode);
            if (fallbackClicked) rememberClick();
            diagnostic("Delete Now", fallbackClicked ? "browser clicks unavailable; page fallback dispatched" : "click failed; retrying", {
              coordinateError: result && result.error || null,
              semanticError: semanticResult && semanticResult.error || null
            });
          });
        });
      }, 250);
    });
  }
  function findProfileRow() {
    var sidebar = document.querySelector("#flow_chat_sidebar");
    if (!sidebar) return null;
    var sidebarRect = sidebar.getBoundingClientRect();
    var rows = sidebar.querySelectorAll(":scope > div");
    var best = null;
    var bestTop = -1;
    for (var i = 0; i < rows.length; i++) {
      var row = rows[i];
      var text = normalize(row.textContent);
      var arrow = row.querySelector("svg");
      if (!text || text.length > 100 || !arrow || !isVisible(row)) continue;
      if (/^(?:Dola|New Chat|AI Creation|Recents|Pinned|About Dola)$/i.test(text)) continue;
      var rect = row.getBoundingClientRect();
      // The authenticated account row is anchored in the lower portion of
      // the sidebar. This works for any profile name or avatar initial.
      if (sidebarRect.height > 0 && rect.top < sidebarRect.top + sidebarRect.height * 0.6) continue;
      if (rect.top >= bestTop) {
        best = row;
        bestTop = rect.top;
      }
    }
    return best;
  }
  function saveCurrentAccount(provider) {
    var profileRow = findProfileRow();
    var displayName = normalize(profileRow && profileRow.textContent);
    var info = accountProfile && accountProfile.createAccountInfo
      ? accountProfile.createAccountInfo(provider, displayName, Date.now())
      : null;
    if (!info) return Promise.reject(new Error("Logged-in profile name could not be saved"));
    return new Promise(function (resolve, reject) {
      var update = {};
      update[ACCOUNT_INFO_KEY] = info;
      update[LOGIN_PREFERENCE_KEY] = { provider: "facebook", accountId: info.id };
      api.storage.local.set(update, function () {
        if (api.runtime.lastError) reject(new Error(api.runtime.lastError.message));
        else {
          diagnostic("Facebook Login", "saved non-secret account profile", { displayName: info.displayName, provider: info.provider });
          resolve(info);
        }
      });
    });
  }
  function findProfileArrow() {
    var sidebar = document.querySelector("#flow_chat_sidebar");
    if (!sidebar) return null;
    var profileRow = findProfileRow();
    if (profileRow) return profileRow.querySelector("svg");
    // Retain the exact selector captured in Final Record.json as a fallback.
    var exact = document.querySelector("#flow_chat_sidebar > div:nth-of-type(4) svg");
    if (exact) return exact;
    // The account row is the sidebar div containing a profile label and an SVG arrow.
    var rows = sidebar.querySelectorAll(":scope > div");
    for (var i = rows.length - 1; i >= 0; i--) {
      if (rows[i].querySelector("svg") && normalize(rows[i].textContent)) return rows[i].querySelector("svg");
    }
    var svgs = sidebar.querySelectorAll("svg");
    return svgs.length ? svgs[svgs.length - 1] : null;
  }
  function clickProfileArrow(deadline) {
    return new Promise(function (resolve, reject) {
      var lastAttempt = 0;
      diagnostic("profile arrow", "waiting for recorded caret selector");
      var timer = setInterval(function () {
        if (flowCancelled) { clearInterval(timer); reject(new Error("Account task stopped")); return; }
        if (flowPaused) return;
        // First use the exact selector captured by Final Record.json, then stable structural fallbacks.
        var arrow = findProfileArrow();
        if (!arrow) {
          var row = findProfileRow();
          arrow = row && (row.querySelector("svg") || row.querySelector("[aria-expanded], [data-state], button") || row);
        }
        if (deadlineReached(deadline)) { clearInterval(timer); diagnostic("profile arrow", "timeout: caret not found or menu did not open"); reject(new Error("Profile arrow failed before the 5-minute timeout")); }
        // Do not report success until the menu actually exposes Settings.
        else if (findText(/^Settings$/i)) { clearInterval(timer); diagnostic("profile arrow", "menu opened; Settings is visible"); resolve(); return; }
        else if (arrow && Date.now() - lastAttempt >= 1000) {
          lastAttempt = Date.now();
          var arrowRect = arrow.getBoundingClientRect ? arrow.getBoundingClientRect() : null;
          diagnostic("profile arrow", "click attempt", {
            selector: "#flow_chat_sidebar > div:nth-of-type(4) svg",
            found: true,
            tag: arrow.tagName,
            rect: arrowRect ? { left: arrowRect.left, top: arrowRect.top, width: arrowRect.width, height: arrowRect.height } : null,
            parent: arrow.parentElement ? arrow.parentElement.outerHTML.slice(0, 500) : null
          });
          var trigger = arrow.closest && (arrow.closest("button, [role=button], [aria-expanded]") || arrow);
          activate(trigger);
          // Some Dola builds attach the handler to the SVG's immediate parent.
          setTimeout(function () {
            if (!findText(/^Settings$/i) && arrow.parentElement) activate(arrow.parentElement);
          }, 300);
        }
      }, 250);
    });
  }

  // Exact sequence captured by the latest recording. The saved index lets the
  // flow continue after Dola navigates to another page.
  var steps = [
    { name: "profile arrow", run: clickProfileArrow },
    { name: "Settings", pattern: /^Settings$/i },
    { name: "Account", pattern: /^Account$/i },
    // The final recording exposes this row as aria "Delete", but the visible
    // control in the live Account panel is labeled "Delete Account".
    { name: "Delete Account", run: clickDeleteAccount },
    { name: "Delete", run: clickDelete },
    { name: "Delete Now", run: clickDeleteNow },
    // Keep the entire login sequence in one durable state so navigation cannot
    // skip an automatically appearing popup or confirmation dialog.
    { name: "Log In", run: completeFacebookLogin }
  ];

  async function resume(sendResponse) {
    if (running) return;
    running = true;
    var state = await getState();
    if (!state || !state.active) { running = false; return; }
    if (state.source !== "explicit-reset" || (!state.paused && Number(state.deadline) <= Date.now())) {
      await clearState();
      diagnostic("reset", "discarded stale reset state; a fresh Reset account click is required");
      running = false;
      return;
    }
    flowPaused = !!state.paused;
    flowCancelled = false;
    deadlineExtensionMs = 0;
    var deadline = Number(state.deadline) || (Date.now() + PROCESS_TIMEOUT);
    diagnostic(steps[state.index] ? steps[state.index].name : "reset", "resuming", { index: state.index, deadline: new Date(deadline).toISOString() });
    try {
      while (state.index < steps.length) {
        await waitUntilRunnable();
        if (deadlineReached(deadline)) throw new Error("Reset stopped after the 5-minute timeout");
        var step = steps[state.index];
        if (step.name === "Delete" && isDeleteNowScreen()) {
          diagnostic("Delete", "already on Delete Now screen; skipping duplicate confirmation");
          state.index += 1;
          await setState(state);
          continue;
        }
        diagnostic(step.name, "starting", { index: state.index, url: location.pathname });
        // Keep destructive/final transition steps pending so navigation or a
        // temporary React unmount resumes the same action.
        var advanceBeforeRun = step.name !== "Delete Now" && step.name !== "Log In";
        if (advanceBeforeRun) {
          state.index += 1;
          await setState(state);
        }
        if (step.pattern) await clickControl(step.pattern, step.name, deadline);
        else await step.run(deadline);
        if (!advanceBeforeRun) {
          state = await getState();
          if (flowCancelled) throw new Error("Account task stopped");
          if (!state || !state.active) throw new Error("Reset flow was stopped");
          state.index += 1;
          await setState(state);
        }
        await new Promise(function (resolve) { setTimeout(resolve, 500); });
        state = await getState();
        if (flowCancelled) throw new Error("Account task stopped");
        if (!state || !state.active) throw new Error("Reset flow was stopped");
      }
      // A stale runner must never mark success while any login UI remains or
      // before the authenticated profile is visible.
      if (!isLoggedInReady()) {
        diagnostic("Log In", "login UI still active; withholding success");
        state = await getState() || { active: true, deadline: deadline };
        state.active = true;
        state.index = steps.length - 1;
        await setState(state);
        await completeFacebookLogin(deadline);
        state = await getState();
        if (!state || !state.active) throw new Error("Reset flow was stopped");
        state.index = steps.length;
        await setState(state);
      }
      await waitUntilRunnable();
      var accountInfo = await saveCurrentAccount("facebook");
      await clearState();
      diagnostic("complete", "all recorded steps completed");
      if (sendResponse) sendResponse({ ok: true, account: accountInfo });
      setTimeout(function () {
        diagnostic("success", "account reset and Facebook login completed successfully");
        location.reload();
      }, 1200);
    } catch (error) {
      var latestState = await getState();
      if (error.message === "Account task stopped") {
        await clearState();
        diagnostic("reset", "task stopped by user");
        if (sendResponse) sendResponse({ ok: false, stopped: true, error: "Account task stopped" });
        return;
      }
      if (!latestState && error.message === "Reset flow was stopped") {
        diagnostic("complete", "flow completed by resumed page");
        if (sendResponse) sendResponse({ ok: true });
        return;
      }
      await clearState();
      diagnostic(state && steps[Math.max(0, (state.index || 1) - 1)] ? steps[Math.max(0, (state.index || 1) - 1)].name : "reset", "failed", { error: error.message });
      console.warn("[Dola ForceDuration/reset] flow stopped", error);
      if (sendResponse) sendResponse({ ok: false, error: error.message });
    } finally { running = false; }
  }

  async function resumeFacebookLogin(sendResponse) {
    if (running) {
      if (sendResponse) sendResponse({ ok: false, error: "Another account flow is already running" });
      return;
    }
    running = true;
    var state = await getState();
    if (!state || !state.active) { running = false; return; }
    if (state.source !== "explicit-facebook-login" || (!state.paused && Number(state.deadline) <= Date.now())) {
      await clearState();
      diagnostic("Facebook Login", "discarded stale login state; click Facebook login again");
      running = false;
      if (sendResponse) sendResponse({ ok: false, error: "Facebook login request expired" });
      return;
    }
    flowPaused = !!state.paused;
    flowCancelled = false;
    deadlineExtensionMs = 0;
    var deadline = Number(state.deadline);
    diagnostic("Facebook Login", "using the Facebook session managed by this browser profile");
    try {
      await completeFacebookLogin(deadline);
      await waitUntilRunnable();
      var accountInfo = await saveCurrentAccount("facebook");
      await clearState();
      diagnostic("Facebook Login", "completed successfully", { displayName: accountInfo.displayName });
      if (sendResponse) sendResponse({ ok: true, account: accountInfo });
    } catch (error) {
      if (error.message === "Account task stopped") {
        await clearState();
        diagnostic("Facebook Login", "task stopped by user");
        if (sendResponse) sendResponse({ ok: false, stopped: true, error: "Account task stopped" });
        return;
      }
      await clearState();
      diagnostic("Facebook Login", "failed: " + error.message);
      if (sendResponse) sendResponse({ ok: false, error: error.message });
    } finally { running = false; }
  }

  function maybeAutoLoginAfterGenerationLogout() {
    if (!/[?&]from_logout=1(?:&|$)/i.test(location.search)) return;
    api.storage.local.get([ACCOUNT_INFO_KEY, LOGIN_PREFERENCE_KEY, LAST_GENERATION_KEY, AUTO_RELOGIN_GUARD_KEY], function (data) {
      var saved = accountProfile && accountProfile.safeAccountInfo ? accountProfile.safeAccountInfo(data && data[ACCOUNT_INFO_KEY]) : null;
      var preference = data && data[LOGIN_PREFERENCE_KEY];
      var generationAt = Number(data && data[LAST_GENERATION_KEY]) || 0;
      var alreadyHandled = Number(data && data[AUTO_RELOGIN_GUARD_KEY]) || 0;
      if (!saved || !preference || preference.provider !== "facebook") return;
      if (!generationAt || Date.now() - generationAt > 120000 || alreadyHandled === generationAt) return;
      var update = {};
      update[AUTO_RELOGIN_GUARD_KEY] = generationAt;
      api.storage.local.set(update, function () {
        diagnostic("Facebook Login", "generation triggered Dola logout; starting one browser-session recovery attempt", { displayName: saved.displayName });
        setState({ active: true, source: "explicit-facebook-login", provider: "facebook", automatic: true, deadline: Date.now() + PROCESS_TIMEOUT })
          .then(function () { resumeFacebookLogin(); });
      });
    });
  }

  api.runtime.onMessage.addListener(function (message, sender, sendResponse) {
    if (!message) return;
    if (message.type === "DOLA_FD_ACCOUNT_TASK_CONTROL") {
      var action = String(message.action || "").toLowerCase();
      getState().then(async function (state) {
        if (!state || !state.active) {
          sendResponse({ ok: false, error: "No account task is active" });
          return;
        }
        if (action === "pause") {
          if (!state.paused) {
            state.paused = true;
            state.pausedAt = Date.now();
            await setState(state);
          }
          flowPaused = true;
          diagnostic("control", "account task paused");
          sendResponse({ ok: true, paused: true });
          return;
        }
        if (action === "continue") {
          var pausedFor = state.pausedAt ? Math.max(0, Date.now() - Number(state.pausedAt)) : 0;
          if (state.paused) {
            state.deadline = Number(state.deadline) + pausedFor;
            state.paused = false;
            delete state.pausedAt;
            await setState(state);
            deadlineExtensionMs += pausedFor;
          }
          flowPaused = false;
          diagnostic("control", "account task continued");
          sendResponse({ ok: true, paused: false });
          return;
        }
        if (action === "stop" || action === "end") {
          flowCancelled = true;
          flowPaused = false;
          await clearState();
          diagnostic("control", action === "end" ? "account task ended; reloading Dola" : "account task stopped");
          sendResponse({ ok: true, stopped: true, ended: action === "end" });
          if (action === "end") setTimeout(function () { location.reload(); }, 250);
          return;
        }
        sendResponse({ ok: false, error: "Unknown account task control" });
      }).catch(function (error) { sendResponse({ ok: false, error: error.message }); });
      return true;
    }
    if (running && (message.type === "DOLA_FD_RESET_ACCOUNT" || message.type === "DOLA_FD_FACEBOOK_LOGIN")) {
      sendResponse({ ok: false, error: "Another account flow is already running" });
      return;
    }
    if (message.type === "DOLA_FD_RESET_ACCOUNT") {
      flowPaused = false; flowCancelled = false; deadlineExtensionMs = 0;
      setState({ active: true, source: "explicit-reset", index: 0, deadline: Date.now() + PROCESS_TIMEOUT }).then(function () { resume(sendResponse); });
      return true;
    }
    if (message.type === "DOLA_FD_FACEBOOK_LOGIN") {
      flowPaused = false; flowCancelled = false; deadlineExtensionMs = 0;
      setState({ active: true, source: "explicit-facebook-login", provider: "facebook", deadline: Date.now() + PROCESS_TIMEOUT }).then(function () { resumeFacebookLogin(sendResponse); });
      return true;
    }
  });

  // Resume only an explicitly started account operation after Dola navigation.
  getState().then(function (state) {
    if (!state || !state.active) { maybeAutoLoginAfterGenerationLogout(); return; }
    if (state.source === "explicit-reset") resume();
    else if (state.source === "explicit-facebook-login") resumeFacebookLogin();
    else clearState();
  });
}());
