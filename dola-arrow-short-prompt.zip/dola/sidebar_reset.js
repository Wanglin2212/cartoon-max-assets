(function () {
  "use strict";
  var api = typeof browser !== "undefined" ? browser : chrome;
  var button = document.getElementById("resetAccount");
  var facebookButton = document.getElementById("facebookLogin");
  var clearSavedButton = document.getElementById("clearSavedAccount");
  var pauseTaskButton = document.getElementById("pauseAccountTask");
  var continueTaskButton = document.getElementById("continueAccountTask");
  var stopTaskButton = document.getElementById("stopAccountTask");
  var endTaskButton = document.getElementById("endAccountTask");
  var taskStateLabel = document.getElementById("accountTaskState");
  var savedAccountName = document.getElementById("savedAccountName");
  var savedAccountDetail = document.querySelector(".account-card small");
  var status = document.getElementById("status");
  var logPanel = document.getElementById("resetLog");
  var resetEntries = [];
  var workflowEntries = [];
  var forceEntries = [];
  if (!button) return;
  function showTaskState(state) {
    var active = !!(state && state.active);
    var paused = active && !!state.paused;
    if (pauseTaskButton) pauseTaskButton.disabled = !active || paused;
    if (continueTaskButton) continueTaskButton.disabled = !paused;
    if (stopTaskButton) stopTaskButton.disabled = !active;
    if (endTaskButton) endTaskButton.disabled = !active;
    if (taskStateLabel) {
      taskStateLabel.className = "task-state" + (paused ? " paused" : (active ? " running" : ""));
      taskStateLabel.textContent = paused ? "⏸ RESET PAUSED — click ▶ Resume to continue clicking" : (active ? "▶ Reset automation is running" : "");
    }
  }
  function sendTaskControl(action) {
    api.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      var tab = tabs && tabs[0];
      if (!tab || !/^https?:\/\/(www\.)?dola\.com\//i.test(tab.url || "")) {
        status.textContent = "Open the Dola task tab first.";
        status.style.color = "#c0392b";
        return;
      }
      api.tabs.sendMessage(tab.id, { type: "DOLA_FD_ACCOUNT_TASK_CONTROL", action: action }, function (result) {
        if (api.runtime.lastError || !result || !result.ok) {
          status.textContent = result && result.error || "Account task control could not be applied.";
          status.style.color = "#c0392b";
          return;
        }
        status.textContent = action === "pause" ? "Account task paused. Continue when ready." : action === "continue" ? "Account task continued." : action === "end" ? "Account task ended. Reloading Dola…" : "Account task stopped on the current screen.";
        status.style.color = action === "stop" || action === "end" ? "#c0392b" : "#666";
      });
    });
  }
  function renderLog() {
    if (!logPanel) return;
    var log = resetEntries.concat(workflowEntries, forceEntries).sort(function (a, b) {
      return String(a.time || "").localeCompare(String(b.time || ""));
    });
    logPanel.textContent = log.slice(-60).map(function (entry) {
      return (entry.time || "").slice(11, 19) + "  [" + (entry.step || entry.status || "activity") + "] " + entry.message;
    }).join("\n");
    logPanel.scrollTop = logPanel.scrollHeight;
  }
  function setResetLog(log) { resetEntries = Array.isArray(log) ? log : []; renderLog(); }
  function setWorkflowLog(log) { workflowEntries = Array.isArray(log) ? log : []; renderLog(); }
  function setForceLog(log) { forceEntries = Array.isArray(log) ? log : []; renderLog(); }
  function showSavedAccount(account) {
    var valid = account && account.provider === "facebook" && typeof account.displayName === "string" && account.displayName.trim();
    if (!valid) {
      if (savedAccountName) savedAccountName.textContent = "No saved Facebook account";
      if (savedAccountDetail) savedAccountDetail.textContent = "Uses the Facebook session already signed into this browser profile. Cookies are never copied.";
      if (clearSavedButton) clearSavedButton.disabled = true;
      if (facebookButton) { facebookButton.textContent = "Log in with Facebook session"; facebookButton.removeAttribute("title"); }
      return;
    }
    var displayName = account.displayName.trim();
    if (savedAccountName) savedAccountName.textContent = displayName;
    var date = new Date(account.lastLoginAt);
    var when = Number.isFinite(date.getTime()) ? date.toLocaleString() : "recently";
    if (savedAccountDetail) savedAccountDetail.textContent = "Facebook • Last successful login: " + when;
    if (clearSavedButton) clearSavedButton.disabled = false;
    if (facebookButton) { facebookButton.textContent = "Log in again as " + displayName.slice(0, 32); facebookButton.title = displayName; }
  }
  function showDiagnostic(entry) {
    if (!entry || !entry.message) return;
    if (/^waiting for control$/i.test(entry.message) || /^waiting for the recorded/i.test(entry.message) || /^waiting for transition$/i.test(entry.message)) {
      status.textContent = "";
      return;
    }
    var facebookSucceeded = entry.step === "Facebook Login" && /completed successfully/i.test(entry.message);
    var succeeded = entry.step === "success" || facebookSucceeded;
    status.textContent = entry.step === "success" ? "✓ Account reset and Facebook login completed successfully." : (facebookSucceeded ? "✓ Facebook session login completed successfully." : "[" + (entry.step || "reset") + "] " + entry.message);
    status.style.color = succeeded || entry.message === "all recorded steps completed" ? "#1a7f37" : (entry.message.indexOf("failed") >= 0 || entry.message.indexOf("timeout") >= 0 ? "#c0392b" : "#666");
  }
  try {
    api.storage.onChanged.addListener(function (changes, area) {
      if (area === "local" && changes.dolaResetDiagnostic) showDiagnostic(changes.dolaResetDiagnostic.newValue);
      if (area === "local" && changes.dolaResetDiagnosticLog) setResetLog(changes.dolaResetDiagnosticLog.newValue);
      if (area === "local" && changes.dolaWorkflowDiagnosticLog) setWorkflowLog(changes.dolaWorkflowDiagnosticLog.newValue);
      if (area === "local" && changes.dolaForceDiagnosticLog) setForceLog(changes.dolaForceDiagnosticLog.newValue);
      if (area === "local" && changes.dolaSavedAccount) showSavedAccount(changes.dolaSavedAccount.newValue);
      if (area === "local" && changes.dolaResetFlow) showTaskState(changes.dolaResetFlow.newValue);
    });
    api.storage.local.get(["dolaResetDiagnostic", "dolaResetDiagnosticLog", "dolaWorkflowDiagnosticLog", "dolaForceDiagnosticLog", "dolaSavedAccount", "dolaResetFlow"], function (data) {
      showDiagnostic(data && data.dolaResetDiagnostic);
      setResetLog(data && data.dolaResetDiagnosticLog);
      setWorkflowLog(data && data.dolaWorkflowDiagnosticLog);
      setForceLog(data && data.dolaForceDiagnosticLog);
      showSavedAccount(data && data.dolaSavedAccount);
      showTaskState(data && data.dolaResetFlow);
    });
  } catch (error) { status.textContent = "Diagnostics unavailable"; }
  if (pauseTaskButton) pauseTaskButton.addEventListener("click", function () { sendTaskControl("pause"); });
  if (continueTaskButton) continueTaskButton.addEventListener("click", function () { sendTaskControl("continue"); });
  if (stopTaskButton) stopTaskButton.addEventListener("click", function () { sendTaskControl("stop"); });
  if (endTaskButton) endTaskButton.addEventListener("click", function () { sendTaskControl("end"); });
  if (facebookButton) facebookButton.addEventListener("click", function () {
    status.textContent = "[Facebook Login] Opening Dola's Facebook login with this browser profile…";
    status.style.color = "#666";
    api.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      var tab = tabs && tabs[0];
      if (!tab || !/^https?:\/\/(www\.)?dola\.com\//i.test(tab.url || "")) {
        status.textContent = "Open a dola.com tab first.";
        status.style.color = "#c0392b";
        return;
      }
      api.tabs.sendMessage(tab.id, { type: "DOLA_FD_FACEBOOK_LOGIN" }, function (result) {
        if (api.runtime.lastError) {
          status.textContent = "Facebook login is continuing on Dola. Watch the activity log.";
          return;
        }
        if (result && result.ok) {
          showSavedAccount(result.account);
          status.textContent = "✓ Logged in with Facebook as " + result.account.displayName + ".";
          status.style.color = "#1a7f37";
        } else {
          status.textContent = result && result.error || "Facebook session login could not be completed.";
          status.style.color = "#c0392b";
        }
      });
    });
  });
  if (clearSavedButton) clearSavedButton.addEventListener("click", function () {
    api.storage.local.remove(["dolaSavedAccount", "dolaLoginPreference"], function () {
      showSavedAccount(null);
      status.textContent = "Saved account label removed. Browser cookies were not changed.";
      status.style.color = "#666";
    });
  });
  button.addEventListener("click", function () {
    if (!confirm("Reset account? This permanently deletes the current Dola account, then follows the recorded login flow. This cannot be undone.")) return;
    status.textContent = "[reset] Starting account reset…";
    status.style.color = "#c0392b";
    api.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      var tab = tabs && tabs[0];
      if (!tab || !/^https?:\/\/(www\.)?dola\.com\//i.test(tab.url || "")) {
        status.textContent = "Open a dola.com tab first.";
        return;
      }
      api.tabs.sendMessage(tab.id, { type: "DOLA_FD_RESET_ACCOUNT" }, function (result) {
        if (api.runtime.lastError) { status.textContent = "Tab not ready — reload dola.com."; return; }
        status.textContent = result && result.ok ? "Account reset flow completed." : (result && result.error || "Account reset flow could not be completed.");
      });
    });
  });
}());
