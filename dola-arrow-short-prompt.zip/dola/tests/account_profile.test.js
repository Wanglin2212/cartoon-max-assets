"use strict";

const assert = require("node:assert/strict");
const profile = require("../account_profile.js");

const saved = profile.createAccountInfo("facebook", "  Example   Person  ", "2026-09-12T12:00:00.000Z");
assert.deepEqual(Object.keys(saved).sort(), ["displayName", "id", "lastLoginAt", "provider"]);
assert.equal(saved.provider, "facebook");
assert.equal(saved.displayName, "Example Person");
assert.equal(saved.lastLoginAt, "2026-09-12T12:00:00.000Z");
assert.match(saved.id, /^facebook:[0-9a-f]{8}$/);

const hostile = profile.safeAccountInfo({
  provider: "facebook",
  displayName: "Example Person",
  lastLoginAt: "2026-09-12T12:00:00.000Z",
  cookie: "must-not-survive",
  accessToken: "must-not-survive",
  password: "must-not-survive"
});
assert.deepEqual(Object.keys(hostile).sort(), ["displayName", "id", "lastLoginAt", "provider"]);
assert.equal(Object.prototype.hasOwnProperty.call(hostile, "cookie"), false);
assert.equal(Object.prototype.hasOwnProperty.call(hostile, "accessToken"), false);
assert.equal(Object.prototype.hasOwnProperty.call(hostile, "password"), false);
assert.equal(profile.createAccountInfo("google", "Example Person"), null);
assert.equal(profile.createAccountInfo("facebook", ""), null);

console.log("Account profile tests passed: Facebook metadata is normalized and credential fields are excluded.");
