"use strict";

const assert = require("node:assert/strict");
const duration = require("../dola_force_duration.js");
const nativeStringify = JSON.stringify.bind(JSON);

function generationBody(existingDuration) {
  return nativeStringify({
    request_id: "keep-me",
    auth_token: "untouched-token",
    chat_ability: {
      ability_type: 17,
      ability_param: nativeStringify({
        duration: existingDuration,
        model: "seedance_v2.0",
        ratio: "16:9",
        resolution: "720p",
        unrelated: "preserve-me"
      })
    },
    messages: [{ role: "user", content: "make a video" }]
  });
}

function currentDolaGenerationBody(existingDuration) {
  const chatAbility = nativeStringify({
    ability_type: 17,
    ability_param: nativeStringify({
      duration: existingDuration,
      model: "seedance_v2.0",
      ratio: "9:16",
      resolution: "720p",
      unrelated: "preserve-current-schema"
    })
  });
  return nativeStringify({
    messages: [{
      unique_id: "keep-current-message",
      ext: { chat_ability: chatAbility, session_key: "untouched-session" }
    }]
  });
}

function patchedParameters(result) {
  const body = JSON.parse(result.bodyText);
  return { body, parameters: JSON.parse(body.chat_ability.ability_param) };
}

function currentDolaParameters(bodyText) {
  const body = JSON.parse(bodyText);
  const ability = JSON.parse(body.messages[0].ext.chat_ability);
  return { body, ability, parameters: JSON.parse(ability.ability_param) };
}

async function testPresets() {
  for (const seconds of [5, 10, 15, 20, 30, 60]) {
    const result = duration.patchPayload(generationBody(10), seconds);
    const parsed = patchedParameters(result);
    assert.equal(parsed.parameters.duration, seconds, "preset " + seconds + "s");
    assert.equal(parsed.body.request_id, "keep-me");
    assert.equal(parsed.body.auth_token, "untouched-token");
    assert.equal(parsed.parameters.model, "seedance_v2.0");
    assert.equal(parsed.parameters.ratio, "16:9");
    assert.equal(parsed.parameters.resolution, "720p");
    assert.equal(parsed.parameters.unrelated, "preserve-me");
  }
}

async function testCustomOverride() {
  assert.equal(duration.selectedSeconds(30, "47"), 47);
  assert.equal(duration.selectedSeconds(30, "120"), 120);
  assert.equal(duration.selectedSeconds(30, ""), 30);
  assert.equal(duration.selectedSeconds(30, "0"), 0, "a filled invalid custom value must not fall back to preset");
  assert.equal(duration.selectedSeconds(30, "12.5"), 0, "a fractional custom value must not be silently shortened");
  assert.equal(duration.selectedSeconds(30, "not-a-number"), 0, "a filled invalid custom value must not fall back to preset");
  const result = duration.patchPayload(generationBody(10), duration.selectedSeconds(10, "47"));
  assert.equal(patchedParameters(result).parameters.duration, 47);
}

async function testCurrentNestedDolaSchema() {
  const source = currentDolaGenerationBody(10);
  const result = duration.patchPayload(source, 30);
  const parsed = currentDolaParameters(result.bodyText);
  assert.equal(result.matched, true);
  assert.equal(result.changed, true);
  assert.equal(parsed.ability.ability_type, 17);
  assert.equal(parsed.parameters.duration, 30);
  assert.equal(parsed.parameters.model, "seedance_v2.0");
  assert.equal(parsed.parameters.ratio, "9:16");
  assert.equal(parsed.parameters.resolution, "720p");
  assert.equal(parsed.parameters.unrelated, "preserve-current-schema");
  assert.equal(parsed.body.messages[0].unique_id, "keep-current-message");
  assert.equal(parsed.body.messages[0].ext.session_key, "untouched-session");

  const exact = duration.patchPayload(result.bodyText, 30);
  assert.equal(exact.matched, true);
  assert.equal(exact.changed, false);
  assert.equal(exact.bodyText, result.bodyText);
}

async function testSelectedVideoOptions() {
  const selected = {
    enabled: true,
    duration: 30,
    ratio: "9:16",
    model: "seedance_v2.5",
    resolution: "1080p"
  };
  const result = duration.patchPayload(generationBody(10), selected);
  const parsed = patchedParameters(result);
  assert.equal(result.matched, true);
  assert.equal(result.applied, true);
  assert.equal(parsed.parameters.duration, 30);
  assert.equal(parsed.parameters.ratio, "9:16");
  assert.equal(parsed.parameters.model, "seedance_v2.5");
  assert.equal(parsed.parameters.resolution, "1080p");
  assert.equal(parsed.parameters.unrelated, "preserve-me");
  assert.equal(parsed.body.auth_token, "untouched-token");

  for (const resolution of ["2k", "4k"]) {
    const highResolution = Object.assign({}, selected, { resolution, duration: 180 });
    const patched = duration.patchPayload(generationBody(10), highResolution);
    assert.equal(patched.applied, true);
    assert.equal(patchedParameters(patched).parameters.resolution, resolution);
    assert.equal(patchedParameters(patched).parameters.duration, 180);
    assert.equal(patchedParameters(patched).body.auth_token, "untouched-token");
  }

  const exact = duration.patchPayload(result.bodyText, selected);
  assert.equal(exact.changed, false);
  assert.equal(exact.applied, true);
  assert.equal(exact.bodyText, result.bodyText);

  assert.deepEqual(duration.normalizeSettings({ duration: 30, ratio: "invalid", model: "other", resolution: "8k" }), {
    enabled: true,
    duration: 30,
    ratio: "",
    model: "",
    resolution: ""
  });
}

async function testUnrelatedJsonUntouched() {
  const unrelated = JSON.stringify({
    messages: [{ role: "user", content: "ordinary chat" }],
    duration: 10,
    preferences: { duration: 5 },
    cookie: "do-not-touch"
  });
  const result = duration.patchPayload(unrelated, 30);
  assert.equal(result.changed, false);
  assert.equal(result.matched, false);
  assert.equal(result.bodyText, unrelated);

  const metadataOnly = nativeStringify({ ability_type: 17, label: "video skill metadata", duration: 10 });
  const metadataResult = duration.patchPayload(metadataOnly, 30);
  assert.equal(metadataResult.changed, false);
  assert.equal(metadataResult.matched, false);
  assert.equal(metadataResult.bodyText, metadataOnly, "ability metadata without an ability_param is not a generation settings object");
}

async function testUnsupportedDurationResponse() {
  const refusal = duration.unsupportedDurationResponse(
    "A video longer than 10s is not supported. Continue generate with 10s?",
    30
  );
  assert.equal(refusal.unsupported, true);
  assert.equal(refusal.requestedSeconds, 30);
  assert.equal(refusal.offeredSeconds, 10);
  assert.equal(duration.unsupportedDurationResponse("Your 30s video is being generated.", 30).unsupported, false);
}

async function testLegacyHookNeutralization() {
  let disableCalls = 0;
  const legacy = {
    _state: { enabled: true, duration: 30 },
    disable() { disableCalls += 1; this._state.enabled = false; },
    set(value) { this._state.enabled = true; this._state.duration = value; },
    apply(value) { this.set(value); return Promise.resolve(true); },
    enabled() { return this._state.enabled; }
  };

  assert.equal(duration.neutralizeLegacyApi(legacy), true);
  assert.equal(disableCalls, 1);
  assert.equal(legacy._state.enabled, false);
  assert.equal(legacy._state.duration, 0);
  assert.equal(legacy.set(60), 0, "legacy settings messages must not re-enable the old hook");
  assert.equal(legacy._state.enabled, false);
  assert.equal(await legacy.apply(60), false);
  assert.equal(legacy.enabled(), false);
  assert.equal(duration.neutralizeLegacyApi({ __dolaForceDurationVersion: "1.10.13" }), false);
}

async function testAuthenticationResponsesRemainUntouched() {
  const generationUrl = "https://www.dola.com/samantha/chat/completion";
  assert.equal(duration.shouldMaskTransientLogout(429, generationUrl, "0", null), false);
  assert.equal(duration.shouldMaskTransientLogout(429, generationUrl, null, "0"), false);
  assert.equal(duration.shouldMaskTransientLogout(401, generationUrl, "0", null), false);
  assert.equal(duration.shouldMaskTransientLogout(429, "https://www.dola.com/passport/session", "0", null), false);
  assert.equal(duration.shouldMaskTransientLogout(429, generationUrl, "1", "1"), false);

  const original = new Response("busy", {
    status: 429,
    headers: { "x-tt-flow-login": "0", "x-request-id": "keep-me" }
  });
  const protectedResult = duration.protectTransientLogoutResponse(original, generationUrl);
  assert.equal(protectedResult.details.logoutSuppressed, false);
  assert.strictEqual(protectedResult.response, original);
  assert.equal(protectedResult.response.status, 429);
  assert.equal(protectedResult.response.headers.get("x-tt-flow-login"), "0");
  assert.equal(protectedResult.response.headers.get("x-request-id"), "keep-me");
  assert.equal(protectedResult.response.clone().headers.get("x-tt-flow-login"), "0");
  assert.equal(await protectedResult.response.text(), "busy");

  const authenticationFailure = new Response("unauthorized", { status: 401, headers: { "x-tt-flow-login": "0" } });
  assert.strictEqual(duration.protectTransientLogoutResponse(authenticationFailure, generationUrl).response, authenticationFailure);
}

async function testReadsSettingsBeforeEveryRequest() {
  const originalFetch = global.fetch;
  const captures = [];
  const responses = [];
  const patches = [];
  let selected = { enabled: true, duration: 10, ratio: "16:9", model: "seedance_v2.0", resolution: "720p" };
  global.fetch = async function (input, init) {
    captures.push({ input, init, body: init && init.body, credentials: init && init.credentials, headers: init && init.headers });
    return { ok: true, status: 200, headers: new Headers() };
  };
  try {
    const stringifyBeforeInstall = nativeStringify;
    assert.equal(duration.install(() => selected, (result, details) => patches.push({ result, details }), (result) => responses.push(result)), true);
    const firstSignedBody = duration.patchPayload(generationBody(5), selected).bodyText;
    await global.fetch("https://www.dola.com/samantha/chat/completion", { method: "POST", credentials: "include", headers: { "x-session": "keep" }, body: firstSignedBody });
    selected = { enabled: true, duration: 30, ratio: "9:16", model: "seedance_v2.5", resolution: "1080p" };
    const secondSignedBody = duration.patchPayload(generationBody(5), selected).bodyText;
    await global.fetch("https://www.dola.com/samantha/chat/completion", { method: "POST", credentials: "include", headers: { "x-session": "keep" }, body: secondSignedBody });
    const unrelatedBody = generationBody(5);
    await global.fetch("https://www.dola.com/passport/session", { method: "POST", credentials: "include", body: unrelatedBody });
    const preflightAbility = JSON.stringify({
      ability_type: 17,
      ability_param: nativeStringify({ duration: 5, model: "seedance_v2.0", ratio: "9:16" })
    });
    const preflightParameters = JSON.parse(JSON.parse(preflightAbility).ability_param);
    assert.equal(preflightParameters.duration, 30, "Dola ability serialization must be patched before request signing");
    assert.equal(preflightParameters.model, "seedance_v2.5");
    assert.equal(preflightParameters.ratio, "9:16");
    assert.equal(preflightParameters.resolution, "1080p");
    const authenticatedBody = nativeStringify({ messages: [{ ext: { chat_ability: preflightAbility } }] });
    const authenticatedRequest = new Request("https://www.dola.com/samantha/chat/completion", {
      method: "POST",
      credentials: "include",
      headers: { "x-session": "request-object" },
      body: authenticatedBody
    });
    await global.fetch(authenticatedRequest);
    const capturesBeforeBlockedRequest = captures.length;
    const unpatchedRequest = new Request(new URL("https://www.dola.com/samantha/chat/completion"), {
      method: "POST",
      credentials: "include",
      headers: { "x-session": "must-remain-untouched" },
      body: generationBody(5)
    });
    await assert.rejects(global.fetch(unpatchedRequest), function (error) {
      return error && error.code === "DOLA_SETTINGS_NOT_APPLIED";
    }, "a Request object without the exact selected settings must be blocked instead of silently submitted");
    assert.equal(captures.length, capturesBeforeBlockedRequest, "blocked Request objects must never reach native fetch");
    await assert.rejects(global.fetch("https://www.dola.com/samantha/chat/completion", { method: "POST", credentials: "include", headers: { "x-session": "signed-before-body-change" }, body: generationBody(5) }), function (error) {
      return error && error.code === "DOLA_SETTINGS_NOT_APPLIED";
    }, "an unpatched string body must be blocked instead of being changed after request signing");
    assert.equal(captures.length, capturesBeforeBlockedRequest, "an unpatched signed body must never reach native fetch");
    assert.equal(patchedParameters({ bodyText: captures[0].body }).parameters.duration, 10);
    const second = patchedParameters({ bodyText: captures[1].body }).parameters;
    assert.equal(second.duration, 30);
    assert.equal(second.model, "seedance_v2.5");
    assert.equal(second.ratio, "9:16");
    assert.equal(second.resolution, "1080p");
    assert.equal(captures[0].credentials, "include");
    assert.equal(captures[1].credentials, "include");
    assert.deepEqual(captures[0].headers, { "x-session": "keep" });
    assert.equal(captures[2].body, unrelatedBody, "non-generation endpoints must be untouched");
    assert.strictEqual(captures[3].input, authenticatedRequest, "authenticated Request objects must pass through by identity");
    assert.equal(captures[3].init, undefined, "authenticated Request init must not be replaced");
    const authenticatedParameters = currentDolaParameters(await authenticatedRequest.clone().text()).parameters;
    assert.equal(authenticatedParameters.duration, 30);
    assert.equal(authenticatedParameters.model, "seedance_v2.5");
    assert.equal(authenticatedParameters.ratio, "9:16");
    assert.equal(authenticatedParameters.resolution, "1080p");
    assert.equal(responses.length, 3, "only recognized generation endpoints receive response diagnostics");
    assert.equal(responses.every((response) => response.status === 200 && response.logoutSuppressed === false), true);
    assert.equal(responses.every((response) => response.forceApplied === true), true, "each enabled generation response must be tied to a duration patch");
    assert.equal(patches.some((entry) => entry.details && entry.details.preflight && entry.result.seconds === 30), true);
    const finalPatches = patches.filter((entry) => entry.details && entry.details.finalRequest);
    assert.equal(finalPatches.length, 5, "every final generation attempt must produce an exact audit result, including blocked attempts");
    assert.equal(new Set(finalPatches.map((entry) => entry.details.requestId)).size, 5, "each final request audit must have a unique request id");
    assert.equal(duration.requestUrl(new URL("https://www.dola.com/samantha/chat/completion")), "https://www.dola.com/samantha/chat/completion");

    const unrelatedAbility = JSON.stringify({ ability_type: 16, ability_param: nativeStringify({ duration: 5, model: "other" }) });
    assert.equal(JSON.parse(JSON.parse(unrelatedAbility).ability_param).duration, 5, "non-video ability serialization must remain untouched");
    assert.equal(typeof stringifyBeforeInstall, "function");
  } finally {
    duration.uninstall();
    global.fetch = originalFetch;
  }
}

(async function run() {
  await testPresets();
  await testCustomOverride();
  await testCurrentNestedDolaSchema();
  await testSelectedVideoOptions();
  await testUnrelatedJsonUntouched();
  await testUnsupportedDurationResponse();
  await testLegacyHookNeutralization();
  await testAuthenticationResponsesRemainUntouched();
  await testReadsSettingsBeforeEveryRequest();
  console.log("Focused generation-setting tests passed: presets, custom override, model/ratio/resolution, current nested Dola schema, unrelated JSON, pre-sign serialization, Request identity/blocking, refusal handling, untouched authentication responses, request URLs, legacy-hook neutralization, and per-request reads.");
}()).catch(function (error) {
  console.error(error);
  process.exitCode = 1;
});
