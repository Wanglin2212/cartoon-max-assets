"use strict";

const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const test = require("node:test");
const vm = require("node:vm");

const root = path.resolve(__dirname, "..");
const mediaCaptureSource = fs.readFileSync(
  path.join(root, "dola_media_capture.js"),
  "utf8",
);
const policySource = fs.readFileSync(
  path.join(root, "video_download_policy.js"),
  "utf8",
);
const downloadSource = fs.readFileSync(path.join(root, "download.js"), "utf8");

function createHarness(responsePayloads = [], videos = []) {
  const pageMessageListeners = [];
  const runtimeListeners = [];
  const downloadRequests = [];
  const fetchCalls = [];
  const xhrCalls = [];
  const responses = responsePayloads.slice();
  let windowProxy;

  class FakeXMLHttpRequest {
    constructor() {
      this.responseType = "";
      this.responseText = "";
      this.responseURL = "";
      this.listeners = {};
    }
    open(method, url) {
      this.method = method;
      this.url = url;
    }
    addEventListener(type, listener) {
      (this.listeners[type] || (this.listeners[type] = [])).push(listener);
    }
    send(body) {
      xhrCalls.push({ method: this.method, url: this.url, body });
      this.responseText = JSON.stringify(responses.shift() || {});
      this.responseURL = new URL(this.url, "https://www.dola.com/chat").href;
      Promise.resolve().then(() => (this.listeners.loadend || []).forEach((listener) => listener.call(this)));
    }
  }

  function responseFor(payload) {
    const text = JSON.stringify(payload);
    return {
      clone() {
        return { text: async () => text };
      },
      text: async () => text,
    };
  }

  const context = {
    console,
    URL,
    Date,
    Promise,
    Map,
    Set,
    location: {
      href: "https://www.dola.com/chat",
      origin: "https://www.dola.com",
      pathname: "/chat",
    },
    performance: { getEntriesByType: () => [] },
    document: {
      body: null,
      documentElement: {},
      querySelectorAll(selector) { return selector === "video" ? videos : []; },
      getElementById: () => null,
    },
    getComputedStyle: () => ({ position: "static" }),
    MutationObserver: class {
      observe() {}
    },
    XMLHttpRequest: FakeXMLHttpRequest,
    setTimeout(callback) {
      Promise.resolve().then(callback);
      return 1;
    },
    clearTimeout() {},
    setInterval: () => 1,
    clearInterval() {},
    fetch(input, init) {
      fetchCalls.push({ input, init });
      return Promise.resolve(responseFor(responses.shift() || {}));
    },
    chrome: {
      runtime: {
        lastError: null,
        onMessage: {
          addListener(listener) {
            runtimeListeners.push(listener);
          },
        },
        sendMessage(message, callback) {
          if (message.type === "DOLA_FD_DOWNLOAD") {
            downloadRequests.push(Array.from(message.urls, String));
            callback({ ok: true, count: message.urls.length });
            return;
          }
          callback({ ok: false });
        },
      },
      storage: {
        local: {
          get(_keys, callback) {
            callback({});
          },
          set(_update, callback) {
            if (callback) callback();
          },
        },
        onChanged: { addListener() {} },
      },
    },
    addEventListener(type, listener) {
      if (type === "message") pageMessageListeners.push(listener);
    },
    postMessage(message) {
      for (const listener of pageMessageListeners) {
        listener({
          source: windowProxy,
          origin: "https://www.dola.com",
          data: message,
        });
      }
    },
  };

  context.window = context;
  context.top = context;
  context.globalThis = context;
  vm.createContext(context);
  windowProxy = vm.runInContext("window", context);
  vm.runInContext(mediaCaptureSource, context, {
    filename: "dola_media_capture.js",
  });
  vm.runInContext(policySource, context, {
    filename: "video_download_policy.js",
  });
  vm.runInContext(downloadSource, context, { filename: "download.js" });

  return {
    window: windowProxy,
    runtimeListeners,
    downloadRequests,
    fetchCalls,
    xhrCalls,
  };
}

async function flushPromises() {
  await new Promise((resolve) => setImmediate(resolve));
}

async function capturePlayInfo(harness) {
  const response = await harness.window.fetch(
    "https://www.dola.com/samantha/media/get_play_info?from=chat",
    {
      method: "POST",
      credentials: "same-origin",
      body: JSON.stringify({ request: "unchanged" }),
    },
  );
  assert.ok(response, "the capture wrapper must preserve the fetch response");
  await flushPromises();
}

async function invokeDownload(harness, type) {
  assert.equal(harness.runtimeListeners.length, 1);
  return new Promise((resolve) => {
    const handled = harness.runtimeListeners[0]({ type }, {}, resolve);
    assert.equal(handled, true, type + " must keep the response channel open");
  });
}

test("current play-info endpoint is captured and replayed for Download latest", async () => {
  const url = "https://cdn.example.test/assets/video-flat.mp4?token=fresh";
  const payload = { data: { play_url: url } };
  const harness = createHarness([payload]);

  await capturePlayInfo(harness);
  const result = await invokeDownload(harness, "DOLA_FD_DL_LATEST");

  assert.equal(result.ok, true);
  assert.equal(result.count, 1);
  assert.deepEqual(harness.downloadRequests, [[url]]);
  assert.equal(harness.fetchCalls.length, 1);
  assert.equal(
    harness.fetchCalls[0].input,
    "https://www.dola.com/samantha/media/get_play_info?from=chat",
  );
  assert.equal(harness.fetchCalls[0].init.credentials, "same-origin");
});

test("Download latest resolves the current media play-info endpoint with key", async () => {
  const clean = "https://cdn.example.test/video/tos/current-clean?token=fresh";
  const player = "https://cdn.example.test/player?vid=current-video";
  const video = {
    dataset: { dolaFdDecorated: "1" },
    currentSrc: player,
    src: player,
    getAttribute(name) { return name === "src" ? player : ""; },
    querySelectorAll() { return []; },
    closest() { return null; },
    parentElement: null,
  };
  const harness = createHarness([
    { data: { original_media_info: { main_url: clean } } },
  ], [video]);

  const result = await invokeDownload(harness, "DOLA_FD_DL_LATEST");

  assert.equal(result.ok, true);
  assert.deepEqual(harness.downloadRequests, [[clean]]);
  const request = harness.fetchCalls.find((call) => call.input === "/samantha/media/get_play_info");
  assert.ok(request, "the current play-info endpoint must be attempted first");
  assert.equal(request.init.credentials, "include");
  assert.deepEqual(JSON.parse(request.init.body), { key: "current-video" });
});

test("Download latest falls back to Dola's ordinary logo player file", async () => {
  const player = "https://cdn.example.test/player/video.mp4?logo_type=watermark";
  const video = {
    dataset: { dolaFdDecorated: "1" },
    currentSrc: player,
    src: player,
    getAttribute(name) { return name === "src" ? player : ""; },
    querySelectorAll() { return []; },
    closest() { return null; },
    parentElement: null,
  };
  const harness = createHarness([], [video]);

  const result = await invokeDownload(harness, "DOLA_FD_DL_LATEST");

  assert.equal(result.ok, true);
  assert.deepEqual(harness.downloadRequests, [[player]]);
});

test("current XHR play-info metadata is captured without changing the request", async () => {
  const clean = "https://cdn.example.test/video/tos/xhr-clean?token=fresh";
  const harness = createHarness([
    { data: { original_media_info: { main_url: clean } } },
  ]);
  const xhr = new harness.window.XMLHttpRequest();
  xhr.open("POST", "/samantha/media/get_play_info?from=chat");
  xhr.send(JSON.stringify({ key: "xhr-video", untouched: true }));
  await flushPromises();

  const result = await invokeDownload(harness, "DOLA_FD_DL_LATEST");

  assert.equal(result.ok, true);
  assert.deepEqual(harness.downloadRequests, [[clean]]);
  assert.deepEqual(harness.xhrCalls, [{
    method: "POST",
    url: "/samantha/media/get_play_info?from=chat",
    body: JSON.stringify({ key: "xhr-video", untouched: true }),
  }]);
});

test("Download latest keeps the trusted play_url meaning through url_list", async () => {
  const url = "https://cdn.example.test/assets/video-nested.mp4?token=fresh";
  const payload = { data: { play_url: { url_list: [url] } } };
  const harness = createHarness([payload]);

  await capturePlayInfo(harness);
  const result = await invokeDownload(harness, "DOLA_FD_DL_LATEST");

  assert.equal(result.ok, true);
  assert.equal(result.count, 1);
  assert.deepEqual(harness.downloadRequests, [[url]]);
});

test("Download latest recognizes main_url inside original_media_info", async () => {
  const url = "https://cdn.example.test/assets/video-main.mp4?token=fresh";
  const payload = { data: { original_media_info: { main_url: url } } };
  const harness = createHarness([payload]);

  await capturePlayInfo(harness);
  const result = await invokeDownload(harness, "DOLA_FD_DL_LATEST");

  assert.equal(result.ok, true);
  assert.equal(result.count, 1);
  assert.deepEqual(harness.downloadRequests, [[url]]);
});

test("Download all preserves two distinct clean videos", async () => {
  const first = "https://cdn.example.test/assets/video-one.mp4?token=one";
  const second = "https://cdn.example.test/assets/video-two.mp4?token=two";
  const harness = createHarness([
    { data: { play_url: first } },
    { data: { play_url: second } },
  ]);

  await capturePlayInfo(harness);
  await capturePlayInfo(harness);
  const result = await invokeDownload(harness, "DOLA_FD_DL_ALL");

  assert.equal(result.ok, true);
  assert.equal(result.count, 2);
  assert.equal(harness.downloadRequests.length, 1);
  assert.deepEqual(new Set(harness.downloadRequests[0]), new Set([first, second]));
});
