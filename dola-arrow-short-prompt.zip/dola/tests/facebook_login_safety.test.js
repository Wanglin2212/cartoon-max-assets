"use strict";

const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");

const root = path.resolve(__dirname, "..");
const manifest = JSON.parse(fs.readFileSync(path.join(root, "manifest.json"), "utf8"));
const resetSource = fs.readFileSync(path.join(root, "reset_account.js"), "utf8");
const sidebar = fs.readFileSync(path.join(root, "sidebar.html"), "utf8");

assert.equal(manifest.version, "1.10.28");
assert.equal(manifest.permissions.includes("cookies"), false, "raw cookie access must not be requested");
assert.equal(manifest.host_permissions.some((value) => /facebook\.com/i.test(value)), false, "Facebook page access must remain browser-managed");

const accountContentScript = manifest.content_scripts.find((entry) => entry.js.includes("reset_account.js"));
assert.deepEqual(accountContentScript.js, ["account_profile.js", "facebook_provider_matcher.js", "reset_account.js"]);
assert.match(resetSource, /DOLA_FD_FACEBOOK_LOGIN/);
assert.match(resetSource, /Continue with Facebook/);
assert.match(resetSource, /Continue as…/, "Facebook consent must be surfaced as an expected manual checkpoint");
assert.match(resetSource, /PROCESS_TIMEOUT = 300000/, "OAuth confirmation must have a five-minute reset window");
assert.match(resetSource, /explicit-facebook-login/);
assert.match(resetSource, /var iconButtons = surface\.candidates/, "icon-only Facebook detection must use the detected provider surface without depending on another provider's position");
assert.doesNotMatch(resetSource, /providerIconCandidates\(googleControl\)/, "Facebook discovery must not require a Google control");
assert.match(resetSource, /function completeFacebookLogin\(deadline\)/, "Facebook login must have its own entry point");
assert.match(resetSource, /function completeGoogleLogin\(deadline\)/, "Google login must have its own entry point");
assert.doesNotMatch(resetSource, /completeLogin\(deadline, provider\)/, "provider login must not switch Facebook and Google inside one mixed entry point");
assert.match(resetSource, /requestTrustedClick\(null, null, flow\.semantic\)/, "an icon outside the content-script DOM must use semantic browser lookup");
assert.match(resetSource, /semantic: "Facebook"/, "Facebook must have its own semantic click target");
assert.match(resetSource, /semantic: ""/, "Google must remain outside the Facebook semantic click path");
assert.match(sidebar, /id="facebookLogin"/);
assert.match(sidebar, /id="savedAccountName"/);
assert.match(sidebar, /id="clearSavedAccount"/);

console.log("Facebook login safety tests passed: browser-managed session, no cookie permission, durable flow, and saved-account UI.");
