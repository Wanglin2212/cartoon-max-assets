"use strict";

const assert = require("node:assert/strict");
const matcher = require("../facebook_provider_matcher.js");

assert.equal(matcher.hasFacebookIdentity("Continue with Facebook"), true);
assert.equal(matcher.hasFacebookIdentity("provider-fb"), true);
assert.equal(matcher.hasOtherProviderIdentity("Continue with Apple"), true);
assert.equal(matcher.hasOtherProviderIdentity("Phone login"), true);
assert.equal(matcher.hasFacebookBlue("rgb(24, 119, 242)"), true);
assert.equal(matcher.hasFacebookBlue("fill: #1877f2"), true);
assert.equal(matcher.hasFacebookBlue("rgb(0, 0, 0)"), false);

function detectedIndex(order) {
  return order
    .map((provider, index) => ({
      index,
      score: matcher.evidenceScore(provider, provider === "facebook" ? "rgb(24, 119, 242)" : "rgb(0, 0, 0)")
    }))
    .sort((left, right) => right.score - left.score)[0].index;
}

assert.equal(detectedIndex(["facebook", "phone", "apple"]), 0, "Facebook can be the first icon");
assert.equal(detectedIndex(["phone", "facebook", "apple"]), 1, "Facebook can be the middle icon");
assert.equal(detectedIndex(["phone", "apple", "facebook"]), 2, "Facebook can be the last icon");

console.log("Facebook provider matcher tests passed: semantic and blue-icon detection are independent of provider order.");
