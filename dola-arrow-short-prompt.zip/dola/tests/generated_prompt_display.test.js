'use strict';
const assert = require('node:assert/strict');
const {cleanLabel, install} = require('../generated_prompt_display');
assert.equal(cleanLabel('Generated video: fish in the ocean, 16:9, 10s'), 'Generated video: fish in the ocean');
assert.equal(cleanLabel('Generated video: fish in the ocean, 9:16, 30s'), 'Generated video: fish in the ocean');
for (const text of ['fish in the ocean, 16:9, 10s', 'Generated video: wait 10s', 'Auto · 10s']) assert.equal(cleanLabel(text), text);
let callback;
const parent = {closest:() => null};
const text = {nodeType:3,parentElement:parent,nodeValue:'Generated video: fish, 16:9, 10s'};
const document = {body:{},createTreeWalker:() => {let done=false;return {nextNode:() => done ? null : (done=true,text)};}};
class Observer {constructor(cb){callback=cb;} observe(){}}
install(document,Observer);
assert.equal(text.nodeValue,'Generated video: fish');
text.nodeValue='Generated video: fish, 16:9, 10s';
callback([{type:'characterData',target:text}]);
assert.equal(text.nodeValue,'Generated video: fish');
text.parentElement={closest:() => ({})};
text.nodeValue='Generated video: user typed this, 16:9, 10s';
callback([{type:'characterData',target:text}]);
assert.equal(text.nodeValue,'Generated video: user typed this, 16:9, 10s');
console.log('Generated summary ratio/duration removed; editor text and other labels preserved.');

assert.equal(cleanLabel('Generated video: fish in the ocean, 16:9'), 'Generated video: fish in the ocean');
assert.equal(cleanLabel('Generated video: fish, coral, 21:9, 10s'), 'Generated video: fish, coral');
assert.equal(cleanLabel(cleanLabel('Generated video: fish, 16:9, 10s')), 'Generated video: fish');
