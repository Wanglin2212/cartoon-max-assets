"use strict";

const assert = require("node:assert/strict");
const policy = require("../generation_error_retry_policy.js");

assert.equal(policy.ERROR_MESSAGE, "Something went wrong. Please try again.");
assert.equal(policy.MAX_ATTEMPTS, 5);
assert.equal(policy.RETRY_DELAY_MS, 2500);

assert.equal(policy.isRetryableError("Something went wrong. Please try again."), true);
assert.equal(policy.isRetryableError("  SOMETHING   went wrong. Please try again.  "), true);
assert.equal(policy.isRetryableError("Something went wrong, Please try again"), true, "the punctuation variant in Dola's temporary-error response should also be retried");
assert.equal(policy.isRetryableError("Something else went wrong. Please try again."), false, "unrelated errors must not be retried");
assert.equal(policy.isRetryableError("Please try again later"), false);
assert.equal(policy.isRetryableError("Dola logged out"), false);

assert.equal(policy.isRetryHint("Retry generation"), true);
assert.equal(policy.isRetryHint("regenerate"), true);
assert.equal(policy.isExcludedHint("Share"), true);
assert.equal(policy.isExcludedHint("More menu"), true);

assert.deepEqual(policy.decision({ attempts: 0, lastAttemptAt: 1000 }, 3499, true), {
  action: "wait",
  attempts: 0,
  waitMs: 1
});
assert.deepEqual(policy.decision({ attempts: 0, lastAttemptAt: 1000 }, 3500, true), {
  action: "retry",
  attempts: 0,
  nextAttempt: 1
});
assert.equal(policy.decision({ attempts: 4, lastAttemptAt: 1000 }, 3500, true).nextAttempt, 5);
assert.deepEqual(policy.decision({ attempts: 5, lastAttemptAt: 1000 }, 3500, true), {
  action: "failed",
  attempts: 5
});
assert.equal(policy.decision({ attempts: 2, lastAttemptAt: 1000 }, 9000, false).action, "wait");

console.log("Generation error retry policy tests passed: exact error only, 2.5-second delay, and a hard five-attempt limit.");
