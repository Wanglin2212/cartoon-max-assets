"use strict";

const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");

const root = path.resolve(__dirname, "..");
const workflow = fs.readFileSync(path.join(root, "workflow_actions.js"), "utf8");
const bridge = fs.readFileSync(path.join(root, "dola_force_duration_bridge.js"), "utf8");
const reset = fs.readFileSync(path.join(root, "reset_account.js"), "utf8");

assert.match(workflow, /experiencing high demand/);
assert.match(workflow, /DOLA_FD_GENERATION_REJECTED/);
assert.match(workflow, /DOLA_FD_FORCE_RESULT/);
assert.match(workflow, /could not verify.*submitted generation settings/);
assert.doesNotMatch(workflow, /if \(\/\^\\\/chat\\\/[\s\S]{0,100}return true;/, "a chat route alone must not count as generation success");
assert.match(bridge, /HTTP 429\/high demand/);
assert.match(bridge, /prompt was not resubmitted/i);
assert.match(bridge, /generation request did not contain the selected/);
assert.match(bridge, /durationMissed/);
assert.match(bridge, /bodyInspection/);
assert.match(workflow, /!submittedRequestId && button/);
assert.match(workflow, /result\.finalRequest !== true/);
assert.match(workflow, /DolaGenerationRetryPolicy/);
assert.match(workflow, /after 5 automatic retry attempts/);
assert.doesNotMatch(bridge, /Logout was blocked/);
assert.match(reset, /from_logout=1/);
assert.match(reset, /dolaFacebookAutoReloginGenerationAt/);

console.log("Generation failure tests passed: 429 is failed, route-only success is blocked, retries stop, and Facebook recovery is bounded.");
