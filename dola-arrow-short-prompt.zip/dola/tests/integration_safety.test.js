"use strict";

const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");

const root = path.resolve(__dirname, "..");
const manifest = JSON.parse(fs.readFileSync(path.join(root, "manifest.json"), "utf8"));
const download = fs.readFileSync(path.join(root, "download.js"), "utf8");
const workflow = fs.readFileSync(path.join(root, "workflow_actions.js"), "utf8");
const workflowUi = fs.readFileSync(path.join(root, "workflow_ui.js"), "utf8");
const sidebar = fs.readFileSync(path.join(root, "sidebar.html"), "utf8");
const sidebarReset = fs.readFileSync(path.join(root, "sidebar_reset.js"), "utf8");
const reset = fs.readFileSync(path.join(root, "reset_account.js"), "utf8");
const mediaCapture = fs.readFileSync(path.join(root, "dola_media_capture.js"), "utf8");
const bootstrap = fs.readFileSync(path.join(root, "bootstrap_submit_only.js"), "utf8");
const background = fs.readFileSync(path.join(root, "background.js"), "utf8");

const main = manifest.content_scripts[0];
assert.equal(main.world, "MAIN");
assert.equal(main.run_at, "document_start");
assert.deepEqual(main.js, ["dola_force_duration.js", "dola_force_duration_bridge.js", "dola_media_capture.js"]);
assert.deepEqual(manifest.content_scripts.find((entry) => entry.js.includes("workflow_actions.js")).js, ["generation_error_retry_policy.js", "video_option_matcher.js", "workflow_actions.js"]);
assert.deepEqual(manifest.content_scripts.find((entry) => entry.js.includes("download.js")).js, ["video_duration_audit.js", "video_download_policy.js", "download.js"]);

assert.doesNotMatch(download, /device_id|web_id|tea_uuid|region\s*:\s*["']KH|recent_conv/i, "downloading must not replay hard-coded account/device request identifiers");
assert.match(download, /DOLA_FD_MEDIA_METADATA_REQUEST/);
assert.match(download, /fall back to Dola's ordinary[\s\S]{0,100}player file/, "downloading must allow an honestly labeled logo/player fallback");
assert.match(download, /cleanCandidate\(url, hint\)/, "metadata field hints must use the strict clean-download policy");
assert.doesNotMatch(download, /var cleanHint/, "the downloader must not bypass the shared clean-download policy");
assert.match(mediaCapture, /previousFetch\.call\(receiver, input, init\)/);
assert.match(mediaCapture, /response\.clone\(\)\.text\(\)/);
assert.match(mediaCapture, /XMLHttpRequest\.prototype\.send/, "play-info XHR responses must be observed without rebuilding the request");
assert.match(mediaCapture, /samantha\\\/\(\?:video\|media\)\\\/get_play_info/, "both current and legacy play-info endpoint families must be captured");
assert.doesNotMatch(mediaCapture, /headers\.set|document\.cookie|credentials\s*:/, "media metadata capture must observe Dola responses without altering request/session data");
for (const [name, source] of [["bootstrap", bootstrap], ["download", download], ["media capture", mediaCapture]]) {
  assert.match(source, /event\.source !== window \|\| event\.origin !== location\.origin/, name + " must reject cross-frame and cross-origin page messages");
}
assert.match(download, /downloadVideo\(video\)/, "each rendered-video button must target its own video");
assert.match(download, /\/samantha\/media\/get_play_info/, "the current media play-info endpoint must be tried before the legacy video endpoint");
assert.match(download, /requested .*but Dola rendered/, "rendered media duration must be audited");
assert.match(workflow, /!submittedRequestId && button/, "submit retries must stop after the first exact final request");
assert.match(workflow, /Something went wrong\. Please try again\./);
assert.match(workflow, /attempts:\s*0/);
assert.match(workflow, /dolaGenerationErrorRetry/);
assert.match(workflow, /activeRetryRerender/);
assert.match(workflow, /controls\.length === 6[\s\S]{0,120}return controls\[4\]/, "the fallback must target Dola's fifth Retry action, not the More menu");
assert.match(workflow, /Prompt FAILED:[\s\S]*after 5 automatic retry attempts/);
assert.match(workflow, /dolaLatestForceResult/);
assert.match(workflowUi, /queue\.push/);
assert.match(reset, /Delete control disappeared; advancing to final confirmation/, "the Delete step must advance when the final modal is outside the content-script DOM");
assert.doesNotMatch(reset, /wrong screen detected; retrying Delete Account/, "the final modal title must not send the flow back to the Account screen");
assert.doesNotMatch(reset, /div\.button-PgvIWh/, "Delete Now must not depend on Dola's generated button class");
assert.match(reset, /var target = clickableParent\(label\)/, "Delete Now must resolve its current clickable ancestor");
assert.match(reset, /requestTrustedClick\(null, null, "Delete Now"\)/, "Delete Now must have a browser-level semantic fallback");
assert.match(reset, /button still visible; trying semantic click/, "Delete Now must verify a coordinate click caused the transition");
assert.match(reset, /isDeleteVerificationPending/, "the transient Facebook Next verification must not be mistaken for an absent Delete control");
assert.match(reset, /CONTROL_STABILITY_MS = 750/, "Delete Now must be stable before the first click");
assert.doesNotMatch(reset, /login interface detected; transition confirmed/, "a login surface behind the modal must not complete Delete Now");
assert.match(reset, /control remained absent after click; transition confirmed/, "Delete Now completion must require sustained control absence after a click");
assert.match(reset, /VERIFICATION_GRACE_MS = 4000/, "a stale Next node must not block Delete Now indefinitely");
assert.match(reset, /probing Delete Now despite stale Next UI/, "the reset log must expose recovery from a stale Next node");
assert.match(reset, /if \(missingSince && Date\.now\(\) - missingSince >= ABSENCE_CONFIRMATION_MS\)/, "an unset absence timestamp must not suppress every Delete Now probe");
assert.match(sidebar, /accountTaskState[\s\S]*▶ Resume/, "the sidebar must expose a prominent resume control");
assert.match(sidebarReset, /RESET PAUSED/, "the sidebar must make a paused reset unmistakable");
assert.match(reset, /DOLA_FD_ACCOUNT_TASK_CONTROL/, "account reset must expose pause, continue, stop, and end controls");
assert.match(reset, /waitUntilRunnable/, "paused account work must not advance to the next step");
assert.match(background, /Accessibility\.getFullAXTree/, "trusted controls must be discoverable through Chrome's accessibility tree");
assert.match(background, /element\.shadowRoot/, "trusted controls must be discoverable inside open shadow roots");
assert.match(background, /rendered\.filter[\s\S]{0,160}normalized\(element\.textContent\)===wanted/, "Delete Now must be found from exact rendered text even without button semantics");
assert.match(background, /Page\.captureScreenshot/, "Delete Now must have a page-visual fallback across inaccessible surfaces");
assert.match(background, /matchedBy:\"visual-red-control\"/, "the visual fallback must report its exact match strategy");

console.log("Integration safety tests passed: MAIN-world loading, exact model/audit dependencies, bounded Dola error retry, no hard-coded account identifiers, one-request submit lock, queue producer, exact-video download, and reset retry index.");
