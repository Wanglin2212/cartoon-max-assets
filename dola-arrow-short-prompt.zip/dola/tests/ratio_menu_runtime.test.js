'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const matcher = require('../video_option_matcher');
const source = fs.readFileSync(require('node:path').join(__dirname, '../workflow_actions.js'), 'utf8');

for (const label of ['Auto · 10s', '16:9 · 10s', '9:16 · 4s', '21:9 · 10s']) {
  test('recognizes combined menu: ' + label, () => {
    assert.equal(matcher.controlMatches('ratio', label, ''), true);
    assert.equal(matcher.controlMatches('model', label, ''), false);
  });
}
test('ratio matching rejects different ratios, partial ratios and entire menus', () => {
  assert.equal(matcher.optionMatches('ratio', '19:16', '9:16'), false);
  assert.equal(matcher.optionMatches('ratio', 'Auto 3:4 4:3 9:16 16:9 1:1 21:9', '9:16'), false);
  assert.equal(matcher.optionMatches('ratio', '9 : 16', '9:16'), true);
  assert.equal(matcher.controlMatches('ratio', 'Generate 10s', ''), false);
});
for (const ratio of ['16:9', '9:16', '1:1', '21:9']) {
  test('opens Auto menu, clicks plain tile and confirms updated chip: ' + ratio, async () => {
    let open = false, now = 10000;
    const clicks = [];
    function node(text, width, height, attrs = {}) {
      return {textContent:text, isConnected:true, getAttribute:key => attrs[key] || null,
        closest:() => null, getBoundingClientRect:() => ({left:500,right:500+width,top:300,bottom:300+height,width,height})};
    }
    const chip = node('Auto · 10s', 170, 48);
    const tile = node(ratio, 120, 84);
    const label = node(ratio, 40, 20); label.parentElement = tile;
    const context = {
      optionMatcher:matcher, normalize:matcher.normalize, optionDisplay:matcher.optionDisplay,
      isVisible:n => n.isConnected, findVideoEditor:() => null, window:{innerHeight:900},
      document:{querySelectorAll:selector => selector === 'span,div' ? (open ? [label,tile] : []) : [chip]},
      Date:{now:() => now}, wait:async ms => {now += ms;}, diagnostic:async () => {},
      activate:n => {clicks.push(n); if(n === chip) open = !open; else if(n === tile) {chip.textContent = ratio + ' · 10s'; open=false;}},
      requestTrustedClick:async () => {throw Error('Unexpected trusted click');}
    };
    vm.createContext(context);
    vm.runInContext(source.slice(source.indexOf('  function nodeLabel('), source.indexOf('  async function applyVideoOptions(')), context);
    const result = await context.selectVideoOption('ratio',ratio,30000);
    assert.equal(result.selected,true);
    assert.deepEqual(clicks,[chip,tile]);
    assert.equal(chip.textContent,ratio+' · 10s');
    assert.equal(context.findVideoOptionTarget('ratio',ratio),null,'selected chip must not be treated as a menu item');
  });
}

test('21:9 survives generation setting validation', () => {
  const engine = require('../dola_force_duration');
  assert.equal(engine.normalizeSettings({enabled:true,duration:10,ratio:'21:9'}).ratio,'21:9');
});
