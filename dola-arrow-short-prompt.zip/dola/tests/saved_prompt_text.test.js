'use strict';
const assert = require('node:assert/strict');
const engine = require('../dola_force_duration');
const stringify = JSON.stringify.bind(JSON);
const settings = {enabled:true,duration:30,ratio:'16:9',model:'seedance_v2.5',resolution:'720p'};
function payload(prompt='fish in the ocean') {
  return {client_meta:{local_conversation_id:'keep'},messages:[{local_message_id:'keep-id',content_block:[{block_type:10000,content:{text_block:{text:'Generated video: '+prompt+', 16:9, 10s',summary:''}},block_id:'keep-block'}]}],chat_ability:{ability_type:17,ability_param:stringify({...settings,input_box_content:{user_input_content:prompt,reply_message_format:'Generated video: %s'}})},option:{unique_key:'keep-key'}};
}
function text(body) {return body.messages[0].content_block[0].content.text_block.text;}
const original=payload();
const clean=engine.patchPayload(stringify(original),settings);
const body=JSON.parse(clean.bodyText);
assert.equal(text(body),'Generated video: fish in the ocean');
assert.equal(JSON.parse(body.chat_ability.ability_param).duration,30);
assert.equal(JSON.parse(body.chat_ability.ability_param).ratio,'16:9');
assert.deepEqual(body.client_meta,original.client_meta);
assert.deepEqual(body.option,original.option);
assert.equal(body.messages[0].local_message_id,'keep-id');
assert.equal(engine.patchPayload(clean.bodyText,settings).changed,false,'already cleaned request passes final audit');
// Real prompt content that happens to contain duration/ratio must survive.
const literal=engine.patchPayload(stringify(payload('show a 16:9 screen for 10s')),settings);
assert.equal(text(JSON.parse(literal.bodyText)),'Generated video: show a 16:9 screen for 10s');
const other=payload();other.messages[0].content_block[0].content.text_block.text='Some different text, 16:9, 10s';
assert.equal(text(JSON.parse(engine.patchPayload(stringify(other),settings).bodyText)),text(other));
const unrelated=payload();unrelated.chat_ability.ability_type=16;
assert.equal(engine.patchPayload(stringify(unrelated),settings).bodyText,stringify(unrelated));
assert.equal(engine.patchPayload(stringify(original),{enabled:false}).bodyText,stringify(original));
assert.equal(engine.patchPayload('null',settings).matched,false);
(async () => {
  const previousFetch=global.fetch;
  let transmitted, resolveReply;
  global.fetch=(_input,init) => {transmitted=init.body; return new Promise(resolve => {resolveReply=resolve;});};
  try {
    engine.install(()=>settings);
    const request=payload();
    // This is the native request serialization, before signing/network send.
    const serialized=JSON.stringify(request);
    assert.equal(text(JSON.parse(serialized)),'Generated video: fish in the ocean');
    assert.equal(text(request),'Generated video: fish in the ocean, 16:9, 10s','do not mutate caller state');
    const pending = fetch('https://www.dola.com/samantha/chat/completion',{method:'POST',body:serialized});
    // Native optimistic UI can still use the unsanitized local object.
    // Verify display cleanup runs without any server response arriving.
    const display = require('../generated_prompt_display');
    const localText = {nodeType:3,parentElement:{closest:() => null},nodeValue:text(request)};
    let mutation;
    const document = {body:{},createTreeWalker:() => ({nextNode:() => null})};
    class Observer {constructor(cb){mutation=cb;} observe(){}}
    display.install(document,Observer);
    mutation([{type:'childList',addedNodes:[localText]}]);
    assert.equal(localText.nodeValue,'Generated video: fish in the ocean','optimistic display cleaned before reply');
    assert.equal(text(JSON.parse(transmitted)),'Generated video: fish in the ocean','actual saved request also clean');
    resolveReply(new Response('{}',{status:200}));
    await pending;
    assert.equal(transmitted,serialized,'send the pre-serialized request unchanged');
    assert.equal(text(JSON.parse(transmitted)),'Generated video: fish in the ocean');
    const stale=stringify(payload());
    await assert.rejects(fetch('https://www.dola.com/samantha/chat/completion',{method:'POST',body:stale}),{code:'DOLA_SETTINGS_NOT_APPLIED'},'unclean final body must not be silently rewritten after signing');
  } finally {engine.uninstall();global.fetch=previousFetch;}
  console.log('Native request text cleaned before send; generation settings and request identity preserved.');
})().catch(error=>{console.error(error);process.exitCode=1;});
