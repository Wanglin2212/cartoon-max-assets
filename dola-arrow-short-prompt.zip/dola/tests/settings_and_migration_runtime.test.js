"use strict";
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const test = require('node:test');
const source = name => fs.readFileSync(path.join(__dirname, '..', name), 'utf8');
const settle = () => new Promise(resolve => setImmediate(resolve));

test('invalid durations neither persist nor apply; valid custom durations do', async () => {
  const nodes = new Map();
  const get = id => {
    if (!nodes.has(id)) nodes.set(id, { value: '', checked: true, style: {}, options: [{value:'15'}], listeners: {}, addEventListener(type, fn) { this.listeners[type] = fn; } });
    return nodes.get(id);
  };
  const saved = [], messages = [];
  const browser = {
    storage: {local: {get: async () => ({}), set: async data => saved.push(data)}},
    tabs: {query: async () => [{id:1, url:'https://www.dola.com/chat'}], sendMessage: async (_, message) => {messages.push(message); return {ok:true};}}
  };
  vm.runInNewContext(source('popup.js'), {browser, document:{getElementById:get}, console});
  await settle();
  for (const value of ['0', '-1', '1.5', 'abc', 'Infinity', '9007199254740992']) {
    get('custom').value = value;
    get('save').listeners.click();
    await settle();
    assert.equal(saved.length, 0, value);
    assert.equal(messages.length, 0, value);
    assert.match(get('status').textContent, /positive whole-number/);
  }
  get('custom').value = '47';
  get('save').listeners.click();
  await settle();
  assert.equal(saved[0].forceDuration.duration, 47);
  assert.equal(messages[0].type, 'DOLA_FD_APPLY_OPTIONS');
});

test('Firefox migration awaits reloads and runs only once', async () => {
  const store = {}, reloads = [];
  const browser = {
    storage:{local:{get:async () => ({...store}), set:async data => Object.assign(store, data)}},
    tabs:{query:async () => [{id:7}, {id:8}, {}], reload:async id => reloads.push(id)},
    runtime:{onMessage:{addListener(){}}}
  };
  const context = {browser, console, URL};
  vm.runInNewContext(source('background.js'), context);
  await settle();
  assert.deepEqual(reloads, [7,8]);
  assert.equal(store.dolaSafeHookMigrationVersion, '1.10.25');
  vm.runInNewContext(source('background.js'), context);
  await settle();
  assert.deepEqual(reloads, [7,8]);
});

test('Firefox failed reload leaves migration pending for a later retry', async () => {
  let written = false;
  const browser = {
    storage:{local:{get:async () => ({}), set:async () => {written = true;}}},
    tabs:{query:async () => [{id:7}], reload:async () => {throw new Error('reload failed');}},
    runtime:{onMessage:{addListener(){}}}
  };
  vm.runInNewContext(source('background.js'), {browser, console:{warn(){}}, URL});
  await settle();
  assert.equal(written, false);
});
