"use strict";

const assert = require("node:assert/strict");
const policy = require("../video_download_policy.js");

assert.equal(policy.isExplicitlyClean("https://cdn.example/video.mp4"), false, "an arbitrary player MP4 is not proven logo-free");
assert.equal(policy.isExplicitlyClean("https://cdn.example/origin/video.mp4"), true);
assert.equal(policy.isExplicitlyClean("https://cdn.example/video.mp4", "play_url"), true);
assert.equal(policy.isExplicitlyClean("https://cdn.example/video.mp4?logo_type=unwatermarked"), true);
assert.equal(policy.isExplicitlyClean("https://cdn.example/video.mp4?logo_type=watermark"), false);
assert.equal(policy.isExplicitlyWatermarked("https://cdn.example/video.mp4?watermark=1"), true);
assert.equal(policy.isExplicitlyClean("https://cdn.example/resources/video.mp4"), false, "source inside resources is not a clean marker");
assert.equal(policy.isExplicitlyClean("https://cdn.example/rawhide/video.mp4"), false, "raw inside rawhide is not a clean marker");
assert.equal(policy.isExplicitlyClean("https://origins.example/video.mp4"), false, "a hostname containing origin is not a clean marker");
assert.equal(policy.isExplicitlyClean("https://cdn.example/video.mp4", "resource_url"), false, "source inside a field name is not enough");
assert.equal(policy.isExplicitlyClean("https://cdn.example/original/video.mp4"), true);
assert.equal(policy.isExplicitlyClean("https://cdn.example/video.mp4", "original_url"), true);
assert.equal(policy.isExplicitlyClean("https://cdn.example/video.mp4", "originalUrl"), true);
assert.equal(policy.isExplicitlyClean("https://cdn.example/video.mp4", "playUrl"), true);
assert.equal(policy.isExplicitlyClean("https://cdn.example/video.mp4", "data.play_url.url_list.0"), true, "nested URL lists must keep the trusted play_url parent");
assert.equal(policy.isExplicitlyClean("https://cdn.example/video.mp4", "data.original_media_info.main_url"), true, "Dola's original media main URL is an explicit clean source");
assert.equal(policy.isExplicitlyClean("https://cdn.example/video.mp4", "main_url"), false, "a bare generic main_url is not enough proof");

console.log("Download policy tests passed: ordinary player files are rejected, explicit clean/original files are allowed, and watermark/logo URLs are blocked.");
