"use strict";

const assert = require("node:assert/strict");
const audit = require("../video_duration_audit.js");

assert.deepEqual(audit.evaluate(30, 9).shorter, true, "a 30s request that renders 9s must fail");
assert.deepEqual(audit.evaluate(30, 29).shorter, false, "small container/metadata rounding is allowed");
assert.deepEqual(audit.evaluate(10, 9).shorter, false, "a nominal 10s clip may report approximately 9s");
assert.deepEqual(audit.evaluate(30, 0).valid, false, "missing metadata must not be reported as verified");

console.log("Rendered-duration audit tests passed: a 30s request resulting in 9s fails while normal media rounding is tolerated.");
