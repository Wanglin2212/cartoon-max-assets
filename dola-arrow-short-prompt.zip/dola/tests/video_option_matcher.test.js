"use strict";

const assert = require("node:assert/strict");
const matcher = require("../video_option_matcher.js");

assert.equal(matcher.controlMatches("model", "2.0 Fast", ""), true, "Dola's current selected model label must open the model menu");
assert.equal(matcher.controlMatches("model", "Dreamina Seedance 2.5", ""), true);
assert.equal(matcher.controlMatches("model", "Ratio", "image-creation-chat-input-video-ration-button"), false);
assert.equal(matcher.controlMatches("ratio", "Ratio", "image-creation-chat-input-video-ration-button"), true);
assert.equal(matcher.controlMatches("resolution", "1080p", ""), true);

assert.equal(matcher.optionMatches("model", "Dreamina Seedance 2.5", "seedance_v2.5"), true);
assert.equal(matcher.optionMatches("model", "2.0 Fast", "seedance_v2.0"), true);
assert.equal(matcher.optionMatches("model", "2.0 Fast", "seedance_v2.5"), false);
assert.equal(matcher.optionMatches("ratio", "9 : 16", "9:16"), true);
assert.equal(matcher.optionMatches("resolution", "1080P", "1080p"), true);
assert.equal(matcher.shouldDeferMissingControl("resolution", 2499), false);
assert.equal(matcher.shouldDeferMissingControl("resolution", 2500), true, "a model-hidden resolution control is deferred to exact request verification");
assert.equal(matcher.shouldDeferMissingControl("model", 5000), false, "model selection must never be silently deferred");

console.log("Video-option matcher tests passed: Dola's 2.0 Fast model trigger and selected options are recognized, with hidden resolution safely deferred to request verification.");
