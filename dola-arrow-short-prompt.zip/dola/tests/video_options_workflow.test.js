"use strict";

const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");

const root = path.resolve(__dirname, "..");
const workflow = fs.readFileSync(path.join(root, "workflow_actions.js"), "utf8");
const popup = fs.readFileSync(path.join(root, "popup.js"), "utf8");
const sidebar = fs.readFileSync(path.join(root, "sidebar.html"), "utf8");
const engine = fs.readFileSync(path.join(root, "dola_force_duration.js"), "utf8");
const matcher = require(path.join(root, "video_option_matcher.js"));

const applyStart = workflow.indexOf("async function applyVideoOptions");
const applyEnd = workflow.indexOf("function forceResultMatches", applyStart);
assert.ok(applyStart >= 0 && applyEnd > applyStart, "video-option application routine must exist");
const applyBody = workflow.slice(applyStart, applyEnd);
const modelAt = applyBody.indexOf('selectVideoOption("model"');
const ratioAt = applyBody.indexOf('selectVideoOption("ratio"');
const resolutionAt = applyBody.indexOf('selectVideoOption("resolution"');
assert.equal(modelAt, -1, "model must never be selected on the platform");
assert.ok(ratioAt >= 0 && resolutionAt > ratioAt, "ratio/resolution application stays unchanged");

assert.match(workflow, /state\.stage === "select_video"[\s\S]*applyVideoOptions\(await forceExpectation\(\), deadline\)/);
assert.match(workflow, /DOLA_FD_APPLY_OPTIONS/);
assert.match(workflow, /generation was not submitted/);
assert.match(workflow, /Duration remains submit-only/);
assert.match(workflow, /forceResultMatches/);

assert.match(popup, /DOLA_FD_APPLY_OPTIONS/);
assert.doesNotMatch(popup, /DOLA_FD_APPLY_CHIP/);
assert.match(sidebar, /Apply video options on page now/);
assert.match(engine, /ratio: settings\.ratio/);
assert.match(engine, /model: settings\.model/);
assert.match(engine, /resolution: settings\.resolution/);
assert.equal(matcher.controlMatches("model", "2.0 Fast", ""), true);
assert.equal(matcher.optionMatches("model", "Dreamina Seedance 2.5", "seedance_v2.5"), true);
assert.equal(matcher.shouldDeferMissingControl("resolution", 2500), true);
assert.match(workflow, /Dola hides the Resolution control[\s\S]*final request/);

console.log("Video-option workflow tests passed: model is enforced on submit without platform selection; visible ratio/resolution controls are selected, hidden resolution is deferred to exact request verification, and duration remains submit-only.");

const vm = require("node:vm");
(async () => {
  for (const model of ["seedance_v2.0", "seedance_v2.5"]) {
    const calls = [];
    const context = {
      selectVideoOption: async (kind, value) => { calls.push([kind, value]); return {}; },
      diagnostic: async () => {},
      settingSummary: () => "settings",
      optionDisplay: (_, value) => value
    };
    vm.createContext(context);
    vm.runInContext(applyBody, context);
    await context.applyVideoOptions({ enabled: true, model, ratio: "9:16", resolution: "4k" }, 1000);
    assert.deepEqual(calls, [["ratio", "9:16"], ["resolution", "4k"]]);
  }
  console.log("Both model choices skip platform model selection at runtime.");
})().catch(error => { console.error(error); process.exitCode = 1; });
