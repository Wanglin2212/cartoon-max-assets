'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const source = fs.readFileSync(require('node:path').join(__dirname, '../workflow_actions.js'), 'utf8');
function harness(document, extra = {}) {
 const window = {}; window.top = window;
 const context = {window, chrome:{}, document, ...extra, getComputedStyle:node => ({display:'block',visibility:'visible',opacity:'1',pointerEvents:'auto',backgroundImage:node.backgroundImage || '',backgroundColor:node.backgroundColor || '',color:node.color || '',cursor:node.cursor || ''})};
 vm.runInNewContext(source.replace('  api.runtime.onMessage.addListener', '  window.testAPI = {isVideoMode, findVideoEditor, findSubmitButton, findFileInput, waitForReferencePreviews, clickGenerateButton, attachFileTransfer, referencePreviews, shorterDurationOffer}; return;\n  api.runtime.onMessage.addListener'), context);
 return window.testAPI;
}
function node(text, attrs = {}) {
 return {textContent:text, isConnected:true, getAttribute:key => attrs[key] || null, getBoundingClientRect:() => ({left:0,right:400,top:200,bottom:300,width:400,height:100})};
}
test('selected Video tab works after placeholder disappears; Image mode does not', () => {
 const tab = node('Video', {'aria-selected':'true'});
 const editor = node('Already filled prompt');
 const api = harness({querySelector:() => null, querySelectorAll:selector => selector.includes('[role=tab]') ? [tab] : selector.startsWith('textarea, input[type=text]') ? [editor] : []});
 assert.equal(api.isVideoMode(), true);
 assert.equal(api.findVideoEditor(), editor);
 tab.getAttribute = () => null;
 assert.equal(api.isVideoMode(), false);
 assert.equal(api.findVideoEditor(), null);
});
test('submit stays inside composer and rejects account controls', () => {
 const send = node('Send'); send.tagName = 'BUTTON';
 send.getBoundingClientRect = () => ({left:350,right:400,top:250,bottom:300,width:50,height:50});
 const logout = node('Sign out');
 logout.getBoundingClientRect = send.getBoundingClientRect;
 const editor = node('Prompt');
 const root = {querySelector:() => send, querySelectorAll:() => [logout,send]};
 editor.querySelector = () => null;
 editor.querySelectorAll = () => [];
 editor.parentElement = root;
 const api = harness({body:{}, querySelectorAll:() => {throw new Error('Global button search is forbidden');}});
 assert.equal(api.findSubmitButton(editor), send);
 root.querySelectorAll = () => [logout];
 assert.equal(api.findSubmitButton(editor), null);
});

test('reference input is found above the closest toolbar', () => {
 const input = {accept:'image/*'};
 const editor = node('Prompt');
 editor.querySelectorAll = () => [];
 editor.parentElement = {querySelectorAll:() => [], parentElement:{querySelectorAll:() => [input]}};
 const api = harness({body:{}});
 assert.equal(api.findFileInput(editor), input);
});
test('ignored drops fail instead of reporting attachment success', async () => {
 let now = 0;
 const editor = node('Prompt');
 editor.querySelectorAll = () => [];
 editor.querySelector = () => null;
 editor.parentElement = {querySelectorAll:() => [], querySelector:() => null};
 const api = harness({body:{},querySelector:() => null,querySelectorAll:() => []}, {Date:{now:() => now},setTimeout:fn => {now += 250;fn();}});
 await assert.rejects(api.waitForReferencePreviews(editor, new Set(), 1, 2000), /did not confirm all reference images/);
});
test('new reference preview must appear and remain ready before continuing', async () => {
 let now = 0;
 const editor = node('Prompt');
 const image = node(''); image.src = 'blob:reference';
 editor.querySelectorAll = () => [];
 editor.querySelector = () => null;
 editor.parentElement = {querySelectorAll:() => now >= 500 ? [image] : [],querySelector:() => null};
 const api = harness({body:{},querySelector:() => null,querySelectorAll:() => []}, {Date:{now:() => now},setTimeout:fn => {now += 250;fn();}});
 await api.waitForReferencePreviews(editor, new Set(), 1, 3000);
 assert.ok(now >= 1500);
});

test('Send search reaches a sibling toolbar outside the nearest composer wrapper', () => {
 const editor = node('Prompt');
 const send = node(''); send.tagName = 'BUTTON';
 send.getBoundingClientRect = () => ({left:350,right:400,top:250,bottom:300,width:50,height:50});
 editor.querySelectorAll = () => [];
 editor.parentElement = {querySelectorAll:() => [],parentElement:{querySelectorAll:() => [send]}};
 const api = harness({body:{}});
 assert.equal(api.findSubmitButton(editor), send);
 send.disabled = true;
 assert.equal(api.findSubmitButton(editor), null);
});
test('Generate uses one trusted Chrome click without a duplicate synthetic click', async () => {
 const messages = [];
 const button = node('Send');
 button.click = () => {throw new Error('Duplicate synthetic click');};
 const api = harness({body:{}}, {chrome:{runtime:{sendMessage(message, callback){messages.push(message);callback({ok:true});}}}});
 await api.clickGenerateButton(button);
 assert.equal(messages.length, 1);
 assert.equal(messages[0].type, 'DOLA_FD_TRUSTED_CLICK');
 assert.equal(messages[0].x, 200);
});

test('hidden image input outside composer is accepted only when unambiguous', () => {
 const editor = node('Prompt'); editor.querySelectorAll = () => [];
 const imageInput = {accept:'image/*'};
 let inputs = [imageInput];
 const api = harness({body:{},querySelectorAll:() => inputs});
 assert.equal(api.findFileInput(editor), imageInput);
 inputs = [imageInput, {accept:'image/png'}];
 assert.equal(api.findFileInput(editor), null);
 inputs = [{accept:''}];
 assert.equal(api.findFileInput(editor), null);
 assert.equal(api.findFileInput(editor, new Set()), inputs[0]);
 inputs[0].disabled = true;
 assert.equal(api.findFileInput(editor, new Set()), null);
});
test('file transfer uses native setter and bubbling composed events', () => {
 const events = [];
 function Input() {}
 Object.defineProperty(Input.prototype, 'files', {set(value){this.assignedFiles = value;}});
 const input = new Input();
 Object.defineProperty(input,'files',{set(){throw new Error('site own setter');}});
 input.value = 'previous.png';
 input.dispatchEvent = event => events.push(event);
 const files = [{name:'reference.png'}];
 class FakeEvent {constructor(type, options){this.type = type;Object.assign(this,options);}}
 const api = harness({body:{}},{HTMLInputElement:Input,Event:FakeEvent});
 api.attachFileTransfer(input,{files});
 assert.equal(input.value,'');
 assert.equal(input.assignedFiles,files);
 assert.deepEqual(events.map(event => event.type),['input','change']);
 assert.ok(events.every(event => event.bubbles && event.composed));
});

test('CSS reference thumbnails confirm upload while old backgrounds do not', async () => {
 let now = 0;
 const editor = node('Prompt'); editor.querySelectorAll = () => []; editor.querySelector = () => null;
 const old = node(''); old.backgroundImage = 'url("https://cdn.test/ui-background.png")';
 const thumbnail = node(''); thumbnail.backgroundImage = 'url("blob:uploaded-reference")';
 editor.parentElement = {querySelectorAll:() => now < 500 ? [old] : [old,thumbnail],querySelector:() => null};
 const api = harness({body:{},querySelector:() => null,querySelectorAll:() => []},{Date:{now:() => now},setTimeout:fn => {now += 250;fn();}});
 const before = api.referencePreviews(editor);
 assert.equal(before.size,1);
 await api.waitForReferencePreviews(editor,before,1,3000);
 assert.ok(now >= 1500);
});
test('reference filenames containing logo or icon are retained, distant images excluded', () => {
 const editor = node('Prompt'); editor.querySelectorAll = () => [];
 const reference = node(''); reference.src = 'https://cdn.test/my-logo-reference.png';
 const distant = node(''); distant.src = 'https://cdn.test/other-image.png';
 distant.getBoundingClientRect = () => ({left:0,right:400,top:1000,bottom:1100,width:400,height:100});
 editor.parentElement = {querySelectorAll:() => [reference,distant]};
 const api = harness({body:{}});
 const previews = api.referencePreviews(editor);
 assert.equal(previews.has(reference.src),true);
 assert.equal(previews.has(distant.src),false);
});

test('unlabelled blue SVG arrow in a clickable div is found', () => {
 const editor = node('Prompt'); editor.querySelectorAll = () => [];
 const arrow = node(''); arrow.tagName = 'DIV'; arrow.backgroundColor = 'rgb(40, 100, 240)'; arrow.cursor = 'pointer';
 arrow.getBoundingClientRect = () => ({left:350,right:400,top:320,bottom:370,width:50,height:50});
 const svg = node(''); svg.tagName = 'svg'; svg.parentElement = arrow;
 arrow.querySelector = () => svg;
 const container = {querySelectorAll:() => [svg]}; arrow.parentElement = container;
 editor.parentElement = container;
 const api = harness({body:{}});
 assert.equal(api.findSubmitButton(editor), arrow);
 arrow.backgroundColor = 'rgb(180, 180, 180)';
 assert.equal(api.findSubmitButton(editor), null);
 arrow.backgroundColor = 'rgb(40, 100, 240)'; arrow.getAttribute = key => key === 'aria-disabled' ? 'true' : null;
 assert.equal(api.findSubmitButton(editor), null);
});
test('Generate search can reach controls twelve wrappers above the editor', () => {
 const send = node('Send'); send.tagName = 'BUTTON';
 send.getBoundingClientRect = () => ({left:350,right:400,top:250,bottom:300,width:50,height:50});
 const editor = node('Prompt'); editor.querySelectorAll = () => [];
 let current = editor;
 for (let i=0;i<9;i++) {current.parentElement = {querySelectorAll:() => []}; current = current.parentElement;}
 current.querySelectorAll = () => [send];
 assert.equal(harness({body:{}}).findSubmitButton(editor),send);
});

test('shorter-duration offer requires a user decision without changing 30-second settings', () => {
 const dialog = node('30 seconds is unavailable. Continue with 10 seconds instead?');
 const settings = {enabled:true,duration:30};
 const api = harness({querySelectorAll:() => [dialog]});
 assert.match(api.shorterDurationOffer(settings),/offers 10s instead of 30s/);
 assert.equal(settings.duration,30);
 dialog.textContent = 'Continue with 30 seconds?';
 assert.equal(api.shorterDurationOffer(settings),'');
 dialog.textContent = 'Your 10 seconds video is ready';
 assert.equal(api.shorterDurationOffer(settings),'');
});

