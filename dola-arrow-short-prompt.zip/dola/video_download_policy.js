(function (root, factory) {
  var api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  if (root) root.DolaVideoDownloadPolicy = api;
})(typeof globalThis !== "undefined" ? globalThis : self, function () {
  "use strict";

  function isExplicitlyWatermarked(value, hint) {
    var field = String(hint || "").toLowerCase().trim();
    var url = String(value || "").toLowerCase();
    var text = field + " " + url;
    return /(?:^|[^a-z0-9])watermark(?:ed)?(?:[^a-z0-9]|$)|logo_type=(?:watermark|hd)|(?:^|[^a-z0-9])wm(?:[^a-z0-9]|$)/.test(text) &&
      !/(?:^|[^a-z0-9])(?:unwatermarked|no[_-]?watermark|without[_-]?watermark)(?:[^a-z0-9]|$)|logo_type=unwatermarked/.test(text);
  }

  function cleanFieldName(value) {
    var field = String(value || "").replace(/([a-z0-9])([A-Z])/g, "$1_$2").toLowerCase().trim().replace(/[.\[\]]+/g, "_").replace(/_+/g, "_");
    // Dola commonly nests a URL below url_list/uri_list. Keep the complete
    // field path so a trusted parent such as play_url is not lost at the
    // array item. A bare main_url remains untrusted; it is accepted only
    // inside Dola's explicit original_media_info object.
    return /(?:^|_)(?:unwatermarked|no_watermark|without_watermark)(?:_(?:url|addr|uri|src))?(?:_(?:url_list|uri_list|urls|uris))?(?:_\d+)?$/.test(field) ||
      /(?:^|_)(?:origin|original|source|raw|material|play)_(?:url|addr|uri|src)(?:_(?:url_list|uri_list|urls|uris))?(?:_\d+)?$/.test(field) ||
      /(?:^|_)original_media_info_(?:main|origin|original|source|play|download)_(?:url|addr|uri|src)(?:_(?:url_list|uri_list|urls|uris))?(?:_\d+)?$/.test(field);
  }

  function cleanUrlMarker(value) {
    var text = String(value || "").toLowerCase();
    try {
      var parsed = new URL(text, "https://dola.invalid/");
      text = parsed.pathname + parsed.search;
      if (parsed.searchParams.get("logo_type") === "unwatermarked") return true;
    } catch (_) {}
    return /(?:^|[^a-z0-9])(?:unwatermarked|no[_-]?watermark|without[_-]?watermark|origin|original|source|raw|material|fplay)(?:[^a-z0-9]|$)/.test(text);
  }

  function isExplicitlyClean(value, hint) {
    if (isExplicitlyWatermarked(value, hint)) return false;
    return cleanFieldName(hint) || cleanUrlMarker(value);
  }

  return {
    isExplicitlyClean: isExplicitlyClean,
    isExplicitlyWatermarked: isExplicitlyWatermarked
  };
});
