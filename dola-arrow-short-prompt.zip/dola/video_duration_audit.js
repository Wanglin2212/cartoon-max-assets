(function (root, factory) {
  var api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  if (root) root.DolaVideoDurationAudit = api;
})(typeof globalThis !== "undefined" ? globalThis : self, function () {
  "use strict";

  function evaluate(requestedSeconds, actualSeconds) {
    var requested = Number(requestedSeconds);
    var actual = Number(actualSeconds);
    if (!Number.isFinite(requested) || requested <= 0 || !Number.isFinite(actual) || actual <= 0) {
      return { valid: false, shorter: false, requestedSeconds: requested || 0, actualSeconds: actual || 0, tolerance: 0 };
    }
    var tolerance = Math.max(1.5, requested * 0.05);
    return {
      valid: true,
      shorter: actual + tolerance < requested,
      requestedSeconds: requested,
      actualSeconds: actual,
      tolerance: tolerance
    };
  }

  return { evaluate: evaluate };
});
