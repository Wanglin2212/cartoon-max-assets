(function (root, factory) {
  var api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  if (root) root.DolaVideoOptionMatcher = api;
})(typeof globalThis !== "undefined" ? globalThis : self, function () {
  "use strict";

  function normalize(value) {
    return String(value || "").replace(/\s+/g, " ").trim();
  }

  function modelDisplay(value) {
    if (value === "seedance_v2.5") return "Dreamina Seedance 2.5";
    if (value === "seedance_v2.0") return "Seedance 2.0";
    return value || "";
  }

  function optionDisplay(kind, value) {
    return kind === "model" ? modelDisplay(value) : String(value || "");
  }

  function optionMatches(kind, text, value) {
    var current = normalize(text);
    if (!current || !value) return false;
    if (kind === "model") {
      if (value === "seedance_v2.5") return /(?:^|\s)2[.,]5(?:\s|$)/i.test(current);
      if (value === "seedance_v2.0") {
        return /(?:^|\s)2[.,]0(?:\s|$)/i.test(current) && !/(?:^|\s)2[.,]5(?:\s|$)/i.test(current);
      }
      return false;
    }
    if (kind === "ratio") return current.replace(/\s+/g, "").indexOf(String(value)) >= 0;
    if (kind === "resolution") return current.toLowerCase().indexOf(String(value).toLowerCase()) >= 0;
    return false;
  }

  function modelTriggerLabel(text) {
    var current = normalize(text);
    if (!current || /\b(?:ratio|resolution|duration)\b/i.test(current)) return false;
    return /\b(?:dreamina|seedance)\b/i.test(current) ||
      /(?:^|\s)2[.,](?:0|5)(?:\s+(?:fast|pro|lite))?(?:\s|$)/i.test(current);
  }

  function controlMatches(kind, text, testId) {
    var current = normalize(text);
    var id = String(testId || "");
    if (kind === "model") return /video.*model/i.test(id) || /(?:^|\s)Model(?:\s|$)/i.test(current) || modelTriggerLabel(current);
    if (kind === "ratio") return /video.*rati/i.test(id) || /(?:^|\s)Ratio(?:\s|$)/i.test(current);
    if (kind === "resolution") {
      return /video.*resolution/i.test(id) || /(?:^|\s)Resolution(?:\s|$)/i.test(current) || /^(?:(?:480|720|1080)p|[24]k)$/i.test(current);
    }
    return false;
  }

  function shouldDeferMissingControl(kind, missingMilliseconds) {
    return kind === "resolution" && Number(missingMilliseconds) >= 2500;
  }

  return {
    normalize: normalize,
    modelDisplay: modelDisplay,
    optionDisplay: optionDisplay,
    optionMatches: optionMatches,
    modelTriggerLabel: modelTriggerLabel,
    controlMatches: controlMatches,
    shouldDeferMissingControl: shouldDeferMissingControl
  };
});
