(function () {
  "use strict";

  if (window.top !== window || window.__dolaFDWorkflow) return;
  window.__dolaFDWorkflow = true;
  var api = typeof browser !== "undefined" ? browser : chrome;
  var STATE_KEY = "dolaWorkflowRun";
  var DIAGNOSTIC_KEY = "dolaWorkflowDiagnostic";
  var DIAGNOSTIC_LOG_KEY = "dolaWorkflowDiagnosticLog";
  var QUEUE_KEY = "dolaWorkflowQueue";
  var EDITOR_SELECTOR = "textarea, input[type=text], [contenteditable]:not([contenteditable=false]), [role=textbox], .ProseMirror";
  var running = false;
  var durationRefusal = null;
  var generationRejection = null;
  var generationForceResult = null;
  var generationResponse = null;
  var optionMatcher = globalThis.DolaVideoOptionMatcher;
  var retryPolicy = globalThis.DolaGenerationRetryPolicy;
  var RETRY_STATE_KEY = "dolaGenerationErrorRetry";
  var retryMonitorRunning = false;
  var retryMonitorTimer = 0;
  var retryErrorWasVisible = false;

  function wait(milliseconds) {
    return new Promise(function (resolve) { setTimeout(resolve, milliseconds); });
  }

  function normalize(value) {
    return String(value || "").replace(/\s+/g, " ").trim();
  }

  function isVisible(node) {
    if (!node || !node.isConnected) return false;
    var rect = node.getBoundingClientRect();
    var style = getComputedStyle(node);
    return rect.width > 0 && rect.height > 0 && style.display !== "none" && style.visibility !== "hidden" && style.opacity !== "0" && style.pointerEvents !== "none";
  }

  function isRendered(node) {
    if (!node || !node.isConnected) return false;
    var rect = node.getBoundingClientRect();
    var style = getComputedStyle(node);
    return rect.width > 0 && rect.height > 0 && style.display !== "none" && style.visibility !== "hidden" && style.opacity !== "0";
  }

  function activate(node) {
    if (!node) return false;
    try { node.focus(); } catch (error) {}
    var rect = node.getBoundingClientRect();
    var options = { bubbles: true, cancelable: true, view: window, button: 0, clientX: rect.left + rect.width / 2, clientY: rect.top + rect.height / 2 };
    try {
      if (typeof PointerEvent === "function") {
        node.dispatchEvent(new PointerEvent("pointerdown", options));
        node.dispatchEvent(new PointerEvent("pointerup", options));
      }
      node.dispatchEvent(new MouseEvent("mousedown", options));
      node.dispatchEvent(new MouseEvent("mouseup", options));
      node.click();
      return true;
    } catch (error) { return false; }
  }

  function requestTrustedClick(node) {
    if (!node || !node.getBoundingClientRect) return Promise.resolve({ ok: false });
    var rect = node.getBoundingClientRect();
    return new Promise(function (resolve) {
      api.runtime.sendMessage({
        type: "DOLA_FD_TRUSTED_CLICK",
        selector: null,
        x: rect.left + rect.width / 2,
        y: rect.top + rect.height / 2
      }, function (result) {
        if (api.runtime.lastError) resolve({ ok: false, error: api.runtime.lastError.message });
        else resolve(result || { ok: false });
      });
    });
  }

  function requestTrustedText(node, value) {
    if (!node || !node.getBoundingClientRect) return Promise.resolve({ ok: false });
    var rect = node.getBoundingClientRect();
    return new Promise(function (resolve) {
      api.runtime.sendMessage({
        type: "DOLA_FD_TRUSTED_TEXT",
        text: String(value || ""),
        x: rect.left + Math.min(rect.width - 12, Math.max(12, rect.width / 2)),
        y: rect.top + Math.min(rect.height - 12, Math.max(12, rect.height / 2))
      }, function (result) {
        if (api.runtime.lastError) resolve({ ok: false, error: api.runtime.lastError.message });
        else resolve(result || { ok: false });
      });
    });
  }

  function getState() {
    return new Promise(function (resolve) {
      api.storage.local.get(STATE_KEY, function (data) { resolve(data && data[STATE_KEY]); });
    });
  }

  function setState(state) {
    var data = {};
    data[STATE_KEY] = state;
    return new Promise(function (resolve) { api.storage.local.set(data, resolve); });
  }

  function diagnostic(status, message) {
    var entry = { status: status, step: "workflow", message: message, time: new Date().toISOString(), url: location.pathname };
    return new Promise(function (resolve) {
      api.storage.local.get(DIAGNOSTIC_LOG_KEY, function (stored) {
        var log = stored && Array.isArray(stored[DIAGNOSTIC_LOG_KEY]) ? stored[DIAGNOSTIC_LOG_KEY].slice(-99) : [];
        log.push(entry);
        var data = {};
        data[DIAGNOSTIC_KEY] = entry;
        data[DIAGNOSTIC_LOG_KEY] = log;
        api.storage.local.set(data, resolve);
      });
    });
  }

  function clearState() {
    return new Promise(function (resolve) { api.storage.local.remove(STATE_KEY, resolve); });
  }

  function getRetryState() {
    return new Promise(function (resolve) {
      api.storage.local.get(RETRY_STATE_KEY, function (data) { resolve(data && data[RETRY_STATE_KEY]); });
    });
  }

  function setRetryState(state) {
    var data = {};
    data[RETRY_STATE_KEY] = state;
    return new Promise(function (resolve) { api.storage.local.set(data, resolve); });
  }

  function forceExpectation() {
    return new Promise(function (resolve) {
      api.storage.local.get("forceDuration", function (data) {
        var settings = data && data.forceDuration || {};
        var duration = Number(settings.duration);
        resolve({
          enabled: settings.enabled !== false && Number.isInteger(duration) && duration > 0,
          duration: Number.isInteger(duration) && duration > 0 ? duration : 0,
          ratio: ["9:16", "16:9", "1:1", "4:3", "3:4", "21:9"].indexOf(String(settings.ratio || "")) >= 0 ? String(settings.ratio) : "",
          model: ["seedance_v2.0", "seedance_v2.5"].indexOf(String(settings.model || "")) >= 0 ? String(settings.model) : "",
          resolution: ["480p", "720p", "1080p", "2k", "4k"].indexOf(String(settings.resolution || "")) >= 0 ? String(settings.resolution) : ""
        });
      });
    });
  }

  function latestGenerationSignals() {
    return new Promise(function (resolve) {
      api.storage.local.get(["dolaLatestForceResult", "dolaLatestGenerationResponse"], function (data) {
        resolve(data || {});
      });
    });
  }

  function findText(pattern, root) {
    var scope = root || document;
    var nodes = scope.querySelectorAll("button, [role=button], a, span, div, p");
    var match = null;
    for (var i = 0; i < nodes.length; i++) {
      if (isVisible(nodes[i]) && pattern.test(normalize(nodes[i].textContent))) match = nodes[i];
    }
    return match;
  }

  function findAiCreation() {
    var sidebar = document.querySelector("#flow_chat_sidebar") || document;
    return findText(/^AI Creation$/i, sidebar);
  }

  function findEditor(pattern) {
    var nodes = document.querySelectorAll(EDITOR_SELECTOR);
    var best = null;
    var bestScore = -1;
    for (var i = 0; i < nodes.length; i++) {
      var node = nodes[i];
      if (!isVisible(node)) continue;
      var hint = normalize((node.placeholder || "") + " " + (node.getAttribute("aria-label") || "") + " " + (node.getAttribute("aria-placeholder") || "") + " " + (node.getAttribute("data-placeholder") || "") + " " + (node.getAttribute("placeholder") || ""));
      if (pattern && !pattern.test(hint)) continue;
      var rect = node.getBoundingClientRect();
      var score = rect.top + Math.min(500, rect.width);
      if (score > bestScore) { best = node; bestScore = score; }
    }
    return best;
  }

  function findVideoPromptHint() {
    var nodes = document.querySelectorAll("textarea, input, [contenteditable], [role=textbox], [data-placeholder], div, span, p");
    var match = null;
    for (var i = 0; i < nodes.length; i++) {
      var node = nodes[i];
      var hints = [node.placeholder, node.getAttribute("aria-placeholder"), node.getAttribute("data-placeholder"), node.textContent];
      var matches = hints.some(function (value) { return /^Describe the actions in the video$/i.test(normalize(value)); });
      if (isRendered(node) && matches) match = node;
    }
    return match;
  }

  function findVideoEditor() {
    var remembered = document.querySelector('[data-dola-fd-video-editor="true"]');
    if (remembered && isVisible(remembered)) return remembered;
    var editor = findEditor(/actions? in (?:the )?video|describe.*video/i);
    if (editor) return editor;
    var placeholder = findVideoPromptHint();
    if (!placeholder) return selectedVideoControl() ? findEditor() : null;
    if (placeholder.matches && placeholder.matches(EDITOR_SELECTOR)) return placeholder;
    var hintRect = placeholder.getBoundingClientRect();
    var candidates = document.querySelectorAll(EDITOR_SELECTOR);
    var best = null;
    var bestDistance = Infinity;
    for (var i = 0; i < candidates.length; i++) {
      var candidate = candidates[i];
      if (!isVisible(candidate)) continue;
      var rect = candidate.getBoundingClientRect();
      var overlapsHorizontally = rect.right >= hintRect.left && rect.left <= hintRect.right;
      var nearPromptHint = Math.abs(rect.top - hintRect.top) < 140 || (rect.top <= hintRect.top && rect.bottom >= hintRect.bottom);
      if (!overlapsHorizontally || !nearPromptHint) continue;
      var distance = Math.abs(rect.left - hintRect.left) + Math.abs(rect.top - hintRect.top);
      if (distance < bestDistance) { best = candidate; bestDistance = distance; }
    }
    return best;
  }

  function selectedVideoControl() {
    var nodes = document.querySelectorAll('[role=tab], button, [role=button]');
    for (var i = 0; i < nodes.length; i++) {
      var node = nodes[i];
      if (isVisible(node) && /^Video$/i.test(normalize(node.textContent || node.getAttribute("aria-label"))) &&
          (node.getAttribute("aria-selected") === "true" || node.getAttribute("aria-pressed") === "true" || node.getAttribute("data-state") === "active")) return node;
    }
    return null;
  }

  function isVideoMode() {
    return !!findEditor(/actions? in (?:the )?video|describe.*video/i) || !!findVideoPromptHint() || !!(selectedVideoControl() && findEditor());
  }

  async function ensureVideoMode(deadline) {
    var lastClick = 0;
    var lastTarget = "";
    while (Date.now() < deadline) {
      if (isVideoMode()) {
        await diagnostic("running", "Video creation mode ready.");
        return;
      }
      var video = findText(/^Video$/i);
      var aiCreation = findAiCreation();
      var node = video || aiCreation;
      var target = video ? "Video" : "AI Creation";
      if (node && Date.now() - lastClick >= 900) {
        lastClick = Date.now();
        if (target !== lastTarget) {
          lastTarget = target;
          await diagnostic("running", target === "Video" ? "Switching AI Creation from Image to Video…" : "Opening AI Creation…");
        }
        var clickTarget = node.closest && node.closest("button, [role=button], [role=tab], [aria-selected], [data-state]");
        clickTarget = clickTarget || node;
        activate(clickTarget);
        await wait(250);
        if (!isVideoMode() && node.parentElement && node.parentElement !== clickTarget) activate(node.parentElement);
        if (!isVideoMode()) await requestTrustedClick(clickTarget);
      }
      await wait(250);
    }
    throw new Error("Could not open Dola Video creation mode.");
  }

  function modelDisplay(value) {
    return optionMatcher ? optionMatcher.modelDisplay(value) : value || "";
  }

  function optionDisplay(kind, value) {
    return optionMatcher ? optionMatcher.optionDisplay(kind, value) : (kind === "model" ? modelDisplay(value) : value);
  }

  function settingSummary(settings) {
    var parts = [];
    if (Number(settings && settings.duration) > 0) parts.push(Number(settings.duration) + "s");
    if (settings && settings.ratio) parts.push(settings.ratio);
    if (settings && settings.resolution) parts.push(settings.resolution);
    if (settings && settings.model) parts.push(modelDisplay(settings.model));
    return parts.join(", ");
  }

  function nodeLabel(node) {
    return normalize((node && node.getAttribute && node.getAttribute("aria-label") || "") + " " +
      (node && node.title || "") + " " + (node && node.textContent || ""));
  }

  function optionMatches(kind, text, value) {
    if (optionMatcher) return optionMatcher.optionMatches(kind, text, value);
    var current = normalize(text);
    if (!current || !value) return false;
    if (kind === "model") {
      if (value === "seedance_v2.5") return /(?:^|\s)2\.5(?:\s|$)/i.test(current);
      if (value === "seedance_v2.0") return /(?:^|\s)2\.0(?:\s|$)/i.test(current) && !/(?:^|\s)2\.5(?:\s|$)/i.test(current);
      return false;
    }
    if (kind === "ratio") return current.replace(/\s+/g, "").indexOf(value) >= 0;
    if (kind === "resolution") return current.toLowerCase().indexOf(String(value).toLowerCase()) >= 0;
    return false;
  }

  function nearVideoComposer(node) {
    var editor = findVideoEditor();
    if (!editor || !node) return true;
    var editorRect = editor.getBoundingClientRect();
    var rect = node.getBoundingClientRect();
    return rect.right >= editorRect.left - 40 && rect.left <= editorRect.right + 40 &&
      rect.top >= editorRect.top - 40 && rect.bottom <= editorRect.bottom + 180;
  }

  function findVideoOptionControl(kind) {
    var selectors = kind === "ratio"
      ? '[data-testid="image-creation-chat-input-video-ration-button"],button,[role=button],[role=combobox]'
      : 'button,[role=button],[role=combobox]';
    var nodes = document.querySelectorAll(selectors);
    var best = null;
    var bestScore = -Infinity;
    for (var i = 0; i < nodes.length; i++) {
      var node = nodes[i];
      if (!isVisible(node) || !nearVideoComposer(node)) continue;
      var text = nodeLabel(node);
      var testId = String(node.getAttribute("data-testid") || "");
      var matches = optionMatcher
        ? optionMatcher.controlMatches(kind, text, testId)
        : kind === "model"
          ? /(?:^|\s)Model(?:\s|$)/i.test(text) || /video.*model/i.test(testId) || /(?:^|\s)2[.,](?:0|5)(?:\s+(?:fast|pro|lite))?(?:\s|$)/i.test(text)
          : kind === "ratio"
            ? /(?:^|\s)Ratio(?:\s|$)/i.test(text) || /video.*rati/i.test(testId)
            : /(?:^|\s)Resolution(?:\s|$)/i.test(text) || /video.*resolution/i.test(testId) || /^(?:(?:480|720|1080)p|[24]k)$/i.test(text);
      if (!matches) continue;
      var rect = node.getBoundingClientRect();
      var score = (testId ? 10000 : 0) - rect.width * rect.height / 1000 + rect.top;
      if (score > bestScore) { best = node; bestScore = score; }
    }
    return best;
  }

  function findOverflowControl() {
    var nodes = document.querySelectorAll("button,[role=button]");
    for (var i = 0; i < nodes.length; i++) {
      if (!isVisible(nodes[i]) || !nearVideoComposer(nodes[i])) continue;
      var text = nodeLabel(nodes[i]);
      if (/^(?:more(?: options)?|overflow|\.{3}|…|⋯)$/i.test(text)) return nodes[i];
    }
    return null;
  }

  function findVideoOptionTarget(kind, value) {
    var selector = '[data-testid="dropdown-menu-item"],[role=option],[role=menuitem],[role=menuitemradio],[role=radio],[data-radix-collection-item],li[tabindex],button[tabindex],div[tabindex]';
    var nodes = document.querySelectorAll(selector);
    var best = null;
    var bestScore = -Infinity;
    for (var i = 0; i < nodes.length; i++) {
      var node = nodes[i];
      if (!isVisible(node) || node.getAttribute("aria-disabled") === "true" || node.disabled) continue;
      var text = nodeLabel(node);
      if (!optionMatches(kind, text, value)) continue;
      // The combined ratio/duration chip opens the menu; it is not a ratio tile.
      if (kind === "ratio" && optionMatcher && optionMatcher.ratioTriggerLabel(text)) continue;
      var rect = node.getBoundingClientRect();
      if (rect.width * rect.height > 400000) continue;
      var role = node.getAttribute("role") || "";
      var testId = node.getAttribute("data-testid") || "";
      var exact = normalize(text).replace(/^Model\s+/i, "");
      var score = (/option|menuitem|radio/i.test(role) || testId === "dropdown-menu-item" ? 10000 : 0) +
        (exact.toLowerCase() === optionDisplay(kind, value).toLowerCase() ? 5000 : 0) -
        rect.width * rect.height / 1000 - Math.abs(rect.top - window.innerHeight / 2) / 100;
      if (score > bestScore) { best = node; bestScore = score; }
    }
    if (best) return best;

    var fallback = document.querySelectorAll("span,div");
    for (var j = 0; j < fallback.length; j++) {
      var child = fallback[j];
      if (!isVisible(child) || !optionMatches(kind, nodeLabel(child), value)) continue;
      var childRect = child.getBoundingClientRect();
      if (childRect.width * childRect.height > 80000) continue;
      var interactive = child.closest('[role=option],[role=menuitem],[role=menuitemradio],[role=radio],button,[tabindex]');
      if (interactive && isVisible(interactive) && !interactive.disabled && interactive.getAttribute("aria-disabled") !== "true" &&
          !(kind === "ratio" && optionMatcher && optionMatcher.ratioTriggerLabel(nodeLabel(interactive)))) return interactive;
      // New Aspect ratio tiles can be plain divs without roles or tabindex.
      if (kind === "ratio" && normalize(child.textContent).replace(/\s+/g, "") === value) {
        var tile = child;
        while (tile.parentElement && normalize(tile.parentElement.textContent).replace(/\s+/g, "") === value) tile = tile.parentElement;
        var tileRect = tile.getBoundingClientRect();
        if (tileRect.width <= 240 && tileRect.height <= 160 && isVisible(tile) &&
            !tile.disabled && tile.getAttribute("aria-disabled") !== "true") return tile;
      }
    }
    return null;
  }

  function videoOptionIsSelected(kind, value) {
    var control = findVideoOptionControl(kind);
    if (control && optionMatches(kind, nodeLabel(control), value)) return true;
    var option = findVideoOptionTarget(kind, value);
    return !!(option && (option.getAttribute("aria-selected") === "true" || option.getAttribute("aria-checked") === "true" || option.getAttribute("data-state") === "checked"));
  }

  async function selectVideoOption(kind, value, deadline) {
    if (!value) return { selected: false, skipped: true };
    var display = optionDisplay(kind, value);
    var stopAt = Math.min(Number(deadline) || Date.now() + 20000, Date.now() + 20000);
    var lastOpen = 0;
    var trustedControlAttempted = false;
    var missingControlSince = 0;
    await diagnostic("running", "Selecting Dola " + kind + ": " + display + "…");
    while (Date.now() < stopAt) {
      if (videoOptionIsSelected(kind, value)) {
        await diagnostic("running", "Dola " + kind + " selected: " + display + ".");
        return { selected: true, deferred: false };
      }

      var target = findVideoOptionTarget(kind, value);
      if (target) {
        activate(target);
        await wait(650);
        if (videoOptionIsSelected(kind, value)) continue;
        if (target.isConnected) await requestTrustedClick(target);
        await wait(500);
        continue;
      }

      var control = findVideoOptionControl(kind);
      if (!control && kind === "resolution") {
        if (!missingControlSince) missingControlSince = Date.now();
        var missingFor = Date.now() - missingControlSince;
        var canDefer = optionMatcher && optionMatcher.shouldDeferMissingControl
          ? optionMatcher.shouldDeferMissingControl(kind, missingFor)
          : missingFor >= 2500;
        if (canDefer) {
          await diagnostic("running", "Dola hides the Resolution control for the selected model. " + display + " will be enforced and verified in the final request.");
          return { selected: false, deferred: true };
        }
      } else if (control) {
        missingControlSince = 0;
      }
      if (!control && Date.now() - lastOpen >= 1200) {
        var overflow = findOverflowControl();
        if (overflow) {
          lastOpen = Date.now();
          activate(overflow);
          await wait(400);
          continue;
        }
      }
      if (control && Date.now() - lastOpen >= 1200) {
        lastOpen = Date.now();
        activate(control);
        await wait(450);
        target = findVideoOptionTarget(kind, value);
        if (target) {
          activate(target);
          await wait(650);
          continue;
        }
        if (!trustedControlAttempted) {
          trustedControlAttempted = true;
          await requestTrustedClick(control);
          await wait(500);
        }
      }
      await wait(250);
    }
    throw new Error("Could not select Dola " + kind + " " + display + ". The option may be unavailable for this account/model; generation was not submitted.");
  }

  async function applyVideoOptions(settings, deadline) {
    if (!settings || !settings.enabled) return { settings: settings, resolutionDeferred: false };
    await selectVideoOption("ratio", settings.ratio, deadline);
    var resolutionResult = await selectVideoOption("resolution", settings.resolution, deadline);
    if (settings.model || settings.ratio || settings.resolution) {
      await diagnostic("running", resolutionResult && resolutionResult.deferred
        ? "Visible Video options confirmed. Hidden resolution " + optionDisplay("resolution", settings.resolution) + " will be verified in the submitted request. Duration remains submit-only. Model is also enforced and verified only on submit."
        : "Request settings saved; visible ratio/resolution confirmed: " + settingSummary(settings) + ". Duration remains submit-only. Model is also enforced and verified only on submit.");
    }
    return { settings: settings, resolutionDeferred: !!(resolutionResult && resolutionResult.deferred) };
  }

  function forceResultMatches(expected, result) {
    if (!expected || !expected.enabled || !result || result.status !== "success" || result.finalRequest !== true || !result.requestId) return false;
    var actual = result.settings || result;
    return Number(actual.duration) === expected.duration &&
      (!expected.ratio || actual.ratio === expected.ratio) &&
      (!expected.model || actual.model === expected.model) &&
      (!expected.resolution || actual.resolution === expected.resolution);
  }

  function setNativeValue(node, value) {
    var prototype = node.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    var descriptor = Object.getOwnPropertyDescriptor(prototype, "value");
    if (descriptor && descriptor.set) descriptor.set.call(node, value);
    else node.value = value;
    node.dispatchEvent(new Event("input", { bubbles: true }));
    node.dispatchEvent(new Event("change", { bubbles: true }));
  }

  function editorValue(editor) {
    if (!editor) return "";
    if (editor.matches("textarea, input")) return String(editor.value || "");
    return String(editor.innerText || editor.textContent || "");
  }

  function promptIsFilled(editor, prompt) {
    return normalize(editorValue(editor)) === normalize(prompt);
  }

  function injectPrompt(editor, prompt) {
    editor.focus();
    if (editor.matches("textarea, input")) {
      setNativeValue(editor, prompt);
    } else {
      var selection = window.getSelection && window.getSelection();
      try {
        var range = document.createRange();
        range.selectNodeContents(editor);
        selection.removeAllRanges();
        selection.addRange(range);
      } catch (error) {}
      var inserted = false;
      try { inserted = document.execCommand("insertText", false, prompt); } catch (error) {}
      if (!inserted || !promptIsFilled(editor, prompt)) editor.textContent = prompt;
      try { editor.dispatchEvent(new InputEvent("beforeinput", { bubbles: true, cancelable: true, inputType: "insertText", data: prompt })); }
      catch (error) {}
      try { editor.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: prompt })); }
      catch (error) { editor.dispatchEvent(new Event("input", { bubbles: true })); }
      editor.dispatchEvent(new Event("change", { bubbles: true }));
    }
    editor.setAttribute("data-dola-fd-video-editor", "true");
  }

  async function fillPrompt(prompt, deadline) {
    var editor = null;
    var stopAt = Math.min(Number(deadline) || Date.now() + 20000, Date.now() + 20000);
    var attempts = 0;
    while (Date.now() < stopAt) {
      editor = editor && editor.isConnected && isVisible(editor) ? editor : findVideoEditor();
      if (editor) {
        attempts++;
        injectPrompt(editor, prompt);
        await wait(700);
        if (promptIsFilled(editor, prompt)) {
          await diagnostic("running", "Prompt filled in the Video composer.");
          return editor;
        }
        if (attempts === 1) await diagnostic("running", "Dola ignored normal prompt input; trying trusted keyboard input…");
        await requestTrustedText(editor, prompt);
        await wait(500);
        if (promptIsFilled(editor, prompt)) {
          editor.setAttribute("data-dola-fd-video-editor", "true");
          await diagnostic("running", "Prompt filled in the Video composer.");
          return editor;
        }
      }
      await wait(300);
    }
    throw new Error(editor ? "Dola did not accept the prompt text." : "Could not find the Video prompt box.");
  }

  function findAttachButton(editor) {
    var root = editor;
    for (var level = 0; level < 6 && root; level++, root = root.parentElement) {
      var buttons = root.querySelectorAll("button, [role=button]");
      for (var i = 0; i < buttons.length; i++) {
        var label = normalize((buttons[i].getAttribute("aria-label") || "") + " " + (buttons[i].title || "") + " " + buttons[i].textContent);
        if (isVisible(buttons[i]) && (/attach|upload|add image|add file/i.test(label) || label === "+")) return buttons[i];
      }
    }
    return null;
  }

  function composerRoot(editor) {
    var root = editor;
    for (var level = 0; root && level < 6; level++, root = root.parentElement) {
      if (root === document.body) break;
      if (root.querySelector("button, [role=button], input[type=file]")) return root;
    }
    return editor.parentElement || editor;
  }

  function acceptsImage(input) {
    var accept = String(input.accept || "");
    return !input.disabled && (!accept || /image|png|jpe?g|webp/i.test(accept));
  }

  function findFileInput(editor, previousInputs) {
    var root = editor;
    for (var level = 0; root && root !== document.body && level < 7; level++, root = root.parentElement) {
      var inputs = root.querySelectorAll("input[type=file]");
      for (var i = 0; i < inputs.length; i++) {
        if (acceptsImage(inputs[i])) return inputs[i];
      }
    }
    // Upload menus can mount their hidden input outside the composer. Prefer
    // an input created by this upload click; otherwise require one unambiguous
    // image-specific input, never an arbitrary global file picker.
    var candidates = Array.from(document.querySelectorAll("input[type=file]")).filter(acceptsImage);
    var created = previousInputs ? candidates.filter(function(input){return !previousInputs.has(input);}) : [];
    if (created.length === 1) return created[0];
    candidates = candidates.filter(function(input){return /image|png|jpe?g|webp/i.test(String(input.accept || ""));});
    if (candidates.length === 1) return candidates[0];
    return null;
  }

  function attachFileTransfer(input, transfer) {
    // Use Chrome's native setter rather than a site-defined own property.
    var descriptor = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "files");
    input.value = "";
    if (descriptor && descriptor.set) descriptor.set.call(input, transfer.files);
    else input.files = transfer.files;
    input.dispatchEvent(new Event("input", { bubbles: true, composed: true }));
    input.dispatchEvent(new Event("change", { bubbles: true, composed: true }));
  }

  function referencePreviews(editor) {
    var previews = new Set();
    var seen = new Set();
    var editorRect = editor.getBoundingClientRect();
    var root = editor;
    for (var level = 0; root && root !== document.body && level < 12; level++, root = root.parentElement) {
      var nodes = root.querySelectorAll("img, div, span, [role=img]");
      for (var i = 0; i < nodes.length; i++) {
        var image = nodes[i];
        if (seen.has(image)) continue;
        seen.add(image);
        if (!isRendered(image)) continue;
        var rect = image.getBoundingClientRect();
        if (rect.right < editorRect.left - 100 || rect.left > editorRect.right + 100 || rect.bottom < editorRect.top - 260 || rect.top > editorRect.bottom + 160) continue;
        var src = image.currentSrc || image.src || "";
        // Uploaded thumbnails may use CSS backgrounds rather than img tags.
        // Compare against the pre-upload snapshot instead of guessing from URL
        // words (a real image filename can contain "logo" or "icon").
        if (src) previews.add(src);
        var background = getComputedStyle(image).backgroundImage || "";
        var urls = /url\(\s*(?:"([^"]*)"|'([^']*)'|([^)]*))\s*\)/g;
        var match;
        while ((match = urls.exec(background))) {
          var url = (match[1] || match[2] || match[3] || "").trim();
          if (url) previews.add(url);
        }
      }
    }
    return previews;
  }

  async function waitForReferencePreviews(editor, before, count, deadline) {
    var stableSince = 0;
    while (Date.now() < deadline) {
      var current = findVideoEditor() || editor;
      var added = Array.from(referencePreviews(current)).filter(function(src){return !before.has(src);});
      var busy = composerRoot(current).querySelector('[role=progressbar], [aria-busy="true"]');
      if (added.length >= count && !busy) {
        if (!stableSince) stableSince = Date.now();
        if (Date.now() - stableSince >= 1000) return;
      } else stableSince = 0;
      await wait(250);
    }
    throw new Error("Dola did not confirm all reference images in the Video composer. Generation was not submitted. Attach the images manually and try Fill prompt instead.");
  }

  async function decodeImages(images) {
    var files = [];
    for (var i = 0; i < images.length; i++) {
      var response = await fetch(images[i].dataUrl);
      var blob = await response.blob();
      files.push(new File([blob], images[i].name || ("image-" + (i + 1) + ".png"), { type: images[i].type || blob.type || "image/png" }));
    }
    return files;
  }

  async function dropImages(images) {
    if (!images || !images.length) throw new Error("Choose one or more images first.");
    var editor = findVideoEditor();
    if (!editor) throw new Error("Could not find the Video composer.");
    var before = referencePreviews(editor);
    var previousInputs = new Set(document.querySelectorAll("input[type=file]"));
    var input = findFileInput(editor);
    if (!input) {
      var attach = findAttachButton(editor);
      if (attach) {
        activate(attach);
        var inputDeadline = Date.now() + 3000;
        while (!input && Date.now() < inputDeadline) { await wait(150); input = findFileInput(editor, previousInputs); }
      }
    }
    var files = await decodeImages(images);
    var transfer = new DataTransfer();
    files.forEach(function (file) { transfer.items.add(file); });
    if (input) {
      if (files.length > 1 && !input.multiple) throw new Error("This Dola reference control accepts one image at a time. Choose one image and retry.");
      await diagnostic("running", "Attaching references through Dola's file input…");
      attachFileTransfer(input, transfer);
    } else {
      await diagnostic("running", "No unambiguous upload input found; trying the Video editor drop handler…");
      var target = editor;
      ["dragenter", "dragover", "drop"].forEach(function (type) {
        target.dispatchEvent(new DragEvent(type, { bubbles: true, cancelable: true, dataTransfer: transfer }));
      });
    }
    await waitForReferencePreviews(editor, before, files.length, Date.now() + 45000);
    await diagnostic("running", "Dola displayed " + files.length + " reference image preview(s).");
    return files.length;
  }

  function findSubmitButton(editor) {
    if (!editor) return null;
    var editorRect = editor.getBoundingClientRect();
    var buttons = [];
    var root = editor;
    for (var level = 0; root && root !== document.body && level < 12; level++, root = root.parentElement) {
      Array.from(root.querySelectorAll("button, [role=button], [tabindex], [data-testid], svg" )).forEach(function(button) {
        if (buttons.indexOf(button) < 0) buttons.push(button);
        if (String(button.tagName || "").toLowerCase() === "svg") {
          var parent = button.parentElement;
          for (var depth = 0; parent && parent !== root && depth < 4; depth++, parent = parent.parentElement) {
            if (buttons.indexOf(parent) < 0) buttons.push(parent);
          }
        }
      });
    }
    var best = null;
    var bestScore = -1;
    for (var i = 0; i < buttons.length; i++) {
      var button = buttons[i];
      if (!isVisible(button) || button.disabled || button.getAttribute("aria-disabled") === "true") continue;
      var rect = button.getBoundingClientRect();
      if (rect.left < editorRect.right - 160 || rect.right > editorRect.right + 180 || Math.abs(rect.bottom - editorRect.bottom) > 220) continue;
      var label = normalize((button.getAttribute("aria-label") || "") + " " + (button.title || "") + " " + button.textContent);
      if (/attach|upload|image|file|ratio|model|duration|continue|shorter|unsupported|log\s*out|sign\s*out|delete|reset|account|settings/i.test(label) || label === "+") continue;
      var semanticSend = /generate|send|submit|create/i.test(label);
      var nativeButton = /^(BUTTON|INPUT)$/i.test(button.tagName || "") || button.getAttribute("role") === "button";
      var marker = String(button.getAttribute("data-testid") || "");
      var style = getComputedStyle(button);
      var colors = String(style.backgroundColor || "") + " " + String(style.color || "");
      var blue = false;
      var colorPattern = /rgba?\(\s*(\d+)\s*[, ]\s*(\d+)\s*[, ]\s*(\d+)(?:\s*[,/]\s*([\d.]+))?/g;
      var color;
      while ((color = colorPattern.exec(colors))) {
        if (Number(color[3]) > 140 && Number(color[3]) > Number(color[1]) + 40 && Number(color[3]) > Number(color[2]) + 15 && (color[4] == null || Number(color[4]) > 0.15)) blue = true;
      }
      var customArrow = blue && style.cursor === "pointer" && rect.width >= 20 && rect.width <= 88 && rect.height >= 20 && rect.height <= 88 && Math.abs(rect.width - rect.height) < 24 && button.querySelector && !!button.querySelector("svg");
      if (!nativeButton && !semanticSend && !/send|submit|generate/i.test(marker) && !customArrow) continue;
      var score = rect.right + (semanticSend ? 1000 : 0) + (customArrow ? 800 : 0) + (button.type === "submit" ? 700 : 0);
      if (Math.abs(rect.width - rect.height) < 20) score += 200;
      if (score > bestScore) { best = button; bestScore = score; }
    }
    return best;
  }

  async function clickGenerateButton(button) {
    if (button.scrollIntoView) button.scrollIntoView({ block: "nearest", inline: "nearest" });
    var trusted = await requestTrustedClick(button);
    if (trusted && trusted.ok) return;
    await diagnostic("running", "Chrome trusted Generate click unavailable: " + (trusted && trusted.error || "no response") + ". Trying page click…");
    activate(button);
  }

  function shorterDurationOffer(expected) {
    if (!expected || !expected.enabled || !expected.duration) return "";
    var dialogs = document.querySelectorAll('[role=dialog], [aria-modal="true"]');
    for (var i = 0; i < dialogs.length; i++) {
      if (!isRendered(dialogs[i])) continue;
      var text = normalize(dialogs[i].textContent);
      if (!/continue|instead|shorter|only|maximum|would you like|do you want/i.test(text)) continue;
      var pattern = /(\d+)\s*(?:s\b|secs?\b|seconds?\b)/gi;
      var match;
      while ((match = pattern.exec(text))) {
        var offered = Number(match[1]);
        if (offered > 0 && offered < expected.duration) return "Dola offers " + offered + "s instead of " + expected.duration + "s. Automation stopped for your decision. Accept or cancel in Dola; the saved duration has not changed.";
      }
    }
    return "";
  }

  function generationSucceeded() {
    if (findRetryableGenerationError()) return false;
    var text = normalize(document.body && document.body.innerText);
    return /^\/chat\/(?!create-image(?:[/?#]|$))[^/?#]+/i.test(location.pathname) &&
      /video will be generated|video is being generated|generated by Dola AI|ready in \d+ minutes?/i.test(text);
  }

  function pageGenerationFailure() {
    if (generationRetryExhausted) {
      return "Prompt FAILED: Dola still reported “Something went wrong. Please try again.” after 5 automatic retry attempts.";
    }
    if (/[?&]from_logout=1(?:&|$)/i.test(location.search)) {
      return "Prompt FAILED: Dola logged out after the generation request. Automatic resubmission was stopped.";
    }
    var text = normalize(document.body && document.body.innerText);
    if (/experiencing high demand|please try again later|too many requests/i.test(text)) {
      return "Prompt FAILED: Dola reported high demand. Automatic resubmission was stopped to protect the account session.";
    }
    return "";
  }

  var generationRetryExhausted = false;

  function retryControlLabel(node) {
    if (!node) return "";
    var titleNode = node.querySelector && node.querySelector("title");
    return normalize([
      node.getAttribute && node.getAttribute("aria-label"),
      node.getAttribute && node.getAttribute("title"),
      node.getAttribute && node.getAttribute("data-testid"),
      node.getAttribute && node.getAttribute("data-test-id"),
      node.getAttribute && node.getAttribute("data-icon"),
      node.getAttribute && node.getAttribute("class"),
      titleNode && titleNode.textContent,
      node.textContent
    ].filter(Boolean).join(" "));
  }

  function isInViewport(node) {
    if (!isRendered(node)) return false;
    var rect = node.getBoundingClientRect();
    return rect.bottom >= 0 && rect.top <= (window.innerHeight || document.documentElement.clientHeight || 0);
  }

  function findRetryableGenerationErrors() {
    if (!retryPolicy || !retryPolicy.isRetryableError || !document.body) return [];
    var nodes = document.body.querySelectorAll("div, p, span");
    var matches = [];
    for (var i = 0; i < nodes.length; i++) {
      if (isInViewport(nodes[i]) && retryPolicy.isRetryableError(nodes[i].textContent)) matches.push(nodes[i]);
    }
    return matches.filter(function (node) {
      return !matches.some(function (other) { return other !== node && node.contains(other); });
    }).sort(function (left, right) {
      var delta = left.getBoundingClientRect().top - right.getBoundingClientRect().top;
      if (delta) return delta;
      return left.compareDocumentPosition(right) & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1;
    });
  }

  function findRetryableGenerationError() {
    var errors = findRetryableGenerationErrors();
    return errors.length ? errors[errors.length - 1] : null;
  }

  function textHash(value) {
    var text = String(value || "");
    var hash = 2166136261;
    for (var i = 0; i < text.length; i++) {
      hash ^= text.charCodeAt(i);
      hash = Math.imul(hash, 16777619);
    }
    return (hash >>> 0).toString(36);
  }

  function retryErrorKey(node, errors) {
    var current = node;
    var identity = "";
    var context = "";
    for (var depth = 0; current && depth < 6; depth++, current = current.parentElement) {
      identity = identity || ["data-message-id", "data-msg-id", "data-id", "id"].map(function (name) {
        return current.getAttribute && current.getAttribute(name);
      }).filter(Boolean)[0] || "";
      var candidateText = normalize(current.textContent);
      if (candidateText.length > retryPolicy.ERROR_MESSAGE.length && candidateText.length <= 3000) context = candidateText;
    }
    return location.pathname + "|" + identity + "|" + errors.indexOf(node) + "|" + textHash(context.slice(-1500));
  }

  function retryCandidateTarget(node, scope) {
    if (!node) return null;
    var isSvg = String(node.tagName || "").toLowerCase() === "svg";
    if (!isSvg && ((node.matches && node.matches("button, [role=button], a, [tabindex]:not([tabindex='-1'])")) || node.onclick || getComputedStyle(node).cursor === "pointer")) return node;
    var current = node.parentElement;
    while (current && current !== scope) {
      var style = getComputedStyle(current);
      if ((current.matches && current.matches("button, [role=button], a, [tabindex]:not([tabindex='-1'])")) || current.onclick || style.cursor === "pointer") return current;
      current = current.parentElement;
    }
    return node;
  }

  function collectRetryCandidates(scope, errorNode) {
    var raw = scope.querySelectorAll("button, [role=button], a, [tabindex]:not([tabindex='-1']), [class*='cursor-pointer'], svg");
    var errorRect = errorNode.getBoundingClientRect();
    var candidates = [];
    for (var i = 0; i < raw.length; i++) {
      var target = retryCandidateTarget(raw[i], scope);
      if (!target || candidates.indexOf(target) >= 0 || target.contains(errorNode) || !isVisible(target)) continue;
      var rect = target.getBoundingClientRect();
      if (rect.top < errorRect.bottom - 24 || rect.top > errorRect.bottom + 180) continue;
      if (rect.right < errorRect.left - 80 || rect.left > errorRect.right + 80) continue;
      candidates.push(target);
    }
    return candidates;
  }

  function findRetryControl(errorNode) {
    if (!errorNode || !retryPolicy) return null;
    var errorRect = errorNode.getBoundingClientRect();
    var scope = errorNode.parentElement;
    for (var depth = 0; scope && scope !== document.body && depth < 8; depth++, scope = scope.parentElement) {
      var candidates = collectRetryCandidates(scope, errorNode);
      for (var i = 0; i < candidates.length; i++) {
        var label = retryControlLabel(candidates[i]);
        if (retryPolicy.isRetryHint(label) && !retryPolicy.isExcludedHint(label)) return candidates[i];
      }

      var compact = candidates.filter(function (candidate) {
        var rect = candidate.getBoundingClientRect();
        return rect.width > 0 && rect.height > 0 && rect.width <= 80 && rect.height <= 80;
      }).sort(function (left, right) {
        var leftRect = left.getBoundingClientRect();
        var rightRect = right.getBoundingClientRect();
        return Math.abs(leftRect.top - rightRect.top) > 12 ? leftRect.top - rightRect.top : leftRect.left - rightRect.left;
      });

      var rows = [];
      compact.forEach(function (candidate) {
        var rect = candidate.getBoundingClientRect();
        var centerY = rect.top + rect.height / 2;
        var row = rows.find(function (entry) { return Math.abs(entry.centerY - centerY) <= 12; });
        if (!row) { row = { centerY: centerY, controls: [] }; rows.push(row); }
        if (row.controls.indexOf(candidate) < 0) row.controls.push(candidate);
      });
      rows.sort(function (left, right) {
        return Math.abs(left.centerY - errorRect.bottom) - Math.abs(right.centerY - errorRect.bottom);
      });
      for (var rowIndex = 0; rowIndex < rows.length; rowIndex++) {
        var controls = rows[rowIndex].controls.sort(function (left, right) {
          return left.getBoundingClientRect().left - right.getBoundingClientRect().left;
        });
        // Dola's failed-response action row is Copy, Like, Dislike, Share,
        // Retry, More. The geometric fallback is deliberately limited to
        // that six-control row and selects only its fifth control.
        if (controls.length === 6 && !retryPolicy.isExcludedHint(retryControlLabel(controls[4]))) return controls[4];
      }
    }
    return null;
  }

  function scheduleGenerationErrorMonitor(delay) {
    clearTimeout(retryMonitorTimer);
    retryMonitorTimer = setTimeout(monitorGenerationError, Math.max(0, Number(delay) || 0));
  }

  async function monitorGenerationError() {
    if (retryMonitorRunning || !retryPolicy) return;
    retryMonitorRunning = true;
    try {
      var errors = findRetryableGenerationErrors();
      var errorNode = errors.length ? errors[errors.length - 1] : null;
      if (!errorNode) { retryErrorWasVisible = false; generationRetryExhausted = false; return; }
      var continuouslyVisible = retryErrorWasVisible;
      retryErrorWasVisible = true;
      var now = Date.now();
      var key = retryErrorKey(errorNode, errors);
      var state = await getRetryState();
      var activeRetryRerender = state && state.path === location.pathname && Number(state.expiresAt) > now &&
        Number(state.attempts) > 0 && !state.failedLogged;
      var exhaustedErrorRerender = state && state.path === location.pathname && Number(state.expiresAt) > now &&
        state.failedLogged && continuouslyVisible;
      if (!state || (state.errorKey !== key && !activeRetryRerender && !exhaustedErrorRerender) || Number(state.expiresAt) <= now) {
        state = {
          errorKey: key,
          path: location.pathname,
          attempts: 0,
          lastAttemptAt: now,
          expiresAt: now + 30 * 60 * 1000,
          failedLogged: false
        };
        generationRetryExhausted = false;
        await setRetryState(state);
        await diagnostic("running", "Dola reported “Something went wrong. Please try again.” Waiting 2.5 seconds before automatic retry 1/5.");
        scheduleGenerationErrorMonitor(retryPolicy.RETRY_DELAY_MS);
        return;
      }
      if (state.errorKey !== key) {
        // Dola may replace the failed assistant message with a new DOM/message
        // id after Retry. Keep the same attempt budget for that rerender.
        state.errorKey = key;
        await setRetryState(state);
      }

      var next = retryPolicy.decision(state, now, true);
      if (next.action === "wait") {
        scheduleGenerationErrorMonitor(next.waitMs || 500);
        return;
      }
      if (next.action === "failed") {
        generationRetryExhausted = true;
        if (!state.failedLogged) {
          state.failedLogged = true;
          await setRetryState(state);
          await diagnostic("failed", "Prompt FAILED: Dola still reported “Something went wrong. Please try again.” after 5 automatic retry attempts.");
        }
        return;
      }

      var control = findRetryControl(errorNode);
      if (!control) {
        if (!state.controlMissingLogged) {
          state.controlMissingLogged = true;
          await setRetryState(state);
          await diagnostic("running", "Dola error detected; waiting for its Retry control to appear.");
        }
        scheduleGenerationErrorMonitor(500);
        return;
      }

      state.attempts = next.nextAttempt;
      state.lastAttemptAt = now;
      state.expiresAt = now + 30 * 60 * 1000;
      state.controlMissingLogged = false;
      await setRetryState(state);
      await diagnostic("running", "Retrying Dola generation after the temporary error (attempt " + state.attempts + "/5)…");
      if (!activate(control)) {
        var trustedResult = await requestTrustedClick(control);
        if (!trustedResult || !trustedResult.ok) await diagnostic("running", "Retry click was not accepted; another attempt will be made in 2.5 seconds.");
      }
      scheduleGenerationErrorMonitor(retryPolicy.RETRY_DELAY_MS);
    } finally {
      retryMonitorRunning = false;
    }
  }

  async function submitUntilSuccess(deadline, startedAt) {
    var lastClick = 0;
    var generationConfirmedAt = 0;
    var submittedRequestId = "";
    var lastStorageRead = 0;
    var expectedForce = await forceExpectation();
    startedAt = Number(startedAt) || Date.now();
    durationRefusal = null;
    generationRejection = null;
    generationForceResult = null;
    generationResponse = null;
    await diagnostic("running", "Prompt filled. Waiting for the blue Generate arrow…");
    while (Date.now() < deadline) {
      if (Date.now() - lastStorageRead >= 500) {
        lastStorageRead = Date.now();
        var storedSignals = await latestGenerationSignals();
        if (storedSignals.dolaLatestForceResult && Number(storedSignals.dolaLatestForceResult.at) >= startedAt) generationForceResult = storedSignals.dolaLatestForceResult;
        if (storedSignals.dolaLatestGenerationResponse && Number(storedSignals.dolaLatestGenerationResponse.at) >= startedAt) generationResponse = storedSignals.dolaLatestGenerationResponse;
      }
      if (durationRefusal && Number(durationRefusal.at) >= startedAt) {
        var refusalRequestMatches = !submittedRequestId || !durationRefusal.requestId || durationRefusal.requestId === submittedRequestId;
        if (!refusalRequestMatches) { durationRefusal = null; continue; }
        var refusalError = new Error(durationRefusal.message || "Prompt FAILED: Dola refused the selected duration.");
        refusalError.code = "DOLA_UNSUPPORTED_DURATION";
        throw refusalError;
      }
      if (generationRejection && Number(generationRejection.at) >= startedAt) {
        var rejectedRequestMatches = !submittedRequestId || !generationRejection.requestId || generationRejection.requestId === submittedRequestId;
        if (!rejectedRequestMatches) { generationRejection = null; continue; }
        var rejectionError = new Error(generationRejection.message || "Prompt FAILED: Dola rejected the generation request.");
        rejectionError.code = "DOLA_GENERATION_REJECTED";
        throw rejectionError;
      }
      if (forceResultMatches(expectedForce, generationForceResult) && Number(generationForceResult.at) >= startedAt) {
        if (!submittedRequestId) {
          submittedRequestId = generationForceResult.requestId;
          await diagnostic("running", "Generation request sent once with verified settings: " + settingSummary(expectedForce) + ". Waiting for Dola confirmation…");
        }
      } else if (generationForceResult && Number(generationForceResult.at) >= startedAt && generationForceResult.finalRequest && generationForceResult.status === "failed") {
        var forceError = new Error(generationForceResult.message || "Prompt FAILED: the selected settings were not present in the final request.");
        forceError.code = "DOLA_DURATION_NOT_APPLIED";
        throw forceError;
      }
      if (generationResponse && Number(generationResponse.at) >= startedAt && (!submittedRequestId || !generationResponse.requestId || generationResponse.requestId === submittedRequestId)) {
        if (generationResponse.status === "failed" || Number(generationResponse.statusCode) >= 400 || generationResponse.settingsMissed || generationResponse.loginRejected) {
          var responseError = new Error(generationResponse.message || "Prompt FAILED: Dola rejected the generation request.");
          responseError.code = "DOLA_GENERATION_REJECTED";
          throw responseError;
        }
      }
      var pageFailure = pageGenerationFailure();
      if (pageFailure) {
        var pageError = new Error(pageFailure);
        pageError.code = "DOLA_GENERATION_REJECTED";
        throw pageError;
      }
      if (generationSucceeded()) {
        if (!expectedForce.enabled) return;
        if (submittedRequestId && forceResultMatches(expectedForce, generationForceResult)) {
          await diagnostic("running", "Dola accepted one request with the exact submitted settings: " + settingSummary(expectedForce) + ".");
          return;
        }
        if (!generationConfirmedAt) {
          generationConfirmedAt = Date.now();
          await diagnostic("running", "Dola accepted the prompt. Verifying the selected settings: " + settingSummary(expectedForce) + "…");
        } else if (Date.now() - generationConfirmedAt >= 5000) {
          var auditError = new Error("Prompt FAILED: Dola accepted the prompt, but the extension could not verify the selected values in the submitted generation settings.");
          auditError.code = "DOLA_DURATION_NOT_APPLIED";
          throw auditError;
        }
      }
      var editor = findVideoEditor();
      var shorterOffer = shorterDurationOffer(expectedForce);
      if (shorterOffer) {
        var approvalError = new Error(shorterOffer);
        approvalError.code = "DOLA_DURATION_CONFIRMATION_REQUIRED";
        throw approvalError;
      }
      var button = findSubmitButton(editor);
      if (!submittedRequestId && button && Date.now() - lastClick >= 2000) {
        lastClick = Date.now();
        await diagnostic("running", "Clicking the blue Generate arrow…");
        await clickGenerateButton(button);
      }
      await wait(250);
    }
    throw new Error(lastClick ? "Generate was clicked, but no confirmed generation followed. Check the workflow log for Chrome debugger errors or Dola request rejection." : "Could not find an enabled Generate arrow near the Video composer. No generation was submitted.");
  }

  function needsImages(action) {
    return action === "drop" || action === "drop_prompt_generate";
  }

  function needsPrompt(action) {
    return action === "fill" || action === "prompt_generate" || action === "drop_prompt_generate";
  }

  function needsGenerate(action) {
    return action === "prompt_generate" || action === "drop_prompt_generate";
  }

  function promptWithDurationApproval(prompt, settings) {
    return String(prompt || "");
  }

  function nextAfterVideo(state) {
    return needsImages(state.action) ? "drop_images" : (needsPrompt(state.action) ? "fill_prompt" : "done");
  }

  function nextAfterDrop(state) {
    return needsPrompt(state.action) ? "fill_prompt" : "done";
  }

  async function complete(state, message) {
    await clearState();
    await diagnostic("success", message);
  }

  function startNextPendingPrompt() {
    return new Promise(function (resolve) {
      api.storage.local.get(QUEUE_KEY, function (data) {
        var queue = data && Array.isArray(data[QUEUE_KEY]) ? data[QUEUE_KEY].slice() : [];
        if (!queue.length) { resolve(false); return; }
        var queued = queue.shift();
        var next = typeof queued === "string" ? { action: "prompt_generate", prompt: queued, images: [] } : Object.assign({}, queued || {});
        if (!next.prompt && (!next.images || !next.images.length)) { resolve(false); return; }
        next.active = true;
        next.id = next.id || String(Date.now()) + "-" + Math.random().toString(16).slice(2);
        next.action = next.action || "prompt_generate";
        next.images = next.images || [];
        next.stage = "navigate_chat";
        next.deadline = Date.now() + 180000;
        var update = {};
        update[STATE_KEY] = next;
        update[QUEUE_KEY] = queue;
        api.storage.local.set(update, function () { resolve(true); });
      });
    });
  }

  async function resumeWorkflow() {
    if (running) return;
    running = true;
    try {
      var state = await getState();
      if (!state || !state.active) return;
      var deadline = Number(state.deadline) || Date.now() + 180000;
      while (state && state.active) {
        if (/[?&]from_logout=1(?:&|$)/i.test(location.search)) throw new Error("Workflow stopped: Dola signed out. Log in before starting another generation.");
        if (Date.now() >= deadline) throw new Error("Workflow stopped after the 3-minute timeout.");
        if (state.stage === "navigate_chat") {
          if (!/^\/chat\/?$/i.test(location.pathname)) {
            location.assign("https://www.dola.com/chat");
            return;
          }
          state.stage = "select_video";
          await setState(state);
        } else if (state.stage === "select_video") {
          await ensureVideoMode(deadline);
          await applyVideoOptions(await forceExpectation(), deadline);
          state = await getState();
          if (!state || !state.active) return;
          state.stage = nextAfterVideo(state);
          await setState(state);
        } else if (state.stage === "drop_images") {
          await diagnostic("running", "Dropping selected images into Video creation…");
          var count = await dropImages(state.images || []);
          state.stage = nextAfterDrop(state);
          state.imageCount = count;
          await setState(state);
        } else if (state.stage === "fill_prompt") {
          await diagnostic("running", "Filling the Video prompt…");
          var filledPrompt = promptWithDurationApproval(state.prompt, await forceExpectation());
          await fillPrompt(filledPrompt, deadline);
          await wait(500);
          state.stage = needsGenerate(state.action) ? "submit" : "done";
          await setState(state);
        } else if (state.stage === "submit") {
          if (!state.submitStartedAt) {
            state.submitStartedAt = Date.now();
            await setState(state);
          }
          await submitUntilSuccess(deadline, state.submitStartedAt);
          state.stage = "done";
          await setState(state);
        } else if (state.stage === "done") {
          var message = needsGenerate(state.action) ? "Generation request submitted with verified settings." : (needsImages(state.action) && !needsPrompt(state.action) ? "Images dropped into Video creation." : "Video prompt filled.");
          await complete(state, message);
          if (await startNextPendingPrompt()) {
            await diagnostic("running", "Starting the next pending prompt.");
            setTimeout(resumeWorkflow, 50);
          }
          return;
        } else {
          state.stage = "navigate_chat";
          await setState(state);
        }
        state = await getState();
      }
    } catch (error) {
      await clearState();
      await diagnostic("failed", error && error.message || String(error));
      if (error && ["DOLA_GENERATION_REJECTED", "DOLA_DURATION_NOT_APPLIED"].indexOf(error.code) >= 0 && await startNextPendingPrompt()) {
        await diagnostic("running", "Continuing with the next pending prompt after the failed request.");
        setTimeout(resumeWorkflow, 50);
      }
    } finally {
      running = false;
    }
  }

  api.runtime.onMessage.addListener(function (message, sender, sendResponse) {
    if (!message) return;
    if (message.type === "DOLA_FD_WORKFLOW_RESUME") {
      resumeWorkflow();
      if (sendResponse) sendResponse({ ok: true });
      return;
    }
    if (message.type === "DOLA_FD_APPLY_OPTIONS") {
      (async function () {
        try {
          var deadline = Date.now() + 45000;
          await ensureVideoMode(deadline);
          var settings = await forceExpectation();
          var appliedOptions = await applyVideoOptions(settings, deadline);
          var text = appliedOptions && appliedOptions.resolutionDeferred
            ? "Visible options applied. Dola hides Resolution for this model, so " + optionDisplay("resolution", settings.resolution) + " will be enforced and verified when you submit."
            : settings.model || settings.ratio || settings.resolution
              ? "Saved for submit (model); applied visible ratio/resolution: " + settingSummary(settings) + "."
            : "Settings saved. No optional video controls were selected.";
          if (sendResponse) sendResponse({ ok: true, message: text, settings: settings });
        } catch (error) {
          var failure = error && error.message || String(error);
          await diagnostic("failed", failure);
          if (sendResponse) sendResponse({ ok: false, error: failure });
        }
      }());
      return true;
    }
  });

  window.addEventListener("message", function (event) {
    var message = event && event.data;
    if (message && message.type === "DOLA_FD_DURATION_REFUSED") durationRefusal = message;
    if (message && message.type === "DOLA_FD_GENERATION_REJECTED") generationRejection = message;
    if (message && message.type === "DOLA_FD_FORCE_RESULT") generationForceResult = message;
    if (message && message.type === "DOLA_FD_GENERATION_RESPONSE") generationResponse = message;
  });

  if (retryPolicy && document.body) {
    new MutationObserver(function () { scheduleGenerationErrorMonitor(200); }).observe(document.body, {
      childList: true,
      subtree: true,
      characterData: true
    });
    setInterval(function () { scheduleGenerationErrorMonitor(0); }, 1000);
    scheduleGenerationErrorMonitor(0);
  }

  getState().then(function (state) {
    if (state && state.active) resumeWorkflow();
  });
}());
