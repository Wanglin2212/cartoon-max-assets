(function () {
  "use strict";

  var api = typeof browser !== "undefined" ? browser : chrome;
  var promiseApi = typeof browser !== "undefined";
  var promptInput = document.getElementById("workflowPrompt");
  var imageInput = document.getElementById("workflowImages");
  var imagePreview = document.getElementById("workflowImagePreview");
  var clearImagesButton = document.getElementById("clearWorkflowImages");
  var status = document.getElementById("workflowStatus");
  if (!promptInput || !imageInput || !imagePreview || !clearImagesButton || !status) return;

  var pendingAction = null;
  var promptSaveTimer = null;
  var selectedFiles = [];
  var previewUrls = [];
  var WORKFLOW_KEY = "dolaWorkflowRun";
  var QUEUE_KEY = "dolaWorkflowQueue";

  function setStatus(message, error) {
    status.textContent = message;
    status.style.color = error ? "#c0392b" : "#1a7f37";
  }

  function errorMessage(error, fallback) {
    return String(error && (error.error || error.reason || error.message) || fallback);
  }

  function queryTabs(query) {
    if (promiseApi) {
      try { return Promise.resolve(api.tabs.query(query)); }
      catch (error) { return Promise.reject(error); }
    }
    return new Promise(function (resolve, reject) {
      api.tabs.query(query, function (tabs) {
        var message = api.runtime.lastError && api.runtime.lastError.message;
        if (message) reject(new Error(message));
        else resolve(tabs || []);
      });
    });
  }

  function sendTabMessage(tabId, message) {
    if (promiseApi) {
      try { return Promise.resolve(api.tabs.sendMessage(tabId, message)); }
      catch (error) { return Promise.reject(error); }
    }
    return new Promise(function (resolve, reject) {
      api.tabs.sendMessage(tabId, message, function (result) {
        var message = api.runtime.lastError && api.runtime.lastError.message;
        if (message) reject(new Error(message));
        else resolve(result);
      });
    });
  }

  function setDownloadPending(pending, activeButton) {
    ["dlLatest", "dlAll", "workflowDownload"].forEach(function (id) {
      var button = document.getElementById(id);
      if (!button) return;
      button.disabled = !!pending;
      if (pending && button === activeButton) button.setAttribute("aria-busy", "true");
      else button.removeAttribute("aria-busy");
    });
  }

  function renderImages() {
    previewUrls.forEach(function (url) { URL.revokeObjectURL(url); });
    previewUrls = [];
    imagePreview.textContent = "";
    selectedFiles.forEach(function (file, index) {
      var card = document.createElement("div");
      card.className = "workflow-image";
      var image = document.createElement("img");
      var url = URL.createObjectURL(file);
      previewUrls.push(url);
      image.src = url;
      image.alt = file.name;
      image.title = file.name;
      var name = document.createElement("span");
      name.textContent = file.name;
      name.title = file.name;
      var remove = document.createElement("button");
      remove.type = "button";
      remove.className = "remove-image";
      remove.textContent = "×";
      remove.setAttribute("aria-label", "Remove " + file.name);
      remove.title = "Remove " + file.name;
      remove.addEventListener("click", function () {
        selectedFiles.splice(index, 1);
        renderImages();
        setStatus(selectedFiles.length ? selectedFiles.length + " image" + (selectedFiles.length === 1 ? "" : "s") + " selected." : "All images removed.");
      });
      card.appendChild(image);
      card.appendChild(remove);
      card.appendChild(name);
      imagePreview.appendChild(card);
    });
    clearImagesButton.style.display = selectedFiles.length ? "block" : "none";
  }

  function getActiveDolaTab() {
    return queryTabs({ active: true, currentWindow: true }).then(function (tabs) {
      var tab = tabs && tabs[0];
      if (!tab || !/^https?:\/\/(www\.)?dola\.com\//i.test(tab.url || "")) throw new Error("Open a dola.com tab first.");
      return tab;
    });
  }

  function sendToDola(message) {
    return getActiveDolaTab().then(function (tab) {
      return sendTabMessage(tab.id, message).then(function (result) {
        if (!result || !result.ok) {
          throw new Error(errorMessage(result, "The Dola action could not be completed."));
        }
        return result;
      });
    });
  }

  function storageCall(method, value) {
    if (promiseApi) {
      try { return Promise.resolve(api.storage.local[method](value)); }
      catch (error) { return Promise.reject(error); }
    }
    return new Promise(function (resolve, reject) {
      api.storage.local[method](value, function (result) {
        var message = api.runtime.lastError && api.runtime.lastError.message;
        if (message) reject(new Error(message));
        else resolve(result);
      });
    });
  }

  function updateTab(tabId, changes) {
    if (promiseApi) {
      try { return Promise.resolve(api.tabs.update(tabId, changes)); }
      catch (error) { return Promise.reject(error); }
    }
    return new Promise(function (resolve, reject) {
      api.tabs.update(tabId, changes, function (tab) {
        var message = api.runtime.lastError && api.runtime.lastError.message;
        if (message) reject(new Error(message));
        else resolve(tab);
      });
    });
  }

  function setLocal(data) {
    return storageCall("set", data);
  }

  function getLocal(keys) {
    return storageCall("get", keys);
  }

  function removeLocal(key) {
    return storageCall("remove", key);
  }

  function openWorkflowPage(tab) {
    return updateTab(tab.id, { url: "https://www.dola.com/chat" });
  }

  function readFile(file) {
    return new Promise(function (resolve, reject) {
      var reader = new FileReader();
      reader.onload = function () {
        resolve({ name: file.name, type: file.type || "image/png", dataUrl: reader.result });
      };
      reader.onerror = function () { reject(new Error("Could not read " + file.name)); };
      reader.readAsDataURL(file);
    });
  }

  function actionNeedsImages(action) {
    return action === "drop" || action === "drop_prompt_generate";
  }

  function actionNeedsPrompt(action) {
    return action === "fill" || action === "prompt_generate" || action === "drop_prompt_generate";
  }

  async function runAction(action) {
    var runId = "";
    try {
      var files = selectedFiles.slice();
      var prompt = String(promptInput.value || "").trim();
      if (actionNeedsImages(action) && !files.length) {
        pendingAction = action;
        setStatus("Choose one or more images…");
        imageInput.click();
        return;
      }
      if (actionNeedsPrompt(action) && !prompt) {
        promptInput.focus();
        throw new Error("Enter a prompt first.");
      }
      setStatus("Running workflow…");
      var images = actionNeedsImages(action) ? await Promise.all(files.map(readFile)) : [];
      var tab = await getActiveDolaTab();
      var run = {
        active: true,
        id: String(Date.now()) + "-" + Math.random().toString(16).slice(2),
        action: action,
        prompt: prompt,
        images: images,
        stage: "navigate_chat",
        deadline: Date.now() + 180000
      };
      runId = run.id;
      var firstEntry = { status: "running", step: "workflow", message: "Opening Dola video creation…", time: new Date().toISOString(), url: "/chat" };
      var stored = await getLocal(["dolaWorkflowDiagnosticLog", WORKFLOW_KEY, QUEUE_KEY]);
      var workflowLog = stored && Array.isArray(stored.dolaWorkflowDiagnosticLog) ? stored.dolaWorkflowDiagnosticLog.slice(-99) : [];
      if (stored && stored[WORKFLOW_KEY] && stored[WORKFLOW_KEY].active) {
        var queue = Array.isArray(stored[QUEUE_KEY]) ? stored[QUEUE_KEY].slice() : [];
        queue.push({ id: run.id, action: run.action, prompt: run.prompt, images: run.images });
        firstEntry.message = "Added prompt to the pending queue (position " + queue.length + ").";
        workflowLog.push(firstEntry);
        var queuedUpdate = { dolaWorkflowDiagnostic: firstEntry, dolaWorkflowDiagnosticLog: workflowLog };
        queuedUpdate[QUEUE_KEY] = queue;
        await setLocal(queuedUpdate);
        setStatus(firstEntry.message);
        return;
      }
      workflowLog.push(firstEntry);
      var update = { dolaWorkflowDiagnostic: firstEntry, dolaWorkflowDiagnosticLog: workflowLog };
      update[WORKFLOW_KEY] = run;
      await setLocal(update);
      await openWorkflowPage(tab);
      setStatus("Opening Dola video creation…");
    } catch (error) {
      if (runId) {
        var current = await getLocal(WORKFLOW_KEY);
        if (current && current[WORKFLOW_KEY] && current[WORKFLOW_KEY].id === runId) await removeLocal(WORKFLOW_KEY);
      }
      setStatus(error.message || String(error), true);
    }
  }

  function bind(id, action) {
    var button = document.getElementById(id);
    if (button) button.addEventListener("click", function () { runAction(action); });
  }

  bind("dropImages", "drop");
  bind("fillPrompt", "fill");
  bind("promptGenerate", "prompt_generate");
  bind("dropPromptGenerate", "drop_prompt_generate");

  var downloadButton = document.getElementById("workflowDownload");
  if (downloadButton) downloadButton.addEventListener("click", function (event) {
    var button = event.currentTarget;
    setDownloadPending(true, button);
    setStatus("Finding latest no-watermark video…");
    sendToDola({ type: "DOLA_FD_DL_LATEST" }).then(function (result) {
      if (!result || !result.ok) throw new Error(errorMessage(result, "No no-watermark video found. Open the chat with the video."));
      setStatus("Downloading " + result.count + " video" + (result.count === 1 ? "." : "s."));
    }).catch(function (error) {
      setStatus(errorMessage(error, "The Dola action could not be completed."), true);
    }).finally(function () { setDownloadPending(false); });
  });

  imageInput.addEventListener("change", function () {
    var additions = Array.prototype.slice.call(imageInput.files || []);
    additions.forEach(function (file) {
      var duplicate = selectedFiles.some(function (selected) {
        return selected.name === file.name && selected.size === file.size && selected.lastModified === file.lastModified;
      });
      if (!duplicate) selectedFiles.push(file);
    });
    imageInput.value = "";
    renderImages();
    if (selectedFiles.length) setStatus(selectedFiles.length + " image" + (selectedFiles.length === 1 ? "" : "s") + " selected.");
    if (pendingAction && selectedFiles.length) {
      var action = pendingAction;
      pendingAction = null;
      runAction(action);
    }
  });

  clearImagesButton.addEventListener("click", function () {
    selectedFiles = [];
    pendingAction = null;
    renderImages();
    setStatus("All images removed.");
  });

  promptInput.addEventListener("input", function () {
    clearTimeout(promptSaveTimer);
    promptSaveTimer = setTimeout(function () {
      api.storage.local.set({ dolaWorkflowPrompt: promptInput.value });
    }, 250);
  });

  getLocal("dolaWorkflowPrompt").then(function (data) {
    promptInput.value = data && data.dolaWorkflowPrompt || "";
  }).catch(function (error) { setStatus(errorMessage(error, "Saved prompt could not be loaded."), true); });

  api.storage.onChanged.addListener(function (changes, area) {
    if (area !== "local" || !changes.dolaWorkflowDiagnostic || !changes.dolaWorkflowDiagnostic.newValue) return;
    var entry = changes.dolaWorkflowDiagnostic.newValue;
    setStatus(entry.message || "Workflow updated.", entry.status === "failed");
  });
}());
