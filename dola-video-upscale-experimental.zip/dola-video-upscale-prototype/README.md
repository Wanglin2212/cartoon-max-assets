# Dola Video Upscale — experimental prototype

This is a separate Chrome/Edge extension, not an update to the original duration extension. It uploads a video and sends an ordinary-chat instruction requesting 4K upscaling and clearer output. It does not perform local upscaling, add Seedance generation settings, or verify an actual 4K result.

## Install and test

1. Extract this ZIP. In Chrome or Edge, open the extensions management page, enable Developer mode, and choose Load unpacked. Select the extracted `dola-video-upscale-prototype` folder.
2. Disable the original Dola automation extension during this test so its hooks cannot interfere. Open or reload a logged-in `https://www.dola.com/chat` tab.
3. Click this extension's icon to open its side panel. Expand First-time calibration and click Learn.
4. In Dola's ordinary chat, manually attach a short video and send exactly: `DOLA_UPSCALE_CALIBRATION: Please describe this video.` This is a real chat message/upload and may consume service resources. The prototype observes the requests without automating page controls.
5. Wait for Ready. Choose another video in the extension (maximum 10 MiB), review/edit the instruction, and click Upload and send to Dola chat once.
6. Inspect the reply in Dola chat. If Dola returns a video, use Dola's own download control. Automatic result retrieval/download is not implemented.

Calibration is required once per tab session. A reload/navigation may clear it. Requests and session headers are held only in page memory, not exported or written to extension storage. After calibration, the extension itself performs no page clicks or prompt filling. Keeping the side panel open until the request returns is recommended.

## Expected limitations

- Only same-origin POST uploads with exactly one video Blob in fetch FormData are supported. XHR, chunked/binary uploads, cross-origin storage uploads, and nested string-encoded prompt schemas are unsupported.
- Signed endpoints/headers detected by the prototype are rejected. It has no request signer and cannot guarantee detection of every signature format or support other changing protocol fields.
- Upload response identifiers must match strings in the learned chat body. Unknown response shapes fail before chat submission. Known UUID message/request IDs are renewed; other identifier formats are rejected.
- Server timestamps, upload tickets, CSRF/session expiry, or other undocumented state may still make replay fail. Do not repeatedly retry an unknown result; inspect the chat first.
- HTTP 2xx means only that the endpoint responded successfully at the HTTP layer. It is not proof of application success, completed upscaling, or a 4K file.
- Nothing is automatically retried. An uploaded file can remain on Dola if the subsequent chat fails. No account reset/deletion/login automation is included.

## Validation

Run `node --test *.test.js` in this directory. Six tests cover reference/prompt replacement, preserved conversation context, new UUID IDs, unsupported schema rejection, signed/cross-origin restrictions, browser-owned headers, and a simulated calibration/upload/chat flow. Live Dola generation/upscaling has not been tested.

If testing fails, share the exact status message and the browser version. Do not share cookies, tokens, Authorization headers, or unredacted network exports.
