'use strict';
const {test}=require('node:test');const assert=require('node:assert/strict');const vm=require('node:vm');const fs=require('node:fs');const path=require('node:path');
test('learns upload/chat, sends a new video directly, and reports HTTP acceptance only',async()=>{
 const posts=[],calls=[],listeners=[];let uploads=0;
 const origin='https://www.dola.com';
 const window={DolaUpscaleCore:require('./core'),postMessage:m=>posts.push(m),addEventListener:(type,fn)=>listeners.push(fn),fetch:async(url,init)=>{calls.push({url,init});if(url==='/upload'||url===origin+'/upload'){uploads++;return new Response(JSON.stringify({data:{file_id:uploads===1?'old-video-file-id':'new-video-file-id'}}),{status:200});}return new Response('{"accepted":true}',{status:200});}};
 vm.runInNewContext(fs.readFileSync(path.join(__dirname,'page.js'),'utf8'),{window,location:{origin},URL,FormData,Blob,File,Headers,Request,ArrayBuffer,console});
 const dispatch=async data=>{for(const fn of listeners)await fn({source:window,origin,data:{source:'dola-video-upscale-content',...data}});};
 const settle=async()=>{for(let i=0;i<5;i++)await new Promise(r=>setImmediate(r));};
 const phrase='DOLA_UPSCALE_CALIBRATION: Please describe this video.';
 await dispatch({type:'ARM',phrase});const form=new FormData();form.append('video',new File(['video'],'original.mp4',{type:'video/mp4'}));
 await window.fetch('/upload',{method:'POST',body:form});await settle();
 await window.fetch('/chat',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({messages:[{text:phrase,file_id:'old-video-file-id'}]})});await settle();
 assert.equal(posts.some(x=>x.ready===true),true);
 await dispatch({type:'SEND',id:'test-run',bytes:new Uint8Array([1,2,3]).buffer,name:'new.mp4',mime:'video/mp4',prompt:'Upscale this video to 4K and improve clarity.'});
 assert.equal(calls.length,4);assert.equal(calls[2].init.body.get('video').name,'new.mp4');assert.equal(calls[2].init.credentials,'same-origin');
 const sent=JSON.parse(calls[3].init.body);assert.equal(sent.messages[0].file_id,'new-video-file-id');assert.equal(sent.messages[0].text,'Upscale this video to 4K and improve clarity.');assert.doesNotMatch(calls[3].init.body,/seedance|duration/);
 const done=posts.find(x=>x.type==='DONE');assert.equal(done.error,undefined);assert.match(done.message,/not verified/);
});
