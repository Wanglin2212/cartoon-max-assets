(function(){
'use strict';if(window.__dolaVideoUpscalePrototype)return;window.__dolaVideoUpscalePrototype=true;
const core=window.DolaUpscaleCore,nativeFetch=window.fetch;let armed=false,upload=null,chat=null,plan=null,busy=false,phrase='';
const post=(type,detail={})=>window.postMessage({source:'dola-video-upscale-page',type,...detail},location.origin);
const fail=e=>post('STATUS',{error:true,message:e.message||String(e)});
async function observe(input,init,response){
 if(!armed)return;
 const url=typeof input==='string'?input:input.url;
 const method=String(init?.method||input?.method||'GET').toUpperCase();if(method!=='POST')return;
 const body=init?.body;
 if(body instanceof FormData){
  const files=[...body.entries()].filter(([,v])=>v instanceof Blob);if(files.length!==1||!files[0][1].type.startsWith('video/'))return;
  const endpoint=core.endpoint(url,location.origin),headers=core.safeHeaders(init?.headers||input?.headers);delete headers['content-type'];
  if(!response.ok)throw Error('Calibration upload failed.');const result=await response.clone().json();
  const fields=[...body.entries()].filter(([,v])=>typeof v==='string');
  upload={url:endpoint,headers,fields,fileField:files[0][0],response:result};post('STATUS',{message:'Video upload learned. Waiting for the ordinary chat request…'});return;
 }
 let text=typeof body==='string'?body:null;
 if(!text&&input instanceof Request){try{text=await input.clone().text();}catch{}}
 if(!text||!text.includes(phrase))return;
 if(!upload)throw Error('No supported same-origin multipart video upload was observed. This site may use signed, XHR, or binary uploads.');
 const parsed=JSON.parse(text);plan=core.makePlan(upload.response,parsed,phrase);
 chat={url:core.endpoint(url,location.origin),headers:core.safeHeaders(init?.headers||input?.headers),body:parsed};
 if(!response.ok)throw Error('Calibration chat request failed.');armed=false;post('STATUS',{ready:true,message:'Ready: upload and chat formats learned in this tab. Select a new video and send.'});
}
window.fetch=function(input,init){const result=nativeFetch.apply(this,arguments);if(armed)result.then(response=>observe(input,init,response)).catch(fail);return result;};
window.addEventListener('message',async event=>{
 if(event.source!==window||event.origin!==location.origin||event.data?.source!=='dola-video-upscale-content')return;
 const {type,id}=event.data;
 if(type==='ARM'){if(busy)return;phrase=String(event.data.phrase||'');if(phrase.length<6)return;armed=true;upload=null;chat=null;plan=null;post('STATUS',{message:'Learning enabled. Manually attach a short video to ordinary Dola chat and send the displayed calibration phrase.'});}
 if(type==='STATE')post('STATUS',{ready:!!plan,message:plan?'Ready in this tab.':'Calibrate this tab first. Reloading the tab clears learned requests.'});
 if(type==='SEND'){
  if(busy){post('DONE',{id,error:'An upload is already running.'});return;}
  if(!plan||!chat||!upload){post('DONE',{id,error:'Calibrate first. No request sent.'});return;}
  busy=true;
  try{
   const bytes=event.data.bytes;if(!(bytes instanceof ArrayBuffer)||!bytes.byteLength)throw Error('Video file is empty.');
   const form=new FormData();for(const [k,v]of upload.fields)form.append(k,v);
   form.append(upload.fileField,new File([bytes],event.data.name,{type:event.data.mime}));
   post('STATUS',{message:'Uploading video directly…'});
   const uploaded=await nativeFetch.call(window,upload.url,{method:'POST',headers:upload.headers,credentials:'same-origin',body:form});
   if(!uploaded.ok)throw Error('Upload returned HTTP '+uploaded.status+'. No chat request sent.');
   const result=await uploaded.json();const body=core.buildBody(chat.body,plan,result,String(event.data.prompt));
   post('STATUS',{message:'Sending the 4K upscale instruction in chat…'});
   const response=await nativeFetch.call(window,chat.url,{method:'POST',headers:chat.headers,credentials:'same-origin',body:JSON.stringify(body)});
   if(!response.ok)throw Error('Chat returned HTTP '+response.status+'. Not retried.');
   // HTTP acceptance is not proof of a completed upscale or even app-level success.
   post('DONE',{id,message:'Chat endpoint returned HTTP '+response.status+'. Check Dola chat for its reply. Upscale completion and output resolution are not verified.'});
  }catch(e){post('DONE',{id,error:e.message||String(e)});}finally{busy=false;}
 }
});
})();
